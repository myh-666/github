package com.class2.seat27.server.repository;

import com.class2.seat27.server.entity.Material;
import com.class2.seat27.server.entity.OutboundDetail;
import com.class2.seat27.server.entity.Outbound;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OutboundDetailRepository extends JpaRepository<OutboundDetail, Long> {
    List<OutboundDetail> findByOutbound(Outbound outbound);

    List<OutboundDetail> findByMaterial(Material material);

    @Query("SELECT d FROM OutboundDetail d WHERE d.outbound.id = :outboundId")
    List<OutboundDetail> findByOutboundId(@Param("outboundId") Long outboundId);

    @Query("SELECT d FROM OutboundDetail d WHERE d.material.id = :materialId AND d.outbound.status = 'COMPLETED'")
    List<OutboundDetail> findCompletedDetailsByMaterialId(@Param("materialId") Long materialId);
    
    @Modifying
    @Query("DELETE FROM OutboundDetail d WHERE d.material.id = :materialId")
    void deleteByMaterialId(@Param("materialId") Long materialId);
    
    // 添加根据物料ID查询的方法
    @Query("SELECT d FROM OutboundDetail d WHERE d.material.id = :materialId")
    List<OutboundDetail> findByMaterialId(@Param("materialId") Long materialId);
}