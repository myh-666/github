package com.class2.seat27.server.repository;

import com.class2.seat27.server.entity.Inventory;
import com.class2.seat27.server.entity.Material;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jakarta.persistence.LockModeType;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Repository
public interface InventoryRepository extends JpaRepository<Inventory, Long> {
    Optional<Inventory> findByMaterial(Material material);

    @Query("SELECT i FROM Inventory i WHERE i.material.id = :materialId")
    Optional<Inventory> findByMaterialId(@Param("materialId") Long materialId);

    @Query("SELECT i FROM Inventory i WHERE i.quantity > 0")
    List<Inventory> findNonEmptyInventories();


    @Query("SELECT i FROM Inventory i WHERE i.quantity <= i.material.minStock")
    List<Inventory> findLowStockInventories();

    @Query("SELECT i FROM Inventory i WHERE i.quantity <= :threshold")
    List<Inventory> findLowStockInventories(@Param("threshold") BigDecimal threshold);


    @Modifying
    @Query("DELETE FROM Inventory i WHERE i.material.id = :materialId")
    void deleteByMaterialId(@Param("materialId") Long materialId);

    @Query("SELECT i FROM Inventory i WHERE i.material.name LIKE %:keyword%")
    List<Inventory> findByMaterialNameContainingIgnoreCase(@Param("keyword") String keyword);

    @Query("SELECT i FROM Inventory i WHERE i.material.materialCode LIKE %:materialCode%")
    List<Inventory> findByMaterialCodeContainingIgnoreCase(@Param("materialCode") String materialCode);

    @Query("SELECT i FROM Inventory i WHERE i.material.materialCode LIKE %:materialCode% AND i.material.name LIKE %:materialName%")
    List<Inventory> findByMaterialCodeAndNameContainingIgnoreCase(
            @Param("materialCode") String materialCode,
            @Param("materialName") String materialName);

    @Query("SELECT i FROM Inventory i WHERE i.material.id = :materialId")
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    Optional<Inventory> findByMaterialIdWithLock(@Param("materialId") Long materialId);
}