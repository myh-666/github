package com.class2.seat27.server.repository;

import com.class2.seat27.server.entity.Outbound;
import com.class2.seat27.server.entity.User;
import com.class2.seat27.server.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface OutboundRepository extends JpaRepository<Outbound, Long> {
    Optional<Outbound> findByOutboundCode(String outboundCode);

    List<Outbound> findByCreatedBy(User createdBy);

    List<Outbound> findByStatus(Status status);

    List<Outbound> findByOutboundDateBetween(LocalDateTime startDate, LocalDateTime endDate);

    @Query("SELECT o FROM Outbound o WHERE o.status = :status AND o.outboundDate >= :startDate")
    List<Outbound> findByStatusAndOutboundDateAfter(@Param("status") Status status, @Param("startDate") LocalDateTime startDate);

    @Query("SELECT o FROM Outbound o WHERE o.status = :status ORDER BY o.outboundDate DESC")
    List<Outbound> findByStatusOrderByOutboundDateDesc(@Param("status") Status status);
    
    @Query("SELECT MAX(o.outboundCode) FROM Outbound o")
    String findMaxOutboundCode();
    
    // 添加按创建时间倒序排列的第一个记录查询方法
    List<Outbound> findTop1ByOrderByCreatedTimeDesc();
    
    // 按日期范围查询出仓记录
    @Query("SELECT o FROM Outbound o WHERE DATE(o.outboundDate) BETWEEN DATE(:startDate) AND DATE(:endDate)")
    List<Outbound> findByDateRange(@Param("startDate") String startDate, @Param("endDate") String endDate);
    
    // 按物料ID和日期范围查询出仓记录
    @Query("SELECT o FROM Outbound o JOIN o.details d WHERE d.material.id = :materialId AND DATE(o.outboundDate) BETWEEN DATE(:startDate) AND DATE(:endDate)")
    List<Outbound> findByMaterialIdAndDateRange(@Param("materialId") Long materialId, @Param("startDate") String startDate, @Param("endDate") String endDate);
}