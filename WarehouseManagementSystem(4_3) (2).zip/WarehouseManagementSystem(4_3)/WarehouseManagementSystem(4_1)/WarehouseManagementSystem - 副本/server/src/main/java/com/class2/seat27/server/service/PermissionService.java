package com.class2.seat27.server.service;

import com.class2.seat27.server.entity.Permission;
import com.class2.seat27.server.entity.User;
import com.class2.seat27.server.entity.UserPermission;
import com.class2.seat27.server.repository.PermissionRepository;
import com.class2.seat27.server.repository.UserPermissionRepository;
import com.class2.seat27.server.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class PermissionService {

    @Autowired
    private PermissionRepository permissionRepository;

    @Autowired
    private UserPermissionRepository userPermissionRepository;

    @Autowired
    private UserRepository userRepository;

    /**
     * 获取所有权限资源
     */
    public List<Permission> getAllPermissions() {
        return permissionRepository.findAllByOrderByMenuPathAsc();
    }

    /**
     * 获取用户的权限列表
     */
    public List<UserPermission> getUserPermissions(Long userId) {
        List<UserPermission> userPermissions = userPermissionRepository.findByUserId(userId);

        // 填充用户和权限信息
        for (UserPermission userPermission : userPermissions) {
            userPermission.setUser(userRepository.findById(userId).orElse(null));
            userPermission.setPermission(permissionRepository.findByResourceCode(userPermission.getResourceCode()).orElse(null));
        }

        return userPermissions;
    }

    /**
     * 获取用户的完整权限信息（包括未设置的权限）
     */
    public List<Map<String, Object>> getUserFullPermissions(Long userId) {
        List<Permission> allPermissions = getAllPermissions();
        List<UserPermission> userPermissions = getUserPermissions(userId);

        // 将用户权限转换为Map便于查找
        Map<String, Boolean> userPermissionMap = userPermissions.stream()
                .collect(Collectors.toMap(UserPermission::getResourceCode, UserPermission::getGranted));

        // 构建完整权限列表
        List<Map<String, Object>> result = new ArrayList<>();
        for (Permission permission : allPermissions) {
            Map<String, Object> permissionInfo = new HashMap<>();
            permissionInfo.put("resourceCode", permission.getResourceCode());
            permissionInfo.put("resourceName", permission.getResourceName());
            permissionInfo.put("menuPath", permission.getMenuPath());
            permissionInfo.put("description", permission.getDescription());

            // 设置授权状态，如果用户没有设置该权限，默认为false
            Boolean granted = userPermissionMap.get(permission.getResourceCode());
            permissionInfo.put("granted", granted != null ? granted : false);

            result.add(permissionInfo);
        }

        return result;
    }

    /**
     * 更新用户权限
     */
    @Transactional
    public boolean updateUserPermissions(Long userId, Map<String, Boolean> permissions, String updateUser) {
        try {
            for (Map.Entry<String, Boolean> entry : permissions.entrySet()) {
                String resourceCode = entry.getKey();
                Boolean granted = entry.getValue();

                // 检查权限资源是否存在
                Optional<Permission> permissionOpt = permissionRepository.findByResourceCode(resourceCode);
                if (!permissionOpt.isPresent()) {
                    continue; // 跳过不存在的权限
                }

                // 检查用户是否存在
                Optional<User> userOpt = userRepository.findById(userId);
                if (!userOpt.isPresent()) {
                    throw new Exception("用户不存在");
                }

                // 查找现有的用户权限记录
                Optional<UserPermission> userPermissionOpt = userPermissionRepository.findByUserIdAndResourceCode(userId, resourceCode);

                if (userPermissionOpt.isPresent()) {
                    // 更新现有记录
                    UserPermission userPermission = userPermissionOpt.get();
                    userPermission.setGranted(granted);
                    userPermission.setUpdateTime(LocalDateTime.now());
                    userPermission.setUpdateUser(updateUser);
                    userPermissionRepository.save(userPermission);
                } else {
                    // 创建新记录
                    UserPermission userPermission = new UserPermission();
                    userPermission.setUserId(userId);
                    userPermission.setResourceCode(resourceCode);
                    userPermission.setGranted(granted);
                    userPermission.setUpdateTime(LocalDateTime.now());
                    userPermission.setUpdateUser(updateUser);
                    userPermissionRepository.save(userPermission);
                }
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 检查用户是否有某个权限
     */
    public boolean checkPermission(Long userId, String resourceCode) {
        // 管理员默认拥有所有权限
        Optional<User> userOpt = userRepository.findById(userId);
        if (userOpt.isPresent() && userOpt.get().getUserRole() == User.UserRole.ADMIN) {
            return true;
        }

        // 个人管理权限默认允许所有登录用户访问
        if ("PERSONAL_CHANGE_PWD".equals(resourceCode) ||
                "PERSONAL_MODIFY_PROFILE".equals(resourceCode)) {
            return true;
        }

        return userPermissionRepository.hasPermission(userId, resourceCode);
    }
    /*public boolean checkPermission(Long userId, String resourceCode) {
        // 管理员默认拥有所有权限
        Optional<User> userOpt = userRepository.findById(userId);
        if (userOpt.isPresent() && userOpt.get().getUserRole() == User.UserRole.ADMIN) {
            return true;
        }

        // 新增：个人管理权限默认允许所有登录用户访问
        if ("PERSONAL_CHANGE_PWD".equals(resourceCode) ||
                "PERSONAL_MODIFY_PROFILE".equals(resourceCode)) {
            return true;
        }

        return userPermissionRepository.hasPermission(userId, resourceCode);
    }*/

    /**
     * 重置用户权限（删除所有权限）
     */
    @Transactional
    public boolean resetUserPermissions(Long userId) {
        try {
            userPermissionRepository.deleteByUserId(userId);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 获取用户有权限的菜单列表
     */
    public List<String> getUserAllowedMenus(Long userId) {
        List<UserPermission> permissions = userPermissionRepository.findByUserIdAndGranted(userId, true);
        return permissions.stream()
                .map(up -> {
                    Optional<Permission> permissionOpt = permissionRepository.findByResourceCode(up.getResourceCode());
                    return permissionOpt.map(Permission::getMenuPath).orElse(null);
                })
                .filter(Objects::nonNull)
                .distinct()
                .collect(Collectors.toList());
    }
}