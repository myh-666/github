
package com.class2.seat27.server.entity;

public enum Status {
    DRAFT, CONFIRMED, COMPLETED, CANCELLED
}
