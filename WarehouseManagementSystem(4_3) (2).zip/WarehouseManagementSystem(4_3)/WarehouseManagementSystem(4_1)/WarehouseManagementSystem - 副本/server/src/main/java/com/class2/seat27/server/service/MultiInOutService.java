package com.class2.seat27.server.service;

import com.class2.seat27.server.entity.*;
import com.class2.seat27.server.repository.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Types;
import java.time.LocalDateTime;
import java.util.*;

/**
 * 多物料进出仓服务类
 * 使用存储过程处理多物料进出仓操作
 * 确保事务处理，失败时能够全部回滚
 * 所有数量相关字段已修改为int型
 */
@Service
public class MultiInOutService {

    @Autowired
    private MaterialRepository materialRepository;

    @Autowired
    private InventoryRepository inventoryRepository;

    @Autowired
    private MultiInOutRecordRepository multiInOutRecordRepository;

    @Autowired
    private MultiInOutDetailRepository multiInOutDetailRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private WarehouseLedgerRepository warehouseLedgerRepository;

    @Autowired
    private javax.sql.DataSource dataSource;

    @Autowired
    private DocumentSequenceService documentSequenceService;

    @Autowired
    private ObjectMapper objectMapper;

    /**
     * 多物料进仓处理方法
     * 使用新的存储过程，确保所有数量字段为int型
     * 直接完成进仓操作并更新库存
     * 进仓操作不检查库存，只验证数量为正数
     * 注意：进出仓单创建时即自动完成，不再需要单独的"完成"步骤
     */
    @Transactional
    public Map<String, Object> processMultiInbound(String documentCode, String operatorCode, String handlerCode, String remark, List<Map<String, Object>> materials) {
        Map<String, Object> result = new HashMap<>();

        try {
            // 验证进仓特定逻辑 - 只验证数量为正数，不验证库存
            // 进仓操作是增加库存，不需要检查库存是否充足，与出仓操作完全分离
            // 注意：进仓和出仓的验证逻辑必须完全分离，不能混淆
            Map<String, Object> validation = validateInbound(materials);
            if (!(Boolean) validation.get("valid")) {
                result.put("result", 0);
                result.put("message", "进仓验证失败: " + validation.get("message"));
                return result;
            }

            // 确保所有数量字段为int型
            List<Map<String, Object>> processedMaterials = new ArrayList<>();
            for (Map<String, Object> material : materials) {
                Map<String, Object> processedMaterial = new HashMap<>(material);
                // 确保数量为int型
                if (material.containsKey("quantity")) {
                    Object quantity = material.get("quantity");
                    if (quantity instanceof BigDecimal) {
                        processedMaterial.put("quantity", ((BigDecimal) quantity).intValue());
                    } else if (quantity instanceof Double) {
                        processedMaterial.put("quantity", ((Double) quantity).intValue());
                    } else if (quantity instanceof String) {
                        try {
                            processedMaterial.put("quantity", Integer.parseInt((String) quantity));
                        } catch (NumberFormatException e) {
                            result.put("result", 0);
                            result.put("message", "数量格式错误: " + quantity);
                            return result;
                        }
                    }
                }
                // 确保materialId为Long型
                if (material.containsKey("materialId")) {
                    Object materialId = material.get("materialId");
                    if (materialId instanceof Integer) {
                        processedMaterial.put("materialId", ((Integer) materialId).longValue());
                    } else if (materialId instanceof String) {
                        try {
                            processedMaterial.put("materialId", Long.parseLong((String) materialId));
                        } catch (NumberFormatException e) {
                            result.put("result", 0);
                            result.put("message", "物料ID格式错误: " + materialId);
                            return result;
                        }
                    }
                }
                processedMaterials.add(processedMaterial);
            }

            // 构建物料JSON
            String materialsJson = objectMapper.writeValueAsString(processedMaterials);

            // 如果没有提供单号，使用单号序列服务生成一个
            if (documentCode == null || documentCode.isEmpty()) {
                documentCode = documentSequenceService.getNextDocumentNumber("MIIN");
            }

            // 直接调用多物料进仓存储过程，一步完成所有操作
            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(dataSource)
                    .withProcedureName("class2_seat27_多物料进仓")
                    .declareParameters(
                            new SqlParameter("p_document_code", Types.VARCHAR),
                            new SqlParameter("p_operation_date", Types.TIMESTAMP),
                            new SqlParameter("p_operator_code", Types.VARCHAR),
                            new SqlParameter("p_handler_code", Types.VARCHAR),
                            new SqlParameter("p_remark", Types.VARCHAR),
                            new SqlParameter("p_materials", Types.JAVA_OBJECT),
                            new SqlOutParameter("p_result", Types.INTEGER),
                            new SqlOutParameter("p_message", Types.VARCHAR)
                    );

            // 构建输入参数
            Map<String, Object> inParams = new HashMap<>();
            inParams.put("p_document_code", documentCode);
            inParams.put("p_operation_date", new java.util.Date());
            inParams.put("p_operator_code", operatorCode);
            inParams.put("p_handler_code", handlerCode);
            inParams.put("p_remark", remark);
            inParams.put("p_materials", materialsJson);

            // 执行存储过程
            Map<String, Object> outParams = jdbcCall.execute(inParams);

            // 获取输出参数
            int procResult = (Integer) outParams.get("p_result");
            String procMessage = (String) outParams.get("p_message");

            // 设置返回结果
            result.put("result", procResult);
            result.put("message", procMessage);

            if (procResult == 1) {
                // 查询创建的记录
                MultiInOutRecord record = multiInOutRecordRepository.findByDocumentCode(documentCode)
                        .orElseThrow(() -> new RuntimeException("找不到创建的记录"));
                result.put("data", record);
            }

            return result;
        } catch (JsonProcessingException e) {
            result.put("result", 0);
            result.put("message", "构建物料JSON失败: " + e.getMessage());
            return result;
        } catch (Exception e) {
            result.put("result", 0);
            result.put("message", "多物料进仓失败: " + e.getMessage());
            return result;
        }
    }

    /**
     * 多物料出仓处理方法
     * 使用新的存储过程，确保所有数量字段为int型
     * 直接完成出仓操作并更新库存
     * 出仓操作必须验证库存是否充足
     * 注意：进出仓单创建时即自动完成，不再需要单独的"完成"步骤
     */
    @Transactional
    public Map<String, Object> processMultiOutbound(String documentCode, String operatorCode, String handlerCode, String remark, List<Map<String, Object>> materials) {
        Map<String, Object> result = new HashMap<>();

        try {
            // 验证出仓特定逻辑 - 验证数量为正数且库存充足
            // 出仓操作必须检查库存是否充足，与进仓操作完全分离
            Map<String, Object> validation = validateOutbound(materials);
            if (!(Boolean) validation.get("valid")) {
                result.put("result", 0);
                result.put("message", validation.get("message"));
                return result;
            }

            // 确保所有数量字段为int型
            List<Map<String, Object>> processedMaterials = new ArrayList<>();
            for (Map<String, Object> material : materials) {
                Map<String, Object> processedMaterial = new HashMap<>(material);
                // 确保数量为int型
                if (material.containsKey("quantity")) {
                    Object quantity = material.get("quantity");
                    if (quantity instanceof BigDecimal) {
                        processedMaterial.put("quantity", ((BigDecimal) quantity).intValue());
                    } else if (quantity instanceof Double) {
                        processedMaterial.put("quantity", ((Double) quantity).intValue());
                    } else if (quantity instanceof String) {
                        try {
                            processedMaterial.put("quantity", Integer.parseInt((String) quantity));
                        } catch (NumberFormatException e) {
                            result.put("result", 0);
                            result.put("message", "数量格式错误: " + quantity);
                            return result;
                        }
                    }
                }
                // 确保materialId为Long型
                if (material.containsKey("materialId")) {
                    Object materialId = material.get("materialId");
                    if (materialId instanceof Integer) {
                        processedMaterial.put("materialId", ((Integer) materialId).longValue());
                    } else if (materialId instanceof String) {
                        try {
                            processedMaterial.put("materialId", Long.parseLong((String) materialId));
                        } catch (NumberFormatException e) {
                            result.put("result", 0);
                            result.put("message", "物料ID格式错误: " + materialId);
                            return result;
                        }
                    }
                }
                processedMaterials.add(processedMaterial);
            }

            // 构建物料JSON
            String materialsJson = objectMapper.writeValueAsString(processedMaterials);

            // 如果没有提供单号，使用单号序列服务生成一个
            if (documentCode == null || documentCode.isEmpty()) {
                documentCode = documentSequenceService.getNextDocumentNumber("MIOUT");
            }

            // 直接调用多物料出仓存储过程，一步完成所有操作
            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(dataSource)
                    .withProcedureName("class2_seat27_多物料出仓")
                    .declareParameters(
                            new SqlParameter("p_document_code", Types.VARCHAR),
                            new SqlParameter("p_operation_date", Types.TIMESTAMP),
                            new SqlParameter("p_operator_code", Types.VARCHAR),
                            new SqlParameter("p_handler_code", Types.VARCHAR),
                            new SqlParameter("p_remark", Types.VARCHAR),
                            new SqlParameter("p_materials", Types.JAVA_OBJECT),
                            new SqlOutParameter("p_result", Types.INTEGER),
                            new SqlOutParameter("p_message", Types.VARCHAR)
                    );

            // 构建输入参数
            Map<String, Object> inParams = new HashMap<>();
            inParams.put("p_document_code", documentCode);
            inParams.put("p_operation_date", new java.util.Date());
            inParams.put("p_operator_code", operatorCode);
            inParams.put("p_handler_code", handlerCode);
            inParams.put("p_remark", remark);
            inParams.put("p_materials", materialsJson);

            // 执行存储过程
            Map<String, Object> outParams = jdbcCall.execute(inParams);

            // 获取输出参数
            int procResult = (Integer) outParams.get("p_result");
            String procMessage = (String) outParams.get("p_message");

            // 设置返回结果
            result.put("result", procResult);
            result.put("message", procMessage);

            if (procResult == 1) {
                // 查询创建的记录
                MultiInOutRecord record = multiInOutRecordRepository.findByDocumentCode(documentCode)
                        .orElseThrow(() -> new RuntimeException("找不到创建的记录"));
                result.put("data", record);
            }

            return result;
        } catch (JsonProcessingException e) {
            result.put("result", 0);
            result.put("message", "构建物料JSON失败: " + e.getMessage());
            return result;
        } catch (Exception e) {
            result.put("result", 0);
            result.put("message", "多物料出仓失败: " + e.getMessage());
            return result;
        }
    }

    /**
     * 验证进仓操作的特定逻辑
     * 进仓操作不检查库存，只验证数量为正数和物料是否存在
     * 与出仓操作完全分离，确保不会混淆验证逻辑
     *
     * 重要提醒：进仓是增加库存的操作，不应该检查库存是否充足
     * 如果进仓时显示"库存不足"错误，说明可能错误地应用了出仓的验证逻辑
     *
     * @param materials 物料列表
     * @return 验证结果
     */
    private Map<String, Object> validateInbound(List<Map<String, Object>> materials) {
        Map<String, Object> result = new HashMap<>();
        result.put("valid", true);

        // 进仓操作不检查库存，只验证数量为正数和物料是否存在
        // 进仓是增加库存的操作，不应该检查库存是否充足
        // 进仓和出仓的验证逻辑必须完全分离，不能混淆
        for (Map<String, Object> material : materials) {
            // 验证数量是否为正数
            int quantity;
            try {
                Object quantityObj = material.get("quantity");
                if (quantityObj == null) {
                    result.put("valid", false);
                    result.put("message", "物料数量不能为空");
                    return result;
                }

                // 简化类型转换逻辑，避免可能的错误
                if (quantityObj instanceof Integer) {
                    quantity = (Integer) quantityObj;
                } else if (quantityObj instanceof String) {
                    quantity = Integer.parseInt((String) quantityObj);
                } else if (quantityObj instanceof BigDecimal) {
                    quantity = ((BigDecimal) quantityObj).intValue();
                } else {
                    result.put("valid", false);
                    result.put("message", "物料数量格式错误");
                    return result;
                }
            } catch (NumberFormatException e) {
                result.put("valid", false);
                result.put("message", "物料数量格式错误: " + e.getMessage());
                return result;
            }

            if (quantity <= 0) {
                result.put("valid", false);
                result.put("message", "进仓物料数量必须大于0");
                return result;
            }

            // 验证物料是否存在
            Long materialId;
            try {
                Object materialIdObj = material.get("materialId");
                if (materialIdObj == null) {
                    result.put("valid", false);
                    result.put("message", "物料ID不能为空");
                    return result;
                }

                // 简化类型转换逻辑，避免可能的错误
                if (materialIdObj instanceof Long) {
                    materialId = (Long) materialIdObj;
                } else if (materialIdObj instanceof Integer) {
                    materialId = ((Integer) materialIdObj).longValue();
                } else if (materialIdObj instanceof String) {
                    materialId = Long.parseLong((String) materialIdObj);
                } else {
                    result.put("valid", false);
                    result.put("message", "物料ID格式错误");
                    return result;
                }
            } catch (NumberFormatException e) {
                result.put("valid", false);
                result.put("message", "物料ID格式错误: " + e.getMessage());
                return result;
            }

            // 检查物料是否存在
            if (!materialRepository.existsById(materialId)) {
                result.put("valid", false);
                result.put("message", "物料ID " + materialId + " 不存在");
                return result;
            }
        }

        return result;
    }

    /**
     * 验证出仓操作的特定逻辑
     * 出仓操作必须验证库存是否充足，使用SELECT FOR UPDATE防止并发问题
     * 与进仓操作完全分离，确保不会混淆验证逻辑
     *
     * 重要提醒：出仓是减少库存的操作，必须检查库存是否充足
     * 这是与进仓操作的主要区别，进仓操作不检查库存
     *
     * @param materials 物料列表
     * @return 验证结果
     */
    private Map<String, Object> validateOutbound(List<Map<String, Object>> materials) {
        Map<String, Object> result = new HashMap<>();
        result.put("valid", true);

        // 出仓需要检查库存是否充足，这是与进仓操作的主要区别
        // 进仓操作不检查库存，出仓操作必须检查库存
        for (Map<String, Object> material : materials) {
            // 验证物料ID和数量是否有效
            Long materialId;
            int quantity;

            // 解析物料ID
            try {
                Object materialIdObj = material.get("materialId");
                if (materialIdObj == null) {
                    result.put("valid", false);
                    result.put("message", "物料ID不能为空");
                    return result;
                }

                // 简化类型转换逻辑，避免可能的错误
                if (materialIdObj instanceof Long) {
                    materialId = (Long) materialIdObj;
                } else if (materialIdObj instanceof Integer) {
                    materialId = ((Integer) materialIdObj).longValue();
                } else if (materialIdObj instanceof String) {
                    materialId = Long.parseLong((String) materialIdObj);
                } else {
                    result.put("valid", false);
                    result.put("message", "物料ID格式错误");
                    return result;
                }
            } catch (NumberFormatException e) {
                result.put("valid", false);
                result.put("message", "物料ID格式错误: " + e.getMessage());
                return result;
            }

            // 解析数量
            try {
                Object quantityObj = material.get("quantity");
                if (quantityObj == null) {
                    result.put("valid", false);
                    result.put("message", "物料数量不能为空");
                    return result;
                }

                // 简化类型转换逻辑，避免可能的错误
                if (quantityObj instanceof Integer) {
                    quantity = (Integer) quantityObj;
                } else if (quantityObj instanceof String) {
                    quantity = Integer.parseInt((String) quantityObj);
                } else if (quantityObj instanceof BigDecimal) {
                    quantity = ((BigDecimal) quantityObj).intValue();
                } else {
                    result.put("valid", false);
                    result.put("message", "物料数量格式错误");
                    return result;
                }
            } catch (NumberFormatException e) {
                result.put("valid", false);
                result.put("message", "物料数量格式错误: " + e.getMessage());
                return result;
            }

            if (quantity <= 0) {
                result.put("valid", false);
                result.put("message", "出仓物料数量必须大于0");
                return result;
            }

            // 使用SELECT FOR UPDATE锁定库存记录，防止并发问题
            // 检查库存是否充足
            Optional<Inventory> inventoryOpt = inventoryRepository.findByMaterialIdWithLock(materialId);

            // 简化库存数量获取逻辑，直接使用实体类的getQuantity方法
            // Inventory实体类中quantity字段已定义为Integer类型，不需要复杂的类型转换
            int currentQuantity = inventoryOpt.isPresent() ? inventoryOpt.get().getQuantity() : 0;

            if (currentQuantity < quantity) {
                // 获取物料信息用于错误提示
                Optional<Material> materialOpt = materialRepository.findById(materialId);
                String materialName = materialOpt.map(Material::getName).orElse("未知物料");
                String materialCode = materialOpt.map(Material::getMaterialCode).orElse("未知编码");

                result.put("valid", false);
                result.put("message", String.format("物料 %s (编码: %s) 库存不足，当前库存: %d，需要: %d",
                        materialName, materialCode, currentQuantity, quantity));
                return result;
            }
        }

        return result;
    }

    /**
     * 查询多物料进出仓记录
     * @param type 进出仓类型（INBOUND/OUTBOUND）
     * @param materialCode 物料代码
     * @param operatorCode 操作人代码
     * @param startDate 开始日期
     * @param endDate 结束日期
     * @param remark 备注
     * @return 记录列表
     */
    public List<Map<String, Object>> getMultiInOutRecords(String type, String materialCode, String operatorCode, String startDate, String endDate, String remark) {
        try {
            // 构建动态SQL查询
            StringBuilder sql = new StringBuilder(
                    "SELECT r.id, r.document_code, r.operation_type, r.operation_date, " +
                            "r.operator_code, r.handler_code, r.remark, r.status, r.created_time, r.updated_time, " +
                            "d.material_code, d.material_name, d.specification, d.unit, d.quantity, " +
                            "d.unit_price, d.total_price, " +
                            "op.name AS operator_name, h.name AS handler_name " +
                            "FROM class2_seat27_multi_inout_record r " +
                            "LEFT JOIN class2_seat27_multi_inout_detail d ON r.id = d.multi_inout_record_id " +
                            "LEFT JOIN class2_seat27_personnel op ON r.operator_code = op.personnel_code " +
                            "LEFT JOIN class2_seat27_personnel h ON r.handler_code = h.personnel_code " +
                            "WHERE 1=1");

            List<Object> params = new ArrayList<>();

            // 添加类型筛选条件 - 修复点：确保类型比较正确
            if (type != null && !type.isEmpty()) {
                // 确保传入的类型值与数据库中的值匹配
                if ("进仓".equals(type) || "INBOUND".equals(type)) {
                    sql.append(" AND r.operation_type = 'INBOUND'");
                } else if ("出仓".equals(type) || "OUTBOUND".equals(type)) {
                    sql.append(" AND r.operation_type = 'OUTBOUND'");
                } else {
                    // 如果是其他值，直接使用原始值
                    sql.append(" AND r.operation_type = ?");
                    params.add(type);
                }
            }

            // 添加物料筛选条件
            if (materialCode != null && !materialCode.isEmpty()) {
                sql.append(" AND d.material_code = ?");
                params.add(materialCode);
            }

            // 添加操作人筛选条件
            if (operatorCode != null && !operatorCode.isEmpty()) {
                sql.append(" AND r.operator_code = ?");
                params.add(operatorCode);
            }

            // 添加日期范围筛选条件
            if (startDate != null && !startDate.isEmpty()) {
                sql.append(" AND DATE(r.operation_date) >= ?");
                params.add(startDate);
            }

            if (endDate != null && !endDate.isEmpty()) {
                sql.append(" AND DATE(r.operation_date) <= ?");
                params.add(endDate);
            }

            // 添加备注筛选条件
            if (remark != null && !remark.isEmpty()) {
                sql.append(" AND r.remark LIKE ?");
                params.add("%" + remark + "%");
            }

            // 添加排序
            sql.append(" ORDER BY r.operation_date DESC, r.document_code");

            // 使用SimpleJdbcCall获取JdbcTemplate
            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(dataSource);
            return jdbcCall.getJdbcTemplate().queryForList(sql.toString(), params.toArray());
        } catch (Exception e) {
            throw new RuntimeException("查询多物料进出仓记录失败: " + e.getMessage());
        }
    }
}
