package com.class2.seat27.server.service;

import com.class2.seat27.server.entity.User;
import com.class2.seat27.server.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class PersonnelService {

    @Autowired
    private UserRepository userRepository;

    // 身份证号码正则验证
    private static final Pattern ID_CARD_PATTERN = Pattern.compile("^[1-9]\\d{5}(18|19|20)\\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$");

    public User addPersonnel(User user) throws Exception {
        // 验证人员代码不能为空
        if (user.getPersonnelCode() == null || user.getPersonnelCode().trim().isEmpty()) {
            throw new Exception("人员代码不能为空");
        }

        // 验证人员代码是否已存在
        if (userRepository.findByPersonnelCode(user.getPersonnelCode()).isPresent()) {
            throw new Exception("人员代码已存在");
        }

        // 验证身份证号码格式
        if (user.getIdCard() != null && !user.getIdCard().trim().isEmpty()) {
            if (!ID_CARD_PATTERN.matcher(user.getIdCard()).matches()) {
                throw new Exception("身份证号码格式不正确");
            }
        }

        // 设置创建时间和更新时间
        user.setCreatedTime(LocalDateTime.now());
        user.setUpdatedTime(LocalDateTime.now());

        return userRepository.save(user);
    }

    public User updatePersonnel(User user) throws Exception {
        // 验证人员是否存在
        Optional<User> existingUserOpt = userRepository.findById(user.getId());
        if (!existingUserOpt.isPresent()) {
            throw new Exception("人员不存在");
        }

        User existingUser = existingUserOpt.get();

        // 验证身份证号码格式
        if (user.getIdCard() != null && !user.getIdCard().trim().isEmpty()) {
            if (!ID_CARD_PATTERN.matcher(user.getIdCard()).matches()) {
                throw new Exception("身份证号码格式不正确");
            }
        }

        // 更新字段
        existingUser.setName(user.getName());
        existingUser.setGender(user.getGender());
        existingUser.setBirthDate(user.getBirthDate());
        existingUser.setIdCard(user.getIdCard());
        existingUser.setNativePlace(user.getNativePlace());
        existingUser.setAddress(user.getAddress());
        existingUser.setPhone(user.getPhone());
        existingUser.setOtherInfo(user.getOtherInfo());
        existingUser.setUpdatedTime(LocalDateTime.now());

        return userRepository.save(existingUser);
    }

    public void deletePersonnel(Long id) throws Exception {
        // 验证人员是否存在
        if (!userRepository.existsById(id)) {
            throw new Exception("人员不存在");
        }
        userRepository.deleteById(id);
    }

    public List<User> getAllPersonnel() {
        return userRepository.findAll();
    }

    public List<User> searchPersonnelByName(String name) {
        List<User> allUsers = userRepository.findAll();
        return allUsers.stream()
                .filter(user -> user.getName() != null && user.getName().contains(name))
                .collect(Collectors.toList());
    }

    public User getPersonnelByCode(String personnelCode) throws Exception {
        Optional<User> userOpt = userRepository.findByPersonnelCode(personnelCode);
        if (!userOpt.isPresent()) {
            throw new Exception("人员不存在");
        }
        return userOpt.get();
    }

    public User getPersonnelById(Long id) throws Exception {
        Optional<User> userOpt = userRepository.findById(id);
        if (!userOpt.isPresent()) {
            throw new Exception("人员不存在");
        }
        return userOpt.get();
    }


    // 在 PersonnelService 类中添加以下方法：

    /*public User addPersonnelFromMap(Map<String, Object> userData) throws Exception {
        User user = new User();

        // 设置基本字段
        user.setPersonnelCode((String) userData.get("personnelCode"));
        user.setName((String) userData.get("name"));
        user.setGender(User.Gender.valueOf((String) userData.get("gender")));

        // 处理出生日期
        if (userData.get("birthDate") != null) {
            String birthDateStr = (String) userData.get("birthDate");
            LocalDate birthDate = LocalDate.parse(birthDateStr);
            user.setBirthDate(birthDate);
        }

        user.setIdCard((String) userData.get("idCard"));
        user.setNativePlace((String) userData.get("nativePlace"));
        user.setAddress((String) userData.get("address"));
        user.setPhone((String) userData.get("phone"));
        user.setOtherInfo((String) userData.get("otherInfo"));

        // 设置时间戳
        user.setCreatedTime(LocalDateTime.now());
        user.setUpdatedTime(LocalDateTime.now());

        return addPersonnel(user);
    }*/


    public User addPersonnelFromMap(Map<String, Object> userData) throws Exception {
        User user = new User();

        // 自动生成人员代码，不再从 userData 获取
        String generatedCode = generatePersonnelCode();
        user.setPersonnelCode(generatedCode);

        user.setName((String) userData.get("name"));
        user.setGender(User.Gender.valueOf((String) userData.get("gender")));

        // 处理出生日期
        if (userData.get("birthDate") != null) {
            String birthDateStr = (String) userData.get("birthDate");
            LocalDate birthDate = LocalDate.parse(birthDateStr);
            user.setBirthDate(birthDate);
        }

        user.setIdCard((String) userData.get("idCard"));
        user.setNativePlace((String) userData.get("nativePlace"));
        user.setAddress((String) userData.get("address"));
        user.setPhone((String) userData.get("phone"));
        user.setOtherInfo((String) userData.get("otherInfo"));

        // 设置时间戳
        user.setCreatedTime(LocalDateTime.now());
        user.setUpdatedTime(LocalDateTime.now());

        return addPersonnel(user);
    }

    // 生成人员代码的方法
    private String generatePersonnelCode() {
        // 生成基于时间戳和随机数的代码，例如: P20231201123045001
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        String randomSuffix = String.format("%03d", new Random().nextInt(1000));
        return "P" + timestamp + randomSuffix;
    }



    public User updatePersonnelFromMap(Map<String, Object> userData) throws Exception {
        Long id = Long.valueOf(userData.get("id").toString());
        User user = new User();
        user.setId(id);
        user.setPersonnelCode((String) userData.get("personnelCode"));
        user.setName((String) userData.get("name"));
        user.setGender(User.Gender.valueOf((String) userData.get("gender")));

        // 处理出生日期
        if (userData.get("birthDate") != null) {
            String birthDateStr = (String) userData.get("birthDate");
            LocalDate birthDate = LocalDate.parse(birthDateStr);
            user.setBirthDate(birthDate);
        }

        user.setIdCard((String) userData.get("idCard"));
        user.setNativePlace((String) userData.get("nativePlace"));
        user.setAddress((String) userData.get("address"));
        user.setPhone((String) userData.get("phone"));
        user.setOtherInfo((String) userData.get("otherInfo"));

        return updatePersonnel(user);
    }

//    // 用户授权
//    public User authorizeUser(Long personnelId, String role) throws Exception {
//        Optional<User> userOpt = userRepository.findById(personnelId);
//        if (!userOpt.isPresent()) {
//            throw new Exception("人员不存在");
//        }
//
//        User user = userOpt.get();
//
//        // 设置用户角色
//        if ("管理员".equals(role)) {
//            user.setUserRole(User.UserRole.ADMIN);
//        } else if ("普通用户".equals(role)) {
//            user.setUserRole(User.UserRole.USER);
//        } else {
//            throw new Exception("无效的角色类型");
//        }
//
//        user.setUpdatedTime(LocalDateTime.now());
//
//        return userRepository.save(user);
//    }


}