
package com.class2.seat27.server.repository;

import com.class2.seat27.server.entity.WarehouseLedger;
import com.class2.seat27.server.entity.Material;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

/**
 * 仓库账本仓库接口
 */
@Repository
public interface WarehouseLedgerRepository extends JpaRepository<WarehouseLedger, Long> {

    /**
     * 根据物料和日期范围查询仓库账本
     */
    List<WarehouseLedger> findByMaterialAndLedgerDateBetween(Material material, LocalDate startDate, LocalDate endDate);

    /**
     * 根据物料和年份查询仓库账本
     */
    @Query("SELECT w FROM WarehouseLedger w WHERE w.material = :material AND YEAR(w.ledgerDate) = :year ORDER BY w.ledgerDate")
    List<WarehouseLedger> findByMaterialAndYear(@Param("material") Material material, @Param("year") int year);

    /**
     * 根据年份查询所有物料的仓库账本
     */
    @Query("SELECT w FROM WarehouseLedger w WHERE YEAR(w.ledgerDate) = :year ORDER BY w.ledgerDate, w.material.materialCode")
    List<WarehouseLedger> findByYear(@Param("year") int year);

    /**
     * 根据物料代码查询仓库账本
     */
    @Query("SELECT w FROM WarehouseLedger w WHERE w.material.materialCode = :materialCode ORDER BY w.ledgerDate")
    List<WarehouseLedger> findByMaterialCode(@Param("materialCode") String materialCode);

    /**
     * 根据物料代码和年份查询仓库账本
     */
    @Query("SELECT w FROM WarehouseLedger w WHERE w.material.materialCode = :materialCode AND YEAR(w.ledgerDate) = :year ORDER BY w.ledgerDate")
    List<WarehouseLedger> findByMaterialCodeAndYear(@Param("materialCode") String materialCode, @Param("year") int year);

    /**
     * 删除特定物料的仓库账本记录
     */
    void deleteByMaterialId(Long materialId);

    /**
     * 根据物料ID查找仓库账本记录，按日期降序排列
     */
    List<WarehouseLedger> findByMaterialIdOrderByLedgerDateDesc(Long materialId);
    
    /**
     * 根据物料ID和日期范围查找仓库账本记录，按日期升序排列
     */
    List<WarehouseLedger> findByMaterialIdAndLedgerDateBetweenOrderByLedgerDateAsc(Long materialId, LocalDate startDate, LocalDate endDate);
    
    /**
     * 根据日期范围查找所有仓库账本记录，按日期升序排列
     */
    List<WarehouseLedger> findByLedgerDateBetweenOrderByLedgerDateAsc(LocalDate startDate, LocalDate endDate);
}
