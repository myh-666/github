package com.class2.seat27.server.service;

import com.class2.seat27.server.entity.*;
import com.class2.seat27.server.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

/**
 * 报表服务类（新版）
 * 处理各类报表统计和打印功能
 */
@Service
public class ReportServiceNewFixed {

    @Autowired
    private MaterialRepository materialRepository;

    @Autowired
    private InventoryRepository inventoryRepository;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * 使用存储过程生成物料统计信息
     */
    public Map<String, Object> getMaterialStatisticsByProcedure(LocalDate startDate, LocalDate endDate) {
        Map<String, Object> result = new HashMap<>();

        try {
            // 直接调用存储过程获取数据结果集
            List<Map<String, Object>> records = jdbcTemplate.queryForList(
                "CALL class2_seat27_material_flow_statistics(?, ?)",
                startDate, endDate);

            // 打印调试信息
            System.out.println("物料统计查询: " + startDate + " 至 " + endDate);
            System.out.println("返回记录数: " + records.size());

            result.put("success", true);
            result.put("data", records);
            result.put("message", "物料流量统计查询完成");

            return result;
        } catch (Exception e) {
            System.err.println("物料统计数据生成失败: " + e.getMessage());
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "物料统计数据生成失败: " + e.getMessage());
            return result;
        }
    }

    /**
     * 使用存储过程生成月度进出仓单数据
     */
    public Map<String, Object> getMonthlyRecordsByProcedure(int year, int month) {
        Map<String, Object> result = new HashMap<>();

        try {
            // 直接调用存储过程获取数据结果集
            List<Map<String, Object>> records = jdbcTemplate.queryForList(
                "CALL class2_seat27_monthly_records(?, ?)",
                year, month);

            result.put("success", true);
            result.put("data", records);
            result.put("message", "月度进出仓单查询完成");

            return result;
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "月度进出仓单数据生成失败: " + e.getMessage());
            return result;
        }
    }

    /**
     * 使用存储过程生成仓库账本数据
     */
    public Map<String, Object> getWarehouseLedgerByProcedure(int year, String materialCode) {
        Map<String, Object> result = new HashMap<>();

        try {
            // 直接调用存储过程获取数据结果集
            List<Map<String, Object>> records = jdbcTemplate.queryForList(
                "CALL class2_seat27_warehouse_ledger(?, ?)",
                year, materialCode);

            result.put("success", true);
            result.put("data", records);
            result.put("message", "仓库账本查询完成");

            return result;
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "仓库账本数据生成失败: " + e.getMessage());
            return result;
        }
    }
}
