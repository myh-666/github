package com.class2.seat27.server.repository;

import com.class2.seat27.server.entity.InboundDetail;
import com.class2.seat27.server.entity.Inbound;
import com.class2.seat27.server.entity.Material;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InboundDetailRepository extends JpaRepository<InboundDetail, Long> {
    List<InboundDetail> findByInbound(Inbound inbound);

    List<InboundDetail> findByMaterial(Material material);

    @Query("SELECT d FROM InboundDetail d WHERE d.inbound.id = :inboundId")
    List<InboundDetail> findByInboundId(@Param("inboundId") Long inboundId);

    @Query("SELECT d FROM InboundDetail d WHERE d.material.id = :materialId AND d.inbound.status = 'COMPLETED'")
    List<InboundDetail> findCompletedDetailsByMaterialId(@Param("materialId") Long materialId);
    
    @Modifying
    @Query("DELETE FROM InboundDetail d WHERE d.material.id = :materialId")
    void deleteByMaterialId(@Param("materialId") Long materialId);
    
    // 添加根据物料ID查询的方法
    @Query("SELECT d FROM InboundDetail d WHERE d.material.id = :materialId")
    List<InboundDetail> findByMaterialId(@Param("materialId") Long materialId);
}