package com.class2.seat27.server.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "class2_seat27_multi_inout_detail")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class MultiInOutDetail {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "multi_inout_record_id", nullable = false)
    @JsonIgnore // 添加此注解以打破循环引用
    private MultiInOutRecord multiInOutRecord;

    @Column(name = "material_code", nullable = false)
    private String materialCode;

    @Column(name = "material_name", nullable = false)
    private String materialName;

    @Column(name = "specification")
    private String specification;

    @Column(name = "unit", nullable = false)
    private String unit;

    @Column(name = "quantity", nullable = false)
    private Integer quantity;

    @Column(name = "unit_price")
    private BigDecimal unitPrice;

    @Column(name = "total_price")
    private BigDecimal totalPrice;

    private String remark;

    @Column(name = "created_time")
    private LocalDateTime createdTime;

    @Column(name = "updated_time")
    private LocalDateTime updatedTime;

    // 构造器、getter、setter
    public MultiInOutDetail() {
        this.createdTime = LocalDateTime.now();
        this.updatedTime = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public MultiInOutRecord getMultiInOutRecord() { return multiInOutRecord; }
    public void setMultiInOutRecord(MultiInOutRecord multiInOutRecord) {
        this.multiInOutRecord = multiInOutRecord;
    }

    public String getMaterialCode() { return materialCode; }
    public void setMaterialCode(String materialCode) {
        this.materialCode = materialCode;
        this.updatedTime = LocalDateTime.now();
    }

    public String getMaterialName() { return materialName; }
    public void setMaterialName(String materialName) {
        this.materialName = materialName;
        this.updatedTime = LocalDateTime.now();
    }

    public String getSpecification() { return specification; }
    public void setSpecification(String specification) {
        this.specification = specification;
        this.updatedTime = LocalDateTime.now();
    }

    public String getUnit() { return unit; }
    public void setUnit(String unit) {
        this.unit = unit;
        this.updatedTime = LocalDateTime.now();
    }

    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
        this.updatedTime = LocalDateTime.now();
    }

    public BigDecimal getUnitPrice() { return unitPrice; }
    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
        this.updatedTime = LocalDateTime.now();
    }

    public BigDecimal getTotalPrice() { return totalPrice; }
    public void setTotalPrice(BigDecimal totalPrice) {
        this.totalPrice = totalPrice;
        this.updatedTime = LocalDateTime.now();
    }

    public String getRemark() { return remark; }
    public void setRemark(String remark) {
        this.remark = remark;
        this.updatedTime = LocalDateTime.now();
    }

    public LocalDateTime getCreatedTime() { return createdTime; }
    public void setCreatedTime(LocalDateTime createdTime) { this.createdTime = createdTime; }

    public LocalDateTime getUpdatedTime() { return updatedTime; }
    public void setUpdatedTime(LocalDateTime updatedTime) { this.updatedTime = updatedTime; }
}
