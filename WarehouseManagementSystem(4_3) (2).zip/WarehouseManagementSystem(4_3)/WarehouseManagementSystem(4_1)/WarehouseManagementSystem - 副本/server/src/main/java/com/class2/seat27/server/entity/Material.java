package com.class2.seat27.server.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "class2_seat27_material")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Material {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String materialCode;

    @Column(nullable = false)
    private String name;

    private String specification;

    @Column(nullable = false, columnDefinition = "VARCHAR(20) DEFAULT '个'")
    private String unit;  // 可以是任意单位，不限于预定义的常量

    private Integer quantity;

    private String remark;

    @Column(name = "created_time")
    private LocalDateTime createdTime;

    @Column(name = "updated_time")
    private LocalDateTime updatedTime;
    
    private BigDecimal price;
    
    @Column(name = "min_stock")
    private Integer minStock;
    
    // 单位常量定义
    public static final String UNIT_PIECE = "个";
    public static final String UNIT_SET = "套";
    public static final String UNIT_KILOGRAM = "公斤";
    public static final String UNIT_TON = "吨";
    public static final String UNIT_LITER = "升";
    public static final String UNIT_METER = "米";
    public static final String Unit_MILLIMETER = "毫米";
    public static final String UNIT_STRIP = "条";
    public static final String UNIT_UNIT = "台";

    // 构造器、getter、setter
    public Material() {
        this.createdTime = LocalDateTime.now();
        this.updatedTime = LocalDateTime.now();
        this.quantity = 0; // 默认库存数量为0
        this.unit = "个"; // 默认计量单位为"个"
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getMaterialCode() { return materialCode; }
    public void setMaterialCode(String materialCode) {
        this.materialCode = materialCode;
        this.updatedTime = LocalDateTime.now();
    }

    public String getName() { return name; }
    public void setName(String name) {
        this.name = name;
        this.updatedTime = LocalDateTime.now();
    }
    
    public String getMaterialName() {
        return name;
    }

    public String getSpecification() { return specification; }
    public void setSpecification(String specification) {
        this.specification = specification;
        this.updatedTime = LocalDateTime.now();
    }

    public String getUnit() { return unit; }
    public void setUnit(String unit) {
        this.unit = unit;
        this.updatedTime = LocalDateTime.now();
    }

    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) {
        this.quantity = quantity != null ? quantity : 0;
        this.updatedTime = LocalDateTime.now();
    }

    public String getRemark() { return remark; }
    public void setRemark(String remark) {
        this.remark = remark;
        this.updatedTime = LocalDateTime.now();
    }
    
    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) {
        this.price = price;
        this.updatedTime = LocalDateTime.now();
    }
    
    /**
     * 获取物料单价
     * @return 物料单价
     */
    public BigDecimal getUnitPrice() { return price; }
    
    public Integer getMinStock() { return minStock; }
    public void setMinStock(Integer minStock) {
        this.minStock = minStock;
        this.updatedTime = LocalDateTime.now();
    }

    public LocalDateTime getCreatedTime() { return createdTime; }
    public void setCreatedTime(LocalDateTime createdTime) { this.createdTime = createdTime; }

    public LocalDateTime getUpdatedTime() { return updatedTime; }
    public void setUpdatedTime(LocalDateTime updatedTime) { this.updatedTime = updatedTime; }
}
