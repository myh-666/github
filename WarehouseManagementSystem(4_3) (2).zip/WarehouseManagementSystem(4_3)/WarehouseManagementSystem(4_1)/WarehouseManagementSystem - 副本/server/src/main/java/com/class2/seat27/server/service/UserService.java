package com.class2.seat27.server.service;
import com.class2.seat27.server.entity.User;
import com.class2.seat27.server.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.Random;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;


    public User getUserByUsername(String username) {
        return userRepository.findByUsername(username).orElse(null);
    }
    
    public User getUserByPersonnelCode(String personnelCode) {
        return userRepository.findByPersonnelCode(personnelCode).orElse(null);
    }
    
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }


    private String encryptPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] hash = md.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("密码加密失败", e);
        }
    }

    public User login(String username, String password) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            String encryptedPassword = encryptPassword(password);
            if (encryptedPassword.equals(user.getPassword())) {
                return user;
            }
        }
        return null;
    }


    /**
     * 修改用户密码
     * @param username 用户名
     * @param oldPassword 旧密码
     * @param newPassword 新密码
     * @return 修改结果：true成功，false失败
     */
    public boolean changePassword(String username, String oldPassword, String newPassword) {
        try {
            Optional<User> userOpt = userRepository.findByUsername(username);

            if (userOpt.isPresent()) {
                User user = userOpt.get();

                // 验证旧密码是否正确
                String encryptedOldPassword = encryptPassword(oldPassword);
                if (encryptedOldPassword.equals(user.getPassword())) {
                    // 对新密码进行加密后保存
                    String encryptedNewPassword = encryptPassword(newPassword);
                    user.setPassword(encryptedNewPassword);
                    user.setUpdatedTime(LocalDateTime.now());
                    userRepository.save(user);
                    System.out.println("密码更新成功");
                    return true;
                } else {
                    System.out.println("旧密码验证失败");
                }
            } else {
                System.out.println("未找到用户: " + username);
            }
        } catch (Exception e) {
            System.out.println("修改密码过程中发生异常: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("修改密码失败: " + e.getMessage(), e);
        }
        return false;
    }

    /**
     * 用户注册
     * @param username 用户名
     * @param name 姓名
     * @param gender 性别
     * @param password 密码
     * @param idCard 身份证号
     * @return 注册成功的用户对象，如果注册失败则返回null
     */
    public User register(String username, String name, String gender, String password, String idCard) {
        try {
            // 检查用户名是否已存在
            if (userRepository.existsByUsername(username)) {
                System.out.println("用户名已存在: " + username);
                return null;
            }

            // 检查身份证号是否已存在
            if (userRepository.existsByIdCard(idCard)) {
                System.out.println("身份证号已存在: " + idCard);
                return null;
            }

            // 创建新用户
            User user = new User();
            user.setUsername(username);
            user.setName(name);
            user.setGender(User.Gender.valueOf(gender)); // 将字符串转换为枚举
            String encryptedPassword = encryptPassword(password);
            user.setPassword(encryptedPassword);
            user.setIdCard(idCard);
            user.setUserRole(User.UserRole.USER); // 默认角色为USER
            user.setCreatedTime(LocalDateTime.now());
            user.setUpdatedTime(LocalDateTime.now());

            // 自动生成 personnelCode
            String personnelCode = generatePersonnelCode();
            user.setPersonnelCode(personnelCode);
            System.out.println("为用户 " + username + " 生成工号: " + personnelCode);

            // 保存用户
            User savedUser = userRepository.save(user);

            // 新增：为用户自动授予个人管理权限
            grantDefaultPersonalPermissions(savedUser.getId());

            System.out.println("用户注册成功: " + username);
            return savedUser;
        } catch (Exception e) {
            System.out.println("用户注册过程中发生异常: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("用户注册失败: " + e.getMessage(), e);
        }
    }

    /**
     * 为新用户授予默认的个人管理权限
     */
    private void grantDefaultPersonalPermissions(Long userId) {
        try {
            // 这里需要调用权限服务来授予默认权限
            // 由于是服务层内部调用，我们可以直接使用repository
            // 实际项目中可能需要调用PermissionService

            System.out.println("为用户ID: " + userId + " 授予默认个人管理权限");

            // 这里可以添加具体的权限授予逻辑
            // 由于时间关系，这里只是打印日志，实际需要实现具体的权限授予

        } catch (Exception e) {
            System.out.println("授予默认权限失败: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * 生成下一个 personnelCode
     * 基于数据库中最大的 personnel_code 数值部分+1
     */
    private String generatePersonnelCode() {
        // 生成基于时间戳和随机数的代码，例如: P20231201123045001
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        String randomSuffix = String.format("%03d", new Random().nextInt(1000));
        return "P" + timestamp + randomSuffix;
    }
}
