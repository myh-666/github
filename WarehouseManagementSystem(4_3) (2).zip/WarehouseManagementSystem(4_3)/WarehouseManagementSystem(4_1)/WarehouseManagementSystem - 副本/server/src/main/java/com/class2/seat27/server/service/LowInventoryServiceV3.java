
package com.class2.seat27.server.service;

import com.class2.seat27.server.entity.Material;
import com.class2.seat27.server.repository.MaterialRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 低库存预警服务类V3
 * 用于生成低库存预警报表，使用存储过程
 */
@Service
public class LowInventoryServiceV3 {

    @Autowired
    private MaterialRepository materialRepository;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * 生成低库存预警报表
     */
    @Transactional
    public Map<String, Object> generateLowInventoryWarning(LocalDate startDate, LocalDate endDate) {
        Map<String, Object> result = new HashMap<>();

        try {
            // 直接调用存储过程获取低库存预警数据
            List<Map<String, Object>> lowInventoryMaterials = jdbcTemplate.queryForList(
                "CALL class2_seat27_low_inventory_warning(?, ?)",
                startDate, endDate);

            // 输出查询结果
            System.out.println("查询到的低库存物料数量: " + lowInventoryMaterials.size());

            // 确保数据正确处理
            for (Map<String, Object> material : lowInventoryMaterials) {
                // 确保规格不为空
                if (material.get("specification") == null) {
                    material.put("specification", "");
                }

                // 确保最低库存不为空
                if (material.get("min_stock") == null) {
                    material.put("min_stock", 0);
                }

                // 添加阈值字段，用于前端显示
                material.put("threshold", material.get("min_stock"));

                // 添加当前库存字段，用于前端显示
                material.put("quantity", material.get("current_quantity"));
            }

            result.put("success", true);
            result.put("data", lowInventoryMaterials);
            result.put("message", "低库存预警查询完成");
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "低库存预警生成失败: " + e.getMessage());
        }

        return result;
    }
}
