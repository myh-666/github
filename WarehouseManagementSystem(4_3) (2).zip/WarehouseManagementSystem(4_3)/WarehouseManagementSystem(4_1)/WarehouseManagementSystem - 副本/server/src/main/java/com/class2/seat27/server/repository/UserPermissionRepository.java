package com.class2.seat27.server.repository;

import com.class2.seat27.server.entity.UserPermission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserPermissionRepository extends JpaRepository<UserPermission, Long> {

    // 根据用户ID和资源代码查找权限
    Optional<UserPermission> findByUserIdAndResourceCode(Long userId, String resourceCode);

    // 根据用户ID查找所有权限
    List<UserPermission> findByUserId(Long userId);

    // 根据用户ID和授权状态查找权限
    List<UserPermission> findByUserIdAndGranted(Long userId, Boolean granted);

    // 删除用户的所有权限
    @Modifying
    @Query("DELETE FROM UserPermission up WHERE up.userId = :userId")
    void deleteByUserId(@Param("userId") Long userId);

    // 检查用户是否有某个权限
    @Query("SELECT COUNT(up) > 0 FROM UserPermission up WHERE up.userId = :userId AND up.resourceCode = :resourceCode AND up.granted = true")
    boolean hasPermission(@Param("userId") Long userId, @Param("resourceCode") String resourceCode);

    // 批量更新用户权限
    @Modifying
    @Query("UPDATE UserPermission up SET up.granted = :granted, up.updateTime = CURRENT_TIMESTAMP, up.updateUser = :updateUser WHERE up.userId = :userId AND up.resourceCode = :resourceCode")
    int updateUserPermission(@Param("userId") Long userId, @Param("resourceCode") String resourceCode,
                             @Param("granted") Boolean granted, @Param("updateUser") String updateUser);
}