package com.class2.seat27.server.controller;

import com.class2.seat27.server.service.MultiInOutService;
import com.class2.seat27.server.service.UserService;
import com.class2.seat27.server.entity.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 多物料进出仓控制器
 * 处理多物料进出仓相关的API请求
 */
@RestController
@RequestMapping("/api/multi-inout")
@CrossOrigin(origins = "*")
public class MultiInOutController {

    @Autowired
    private MultiInOutService multiInOutService;

    @Autowired
    private UserService userService;

    @Autowired
    private ObjectMapper objectMapper;

    /**
     * 创建并完成多物料进仓单
     */
    @PostMapping("/inbound/create")
    public ResponseEntity<Map<String, Object>> createMultiInbound(@RequestBody Map<String, Object> request) {
        try {
            // 获取当前用户
            System.out.println("服务端接收到的用户名: " + request.get("username")); // 添加调试信息
            System.out.println("服务端接收到的personnel_code: " + request.get("personnel_code")); // 添加调试信息
            String personnelCode = request.get("personnel_code").toString();
            System.out.println("转换后的personnel_code: " + personnelCode); // 添加调试信息
            User currentUser = userService.getUserByPersonnelCode(personnelCode);
            System.out.println("查询到的用户: " + (currentUser != null ? currentUser.getUsername() : "null")); // 添加调试信息
            if (currentUser == null) {
                throw new RuntimeException("用户不存在");
            }

            // 获取单据信息
            Map<String, Object> document = (Map<String, Object>) request.get("document");
            String documentCode = document.get("documentCode") != null ? document.get("documentCode").toString() : "";
            String remark = document.getOrDefault("remark", "").toString();

            // 获取物料明细
            java.util.List<Map<String, Object>> details = (java.util.List<Map<String, Object>>) request.get("details");

            // 调用服务创建多物料进仓单
            Map<String, Object> result = multiInOutService.processMultiInbound(
                    documentCode,
                    personnelCode, // 使用personnelCode而不是username
                    personnelCode, // 使用personnelCode而不是username
                    remark,
                    details
            );

            Map<String, Object> response = new HashMap<>();
            if (Integer.parseInt(result.get("result").toString()) == 1) {
                response.put("success", true);
                response.put("message", "多物料进仓单创建成功");
                response.put("data", result.get("data"));
            } else {
                response.put("success", false);
                response.put("message", result.get("message") != null ? result.get("message").toString() : "多物料进仓单创建失败");
            }

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "多物料进仓单创建失败: " + e.getMessage());
            return ResponseEntity.ok(response);
        }
    }



    /**
     * 创建并完成多物料出仓单
     */
    @PostMapping("/outbound/create")
    public ResponseEntity<Map<String, Object>> createMultiOutbound(@RequestBody Map<String, Object> request) {
        try {
            // 获取当前用户
            System.out.println("服务端接收到的用户名: " + request.get("username")); // 添加调试信息
            System.out.println("服务端接收到的personnel_code: " + request.get("personnel_code")); // 添加调试信息
            String personnelCode = request.get("personnel_code").toString();
            System.out.println("转换后的personnel_code: " + personnelCode); // 添加调试信息
            User currentUser = userService.getUserByPersonnelCode(personnelCode);
            System.out.println("查询到的用户: " + (currentUser != null ? currentUser.getUsername() : "null")); // 添加调试信息
            if (currentUser == null) {
                throw new RuntimeException("用户不存在");
            }

            // 获取单据信息
            Map<String, Object> document = (Map<String, Object>) request.get("document");
            String documentCode = document.get("documentCode") != null ? document.get("documentCode").toString() : "";
            String remark = document.getOrDefault("remark", "").toString();

            // 获取物料明细
            java.util.List<Map<String, Object>> details = (java.util.List<Map<String, Object>>) request.get("details");

            // 调用服务创建多物料出仓单
            Map<String, Object> result = multiInOutService.processMultiOutbound(
                    documentCode,
                    personnelCode, // 使用personnelCode而不是username
                    personnelCode, // 使用personnelCode而不是username
                    remark,
                    details
            );

            Map<String, Object> response = new HashMap<>();
            if (Integer.parseInt(result.get("result").toString()) == 1) {
                response.put("success", true);
                response.put("message", "多物料出仓单创建成功");
                response.put("data", result.get("data"));
            } else {
                response.put("success", false);
                response.put("message", result.get("message") != null ? result.get("message").toString() : "多物料出仓单创建失败");
            }

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "多物料出仓单创建失败: " + e.getMessage());
            return ResponseEntity.ok(response);
        }
    }



    /**
     * 查询多物料进出仓记录
     */
    @GetMapping("/records")
    public ResponseEntity<List<Map<String, Object>>> getMultiInOutRecords(
            @RequestParam(required = false) String type,
            @RequestParam(required = false) String materialCode,
            @RequestParam(required = false) String operatorCode,
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String endDate,
            @RequestParam(required = false) String remark) {
        try {
            List<Map<String, Object>> records = multiInOutService.getMultiInOutRecords(type, materialCode, operatorCode, startDate, endDate, remark);
            return ResponseEntity.ok(records);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }
}
