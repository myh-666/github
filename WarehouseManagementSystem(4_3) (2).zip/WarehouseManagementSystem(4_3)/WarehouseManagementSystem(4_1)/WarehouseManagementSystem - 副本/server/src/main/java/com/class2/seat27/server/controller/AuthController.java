package com.class2.seat27.server.controller;
import com.class2.seat27.server.entity.User;
import com.class2.seat27.server.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*") // 允许所有跨域请求
public class AuthController {
    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody Map<String, String> loginRequest) {
        String username = loginRequest.get("username");
        String password = loginRequest.get("password");

        Map<String, Object> response = new HashMap<>();

        User user = userService.login(username, password);
        if (user != null) {
            response.put("success", true);
            response.put("message", "登录成功");
            response.put("user", user);
        } else {
            response.put("success", false);
            response.put("message", "用户名或密码错误");
        }

        return ResponseEntity.ok(response);
    }

    @PostMapping("/change-password")
    public ResponseEntity<Map<String, Object>> changePassword(@RequestBody Map<String, String> changePwdRequest) {
        String username = changePwdRequest.get("username");
        String oldPassword = changePwdRequest.get("oldPassword");
        String newPassword = changePwdRequest.get("newPassword");

        // 添加日志记录
        System.out.println("修改密码请求 - 用户名: " + username);

        Map<String, Object> response = new HashMap<>();

        try {
            boolean result = userService.changePassword(username, oldPassword, newPassword);
            if (result) {
                response.put("success", true);
                response.put("message", "密码修改成功");
            } else {
                response.put("success", false);
                response.put("message", "旧密码错误或用户不存在");
            }
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "服务器处理异常: " + e.getMessage());
            e.printStackTrace();
        }

        return ResponseEntity.ok(response);
    }

    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> register(@RequestBody Map<String, Object> registerRequest) {
        String username = (String) registerRequest.get("username");
        String name = (String) registerRequest.get("name");
        String gender = (String) registerRequest.get("gender");
        String password = (String) registerRequest.get("password");
        String idCard = (String) registerRequest.get("idCard");

        // 添加日志记录
        System.out.println("注册请求 - 用户名: " + username);

        Map<String, Object> response = new HashMap<>();

        try {
            User user = userService.register(username, name, gender, password, idCard);
            if (user != null) {
                response.put("success", true);
                response.put("message", "注册成功");
            } else {
                response.put("success", false);
                response.put("message", "注册失败，用户名或身份证号已存在");
            }
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "服务器处理异常: " + e.getMessage());
            e.printStackTrace();
        }

        return ResponseEntity.ok(response);
    }

}
