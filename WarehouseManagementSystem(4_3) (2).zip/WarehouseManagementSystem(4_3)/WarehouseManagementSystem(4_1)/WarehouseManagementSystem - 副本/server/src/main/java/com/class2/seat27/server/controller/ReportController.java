package com.class2.seat27.server.controller;

import com.class2.seat27.server.entity.Material;
import com.class2.seat27.server.repository.MaterialRepository;
import com.class2.seat27.server.service.ReportService;
import com.class2.seat27.server.service.LowInventoryServiceV3;
import com.class2.seat27.server.service.ReportServiceNewFixed;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

/**
 * 报表控制器
 * 处理各种报表的生成和导出请求
 */
@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins = "*")
public class ReportController {

    @Autowired
    private ReportServiceNewFixed reportService;

    @Autowired
    private MaterialRepository materialRepository;

    @Autowired
    private LowInventoryServiceV3 lowInventoryService;

    @Autowired
    private ObjectMapper objectMapper;

    /**
     * 生成物料流量统计
     */
    @PostMapping("/material-flow")
    public ResponseEntity<Map<String, Object>> generateMaterialFlowStatistics(
            @RequestBody Map<String, Object> request) {
        try {
            LocalDate startDate = LocalDate.parse(request.get("startDate").toString());
            LocalDate endDate = LocalDate.parse(request.get("endDate").toString());

            // 使用存储过程生成物料统计数据
            Map<String, Object> result = reportService.getMaterialStatisticsByProcedure(startDate, endDate);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "物料流量统计失败: " + e.getMessage());
            return ResponseEntity.ok(response);
        }
    }

    /**
     * 生成月度进出仓单报表
     */
    @PostMapping("/monthly-records")
    public ResponseEntity<Map<String, Object>> generateMonthlyRecords(
            @RequestBody Map<String, Object> request) {
        try {
            int year = Integer.parseInt(request.get("year").toString());
            int month = Integer.parseInt(request.get("month").toString());

            // 使用存储过程生成月度进出仓单数据
            Map<String, Object> result = reportService.getMonthlyRecordsByProcedure(year, month);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "月度进出仓单报表生成失败: " + e.getMessage());
            return ResponseEntity.ok(response);
        }
    }

    /**
     * 生成仓库账本
     */
    @PostMapping("/warehouse-ledger")
    public ResponseEntity<Map<String, Object>> generateWarehouseLedger(
            @RequestBody Map<String, Object> request) {
        try {
            String materialCode = request.get("materialCode").toString();
            int year = Integer.parseInt(request.get("year").toString());

            // 使用存储过程生成仓库账本数据
            Map<String, Object> result = reportService.getWarehouseLedgerByProcedure(year, materialCode);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "仓库账本生成失败: " + e.getMessage());
            return ResponseEntity.ok(response);
        }
    }

    /**
     * 生成低库存预警报表
     */
    @PostMapping("/low-inventory")
    public ResponseEntity<Map<String, Object>> generateLowInventoryWarning(
            @RequestBody Map<String, Object> request) {
        try {
            LocalDate startDate = LocalDate.parse(request.get("startDate").toString());
            LocalDate endDate = LocalDate.parse(request.get("endDate").toString());

            // 直接使用LowInventoryServiceV2，避免使用ReportService中的模拟数据
            System.out.println("调用LowInventoryServiceV2生成低库存预警报表");
            Map<String, Object> result = lowInventoryService.generateLowInventoryWarning(startDate, endDate);
            System.out.println("低库存预警报表生成结果: " + result.toString());
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "低库存预警生成失败: " + e.getMessage());
            return ResponseEntity.ok(response);
        }
    }

    /**
     * 新的低库存预警API端点
     */
    @PostMapping("/low-inventory-new")
    public ResponseEntity<Map<String, Object>> generateLowInventoryWarningNew(
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate) {
        try {
            System.out.println("调用新的低库存预警API");
            Map<String, Object> result = lowInventoryService.generateLowInventoryWarning(startDate, endDate);
            System.out.println("新的低库存预警API结果: " + result.toString());
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "低库存预警生成失败: " + e.getMessage());
            return ResponseEntity.ok(response);
        }
    }

    /**
     * 导出物料统计报表到Excel
     */
    @GetMapping("/export/material-flow")
    public ResponseEntity<byte[]> exportMaterialFlowToExcel(
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate) {
        try {
            // 获取物料统计数据
            Map<String, Object> result = reportService.getMaterialStatisticsByProcedure(startDate, endDate);

            if (!(Boolean) result.get("success")) {
                throw new RuntimeException(result.get("message").toString());
            }

            @SuppressWarnings("unchecked")
            java.util.List<Map<String, Object>> materialData = (java.util.List<Map<String, Object>>) result.get("data");

            // 创建Excel工作簿
            org.apache.poi.ss.usermodel.Workbook workbook = new org.apache.poi.xssf.usermodel.XSSFWorkbook();
            org.apache.poi.ss.usermodel.Sheet sheet = workbook.createSheet("物料统计");

            // 创建标题行
            org.apache.poi.ss.usermodel.Row headerRow = sheet.createRow(0);
            String[] headers = {"物料代码", "物料名称", "规格", "单位", "当前库存",
                    "进仓数量", "进仓金额", "出仓数量", "出仓金额", "净流量", "净金额"};

            // 创建样式
            org.apache.poi.ss.usermodel.CellStyle headerStyle = workbook.createCellStyle();
            org.apache.poi.ss.usermodel.Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);
            headerStyle.setAlignment(org.apache.poi.ss.usermodel.HorizontalAlignment.CENTER);

            // 添加边框
            headerStyle.setBorderTop(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            headerStyle.setBorderBottom(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            headerStyle.setBorderLeft(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            headerStyle.setBorderRight(org.apache.poi.ss.usermodel.BorderStyle.THIN);

            for (int i = 0; i < headers.length; i++) {
                org.apache.poi.ss.usermodel.Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // 创建数据行样式
            org.apache.poi.ss.usermodel.CellStyle dataStyle = workbook.createCellStyle();
            dataStyle.setBorderTop(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            dataStyle.setBorderBottom(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            dataStyle.setBorderLeft(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            dataStyle.setBorderRight(org.apache.poi.ss.usermodel.BorderStyle.THIN);

            // 填充数据
            int rowNum = 1;
            for (Map<String, Object> record : materialData) {
                org.apache.poi.ss.usermodel.Row row = sheet.createRow(rowNum++);

                org.apache.poi.ss.usermodel.Cell cell0 = row.createCell(0);
                cell0.setCellValue(record.get("material_code") != null ? record.get("material_code").toString() : "");
                cell0.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell1 = row.createCell(1);
                cell1.setCellValue(record.get("material_name") != null ? record.get("material_name").toString() : "");
                cell1.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell2 = row.createCell(2);
                cell2.setCellValue(record.get("specification") != null ? record.get("specification").toString() : "");
                cell2.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell3 = row.createCell(3);
                cell3.setCellValue(record.get("unit") != null ? record.get("unit").toString() : "");
                cell3.setCellStyle(dataStyle);

                // 处理数字类型
                org.apache.poi.ss.usermodel.Cell cell4 = row.createCell(4);
                if (record.get("current_quantity") != null) {
                    cell4.setCellValue(((Number) record.get("current_quantity")).intValue());
                } else {
                    cell4.setCellValue(0);
                }
                cell4.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell5 = row.createCell(5);
                if (record.get("inbound_quantity") != null) {
                    cell5.setCellValue(((Number) record.get("inbound_quantity")).intValue());
                } else {
                    cell5.setCellValue(0);
                }
                cell5.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell6 = row.createCell(6);
                if (record.get("inbound_amount") != null) {
                    cell6.setCellValue(((Number) record.get("inbound_amount")).doubleValue());
                } else {
                    cell6.setCellValue(0);
                }
                cell6.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell7 = row.createCell(7);
                if (record.get("outbound_quantity") != null) {
                    cell7.setCellValue(((Number) record.get("outbound_quantity")).intValue());
                } else {
                    cell7.setCellValue(0);
                }
                cell7.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell8 = row.createCell(8);
                if (record.get("outbound_amount") != null) {
                    cell8.setCellValue(((Number) record.get("outbound_amount")).doubleValue());
                } else {
                    cell8.setCellValue(0);
                }
                cell8.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell9 = row.createCell(9);
                if (record.get("net_flow") != null) {
                    cell9.setCellValue(((Number) record.get("net_flow")).intValue());
                } else {
                    cell9.setCellValue(0);
                }
                cell9.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell10 = row.createCell(10);
                if (record.get("net_amount") != null) {
                    cell10.setCellValue(((Number) record.get("net_amount")).doubleValue());
                } else {
                    cell10.setCellValue(0);
                }
                cell10.setCellStyle(dataStyle);
            }

            // 自动调整列宽
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
                // 设置最小列宽，确保内容可完全显示
                if (sheet.getColumnWidth(i) < 20 * 256) {
                    sheet.setColumnWidth(i, 20 * 256);
                }
            }

            // 将工作簿写入字节数组
            java.io.ByteArrayOutputStream outputStream = new java.io.ByteArrayOutputStream();
            workbook.write(outputStream);
            workbook.close();

            byte[] bytes = outputStream.toByteArray();

            // 设置响应头
            String fileName = "物料统计_" + startDate + "_" + endDate + ".xlsx";
            String encodedFileName = java.net.URLEncoder.encode(fileName, "UTF-8");

            return ResponseEntity.ok()
                    .header("Content-Disposition", "attachment; filename=\"" + encodedFileName + "\"")
                    .contentType(org.springframework.http.MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    .body(bytes);

        } catch (Exception e) {
            throw new RuntimeException("导出失败: " + e.getMessage());
        }
    }

    /**
     * 导出月度进出仓单到Excel
     */
    @GetMapping("/export/monthly-records")
    public ResponseEntity<byte[]> exportMonthlyRecordsToExcel(
            @RequestParam int year,
            @RequestParam int month) {
        try {
            // 获取月度进出仓单数据
            Map<String, Object> result = reportService.getMonthlyRecordsByProcedure(year, month);

            if (!(Boolean) result.get("success")) {
                throw new RuntimeException(result.get("message").toString());
            }

            @SuppressWarnings("unchecked")
            java.util.List<Map<String, Object>> monthlyData = (java.util.List<Map<String, Object>>) result.get("data");

            // 创建Excel工作簿
            org.apache.poi.ss.usermodel.Workbook workbook = new org.apache.poi.xssf.usermodel.XSSFWorkbook();
            org.apache.poi.ss.usermodel.Sheet sheet = workbook.createSheet("月度进出仓单");

            // 创建标题行
            org.apache.poi.ss.usermodel.Row headerRow = sheet.createRow(0);
            String[] headers = {"记录ID", "单据编号", "操作类型", "操作日期", "操作人编码", "操作人姓名",
                    "经手人编码", "经手人姓名", "备注", "状态", "物料ID", "物料编码", "物料名称",
                    "规格", "单位", "数量", "单价", "总价", "物料备注"};

            // 创建样式
            org.apache.poi.ss.usermodel.CellStyle headerStyle = workbook.createCellStyle();
            org.apache.poi.ss.usermodel.Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);
            headerStyle.setAlignment(org.apache.poi.ss.usermodel.HorizontalAlignment.CENTER);

            // 添加边框
            headerStyle.setBorderTop(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            headerStyle.setBorderBottom(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            headerStyle.setBorderLeft(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            headerStyle.setBorderRight(org.apache.poi.ss.usermodel.BorderStyle.THIN);

            for (int i = 0; i < headers.length; i++) {
                org.apache.poi.ss.usermodel.Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // 创建数据行样式
            org.apache.poi.ss.usermodel.CellStyle dataStyle = workbook.createCellStyle();
            dataStyle.setBorderTop(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            dataStyle.setBorderBottom(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            dataStyle.setBorderLeft(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            dataStyle.setBorderRight(org.apache.poi.ss.usermodel.BorderStyle.THIN);

            // 填充数据
            int rowNum = 1;
            for (Map<String, Object> record : monthlyData) {
                org.apache.poi.ss.usermodel.Row row = sheet.createRow(rowNum++);

                org.apache.poi.ss.usermodel.Cell cell0 = row.createCell(0);
                cell0.setCellValue(record.get("record_id") != null ? record.get("record_id").toString() : "");
                cell0.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell1 = row.createCell(1);
                cell1.setCellValue(record.get("document_code") != null ? record.get("document_code").toString() : "");
                cell1.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell2 = row.createCell(2);
                cell2.setCellValue(record.get("operation_type") != null ? record.get("operation_type").toString() : "");
                cell2.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell3 = row.createCell(3);
                cell3.setCellValue(record.get("operation_date") != null ? record.get("operation_date").toString() : "");
                cell3.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell4 = row.createCell(4);
                cell4.setCellValue(record.get("operator_code") != null ? record.get("operator_code").toString() : "");
                cell4.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell5 = row.createCell(5);
                cell5.setCellValue(record.get("operator_name") != null ? record.get("operator_name").toString() : "");
                cell5.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell6 = row.createCell(6);
                cell6.setCellValue(record.get("handler_code") != null ? record.get("handler_code").toString() : "");
                cell6.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell7 = row.createCell(7);
                cell7.setCellValue(record.get("handler_name") != null ? record.get("handler_name").toString() : "");
                cell7.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell8 = row.createCell(8);
                cell8.setCellValue(record.get("remark") != null ? record.get("remark").toString() : "");
                cell8.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell9 = row.createCell(9);
                cell9.setCellValue(record.get("status") != null ? record.get("status").toString() : "");
                cell9.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell10 = row.createCell(10);
                cell10.setCellValue(record.get("material_id") != null ? record.get("material_id").toString() : "");
                cell10.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell11 = row.createCell(11);
                cell11.setCellValue(record.get("material_code") != null ? record.get("material_code").toString() : "");
                cell11.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell12 = row.createCell(12);
                cell12.setCellValue(record.get("material_name") != null ? record.get("material_name").toString() : "");
                cell12.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell13 = row.createCell(13);
                cell13.setCellValue(record.get("specification") != null ? record.get("specification").toString() : "");
                cell13.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell14 = row.createCell(14);
                cell14.setCellValue(record.get("unit") != null ? record.get("unit").toString() : "");
                cell14.setCellStyle(dataStyle);

                // 处理数字类型
                org.apache.poi.ss.usermodel.Cell cell15 = row.createCell(15);
                if (record.get("quantity") != null) {
                    cell15.setCellValue(((Number) record.get("quantity")).intValue());
                } else {
                    cell15.setCellValue(0);
                }
                cell15.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell16 = row.createCell(16);
                if (record.get("unit_price") != null) {
                    cell16.setCellValue(((Number) record.get("unit_price")).doubleValue());
                } else {
                    cell16.setCellValue(0);
                }
                cell16.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell17 = row.createCell(17);
                if (record.get("total_price") != null) {
                    cell17.setCellValue(((Number) record.get("total_price")).doubleValue());
                } else {
                    cell17.setCellValue(0);
                }
                cell17.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell18 = row.createCell(18);
                cell18.setCellValue(record.get("material_remark") != null ? record.get("material_remark").toString() : "");
                cell18.setCellStyle(dataStyle);
            }

            // 自动调整列宽
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
                // 设置最小列宽，确保内容可完全显示
                if (sheet.getColumnWidth(i) < 20 * 256) {
                    sheet.setColumnWidth(i, 20 * 256);
                }
            }

            // 将工作簿写入字节数组
            java.io.ByteArrayOutputStream outputStream = new java.io.ByteArrayOutputStream();
            workbook.write(outputStream);
            workbook.close();

            byte[] bytes = outputStream.toByteArray();

            // 设置响应头
            String fileName = "月度进出仓单_" + year + "_" + month + ".xlsx";
            String encodedFileName = java.net.URLEncoder.encode(fileName, "UTF-8");

            return ResponseEntity.ok()
                    .header("Content-Disposition", "attachment; filename=\"" + encodedFileName + "\"")
                    .contentType(org.springframework.http.MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    .body(bytes);

        } catch (Exception e) {
            throw new RuntimeException("导出失败: " + e.getMessage());
        }
    }

    /**
     * 导出仓库账本到Excel
     */
    @GetMapping("/export/warehouse-ledger")
    public ResponseEntity<byte[]> exportWarehouseLedgerToExcel(
            @RequestParam String materialCode,
            @RequestParam int year) {
        try {
            // 获取仓库账本数据
            Map<String, Object> result = reportService.getWarehouseLedgerByProcedure(year, materialCode);

            if (!(Boolean) result.get("success")) {
                throw new RuntimeException(result.get("message").toString());
            }

            @SuppressWarnings("unchecked")
            java.util.List<Map<String, Object>> ledgerData = (java.util.List<Map<String, Object>>) result.get("data");

            // 创建Excel工作簿
            org.apache.poi.ss.usermodel.Workbook workbook = new org.apache.poi.xssf.usermodel.XSSFWorkbook();
            org.apache.poi.ss.usermodel.Sheet sheet = workbook.createSheet("仓库账本");

            // 创建标题行
            org.apache.poi.ss.usermodel.Row headerRow = sheet.createRow(0);
            String[] headers = {"账本日期", "单据编号", "操作类型", "物料编码", "物料名称", "规格", "单位",
                    "入库数量", "入库金额", "出库数量", "出库金额", "结余数量", "结余金额", "备注"};

            // 创建样式
            org.apache.poi.ss.usermodel.CellStyle headerStyle = workbook.createCellStyle();
            org.apache.poi.ss.usermodel.Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);
            headerStyle.setAlignment(org.apache.poi.ss.usermodel.HorizontalAlignment.CENTER);

            // 添加边框
            headerStyle.setBorderTop(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            headerStyle.setBorderBottom(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            headerStyle.setBorderLeft(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            headerStyle.setBorderRight(org.apache.poi.ss.usermodel.BorderStyle.THIN);

            for (int i = 0; i < headers.length; i++) {
                org.apache.poi.ss.usermodel.Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // 创建数据行样式
            org.apache.poi.ss.usermodel.CellStyle dataStyle = workbook.createCellStyle();
            dataStyle.setBorderTop(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            dataStyle.setBorderBottom(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            dataStyle.setBorderLeft(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            dataStyle.setBorderRight(org.apache.poi.ss.usermodel.BorderStyle.THIN);

            // 填充数据
            int rowNum = 1;
            for (Map<String, Object> record : ledgerData) {
                org.apache.poi.ss.usermodel.Row row = sheet.createRow(rowNum++);

                org.apache.poi.ss.usermodel.Cell cell0 = row.createCell(0);
                cell0.setCellValue(record.get("ledger_date") != null ? record.get("ledger_date").toString() : "");
                cell0.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell1 = row.createCell(1);
                cell1.setCellValue(record.get("document_code") != null ? record.get("document_code").toString() : "");
                cell1.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell2 = row.createCell(2);
                cell2.setCellValue(record.get("operation_type") != null ? record.get("operation_type").toString() : "");
                cell2.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell3 = row.createCell(3);
                cell3.setCellValue(record.get("material_code") != null ? record.get("material_code").toString() : "");
                cell3.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell4 = row.createCell(4);
                cell4.setCellValue(record.get("material_name") != null ? record.get("material_name").toString() : "");
                cell4.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell5 = row.createCell(5);
                cell5.setCellValue(record.get("specification") != null ? record.get("specification").toString() : "");
                cell5.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell6 = row.createCell(6);
                cell6.setCellValue(record.get("unit") != null ? record.get("unit").toString() : "");
                cell6.setCellStyle(dataStyle);

                // 处理数字类型
                org.apache.poi.ss.usermodel.Cell cell7 = row.createCell(7);
                if (record.get("in_quantity") != null) {
                    cell7.setCellValue(((Number) record.get("in_quantity")).intValue());
                } else {
                    cell7.setCellValue(0);
                }
                cell7.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell8 = row.createCell(8);
                if (record.get("in_amount") != null) {
                    cell8.setCellValue(((Number) record.get("in_amount")).doubleValue());
                } else {
                    cell8.setCellValue(0);
                }
                cell8.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell9 = row.createCell(9);
                if (record.get("out_quantity") != null) {
                    cell9.setCellValue(((Number) record.get("out_quantity")).intValue());
                } else {
                    cell9.setCellValue(0);
                }
                cell9.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell10 = row.createCell(10);
                if (record.get("out_amount") != null) {
                    cell10.setCellValue(((Number) record.get("out_amount")).doubleValue());
                } else {
                    cell10.setCellValue(0);
                }
                cell10.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell11 = row.createCell(11);
                if (record.get("balance_quantity") != null) {
                    cell11.setCellValue(((Number) record.get("balance_quantity")).intValue());
                } else {
                    cell11.setCellValue(0);
                }
                cell11.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell12 = row.createCell(12);
                if (record.get("balance_amount") != null) {
                    cell12.setCellValue(((Number) record.get("balance_amount")).doubleValue());
                } else {
                    cell12.setCellValue(0);
                }
                cell12.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell13 = row.createCell(13);
                cell13.setCellValue(record.get("remark") != null ? record.get("remark").toString() : "");
                cell13.setCellStyle(dataStyle);
            }

            // 自动调整列宽
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
                // 设置最小列宽，确保内容可完全显示
                if (sheet.getColumnWidth(i) < 20 * 256) {
                    sheet.setColumnWidth(i, 20 * 256);
                }
            }

            // 将工作簿写入字节数组
            java.io.ByteArrayOutputStream outputStream = new java.io.ByteArrayOutputStream();
            workbook.write(outputStream);
            workbook.close();

            byte[] bytes = outputStream.toByteArray();

            // 设置响应头
            String fileName = "仓库账本_" + materialCode + "_" + year + ".xlsx";
            String encodedFileName = java.net.URLEncoder.encode(fileName, "UTF-8");

            return ResponseEntity.ok()
                    .header("Content-Disposition", "attachment; filename=\"" + encodedFileName + "\"")
                    .contentType(org.springframework.http.MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    .body(bytes);

        } catch (Exception e) {
            throw new RuntimeException("导出失败: " + e.getMessage());
        }
    }

    /**
     * 导出低库存预警到Excel
     */
    @GetMapping("/export/low-inventory")
    public ResponseEntity<byte[]> exportLowInventoryToExcel(
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate) {
        try {
            // 获取低库存预警数据
            Map<String, Object> result = lowInventoryService.generateLowInventoryWarning(startDate, endDate);

            if (!(Boolean) result.get("success")) {
                throw new RuntimeException(result.get("message").toString());
            }

            @SuppressWarnings("unchecked")
            java.util.List<Map<String, Object>> lowInventoryData = (java.util.List<Map<String, Object>>) result.get("data");

            // 创建Excel工作簿
            org.apache.poi.ss.usermodel.Workbook workbook = new org.apache.poi.xssf.usermodel.XSSFWorkbook();
            org.apache.poi.ss.usermodel.Sheet sheet = workbook.createSheet("低库存预警");

            // 创建标题行
            org.apache.poi.ss.usermodel.Row headerRow = sheet.createRow(0);
            String[] headers = {"物料代码", "物料名称", "规格", "单位", "当前库存",
                    "最低库存", "库存状态", "预警级别"};

            // 创建样式
            org.apache.poi.ss.usermodel.CellStyle headerStyle = workbook.createCellStyle();
            org.apache.poi.ss.usermodel.Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);
            headerStyle.setAlignment(org.apache.poi.ss.usermodel.HorizontalAlignment.CENTER);

            // 添加边框
            headerStyle.setBorderTop(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            headerStyle.setBorderBottom(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            headerStyle.setBorderLeft(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            headerStyle.setBorderRight(org.apache.poi.ss.usermodel.BorderStyle.THIN);

            for (int i = 0; i < headers.length; i++) {
                org.apache.poi.ss.usermodel.Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // 创建数据行样式
            org.apache.poi.ss.usermodel.CellStyle dataStyle = workbook.createCellStyle();
            dataStyle.setBorderTop(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            dataStyle.setBorderBottom(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            dataStyle.setBorderLeft(org.apache.poi.ss.usermodel.BorderStyle.THIN);
            dataStyle.setBorderRight(org.apache.poi.ss.usermodel.BorderStyle.THIN);

            // 填充数据
            int rowNum = 1;
            for (Map<String, Object> record : lowInventoryData) {
                org.apache.poi.ss.usermodel.Row row = sheet.createRow(rowNum++);

                org.apache.poi.ss.usermodel.Cell cell0 = row.createCell(0);
                cell0.setCellValue(record.get("material_code") != null ? record.get("material_code").toString() : "");
                cell0.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell1 = row.createCell(1);
                cell1.setCellValue(record.get("material_name") != null ? record.get("material_name").toString() : "");
                cell1.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell2 = row.createCell(2);
                cell2.setCellValue(record.get("specification") != null ? record.get("specification").toString() : "");
                cell2.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell3 = row.createCell(3);
                cell3.setCellValue(record.get("unit") != null ? record.get("unit").toString() : "");
                cell3.setCellStyle(dataStyle);

                // 处理数字类型
                org.apache.poi.ss.usermodel.Cell cell4 = row.createCell(4);
                if (record.get("current_quantity") != null) {
                    cell4.setCellValue(((Number) record.get("current_quantity")).intValue());
                } else {
                    cell4.setCellValue(0);
                }
                cell4.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell5 = row.createCell(5);
                if (record.get("min_stock") != null) {
                    cell5.setCellValue(((Number) record.get("min_stock")).intValue());
                } else {
                    cell5.setCellValue(0);
                }
                cell5.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell6 = row.createCell(6);
                cell6.setCellValue(record.get("stock_status") != null ? record.get("stock_status").toString() : "");
                cell6.setCellStyle(dataStyle);

                org.apache.poi.ss.usermodel.Cell cell7 = row.createCell(7);
                cell7.setCellValue(record.get("warning_level") != null ? record.get("warning_level").toString() : "");
                cell7.setCellStyle(dataStyle);
            }

            // 自动调整列宽
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
                // 设置最小列宽，确保内容可完全显示
                if (sheet.getColumnWidth(i) < 20 * 256) {
                    sheet.setColumnWidth(i, 20 * 256);
                }
            }

            // 将工作簿写入字节数组
            java.io.ByteArrayOutputStream outputStream = new java.io.ByteArrayOutputStream();
            workbook.write(outputStream);
            workbook.close();

            byte[] bytes = outputStream.toByteArray();

            // 设置响应头
            String fileName = "低库存预警_" + startDate + "_" + endDate + ".xlsx";
            String encodedFileName = java.net.URLEncoder.encode(fileName, "UTF-8");

            return ResponseEntity.ok()
                    .header("Content-Disposition", "attachment; filename=\"" + encodedFileName + "\"")
                    .contentType(org.springframework.http.MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    .body(bytes);

        } catch (Exception e) {
            throw new RuntimeException("导出失败: " + e.getMessage());
        }
    }
}