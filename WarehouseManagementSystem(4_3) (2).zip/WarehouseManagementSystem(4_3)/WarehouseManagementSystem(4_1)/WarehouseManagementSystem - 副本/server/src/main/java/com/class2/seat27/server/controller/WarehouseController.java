package com.class2.seat27.server.controller;

import com.class2.seat27.server.entity.Inventory;
import com.class2.seat27.server.entity.Material;
import com.class2.seat27.server.entity.Status;
import com.class2.seat27.server.repository.InventoryRepository;
import com.class2.seat27.server.repository.MaterialRepository;
import com.class2.seat27.server.service.WarehouseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * 仓库控制器
 * 处理仓库相关的API请求
 */
@RestController
@RequestMapping("/api/warehouse")
@CrossOrigin(origins = "*")
public class WarehouseController {

    @Autowired
    private WarehouseService warehouseService;

    @Autowired
    private MaterialRepository materialRepository;

    @Autowired
    private InventoryRepository inventoryRepository;

    /**
     * 获取物料单价
     */
    @GetMapping("/material/price")
    public ResponseEntity<Map<String, Object>> getMaterialPrice(@RequestParam Long materialId) {
        Map<String, Object> response = new HashMap<>();
        try {
            // 通过物料ID获取物料，然后获取其价格
            Optional<Material> materialOpt = materialRepository.findById(materialId);
            if (materialOpt.isPresent()) {
                BigDecimal price = materialOpt.get().getPrice();
                response.put("success", true);
                response.put("price", price != null ? price : BigDecimal.ZERO);
            } else {
                response.put("success", false);
                response.put("message", "物料不存在");
            }
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return ResponseEntity.ok(response);
    }

    /**
     * 检查库存是否充足
     */
    @GetMapping("/inventory/check")
    public ResponseEntity<Map<String, Object>> checkInventory(@RequestParam Long materialId, @RequestParam int quantity) {
        Map<String, Object> response = new HashMap<>();
        try {
            Optional<Inventory> inventoryOpt = inventoryRepository.findByMaterialId(materialId);
            int currentQuantity = inventoryOpt.isPresent() ? inventoryOpt.get().getQuantity() : 0;

            if (currentQuantity >= quantity) {
                response.put("success", true);
                response.put("sufficient", true);
                response.put("message", "库存充足");
            } else {
                Optional<Material> materialOpt = materialRepository.findById(materialId);
                String materialName = materialOpt.isPresent() ? materialOpt.get().getName() : "未知物料";
                response.put("success", true);
                response.put("sufficient", false);
                response.put("message", "物料 " + materialName + " 库存不足，当前库存: " + currentQuantity + "，需要: " + quantity);
            }
        } catch (Exception e) {
            response.put("success", false);
            response.put("sufficient", false);
            response.put("message", "检查库存失败: " + e.getMessage());
        }
        return ResponseEntity.ok(response);
    }

    /**
     * 获取低库存物料列表
     * 如果没有提供阈值参数，则返回当前库存小于最低库存的物料
     */
    @GetMapping("/inventories/low-stock")
    public ResponseEntity<Map<String, Object>> getLowStockInventories(@RequestParam(required = false) BigDecimal threshold) {
        Map<String, Object> response = new HashMap<>();
        try {
            List<Inventory> lowStockInventories;

            if (threshold == null) {
                // 返回当前库存小于最低库存的物料
                lowStockInventories = inventoryRepository.findLowStockInventories();
            } else {
                // 根据指定阈值返回低库存物料
                lowStockInventories = inventoryRepository.findLowStockInventories(threshold);
            }

            // 转换为包含详细信息的列表
            List<Map<String, Object>> result = warehouseService.getAllInventoryWithDetails(lowStockInventories);

            response.put("success", true);
            response.put("data", result);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "获取低库存列表失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * 单物料进仓
     */
    @PostMapping("/inbound/single")
    public ResponseEntity<Map<String, Object>> singleInbound(@RequestBody Map<String, Object> request) {
        try {
            String materialCode = request.get("materialCode").toString();
            int quantity = Integer.parseInt(request.get("quantity").toString());
            String remark = request.getOrDefault("remark", "").toString();
            String username = request.get("username").toString();

            // 通过物料编码获取物料
            Optional<Material> materialOpt = materialRepository.findByMaterialCode(materialCode);
            if (!materialOpt.isPresent()) {
                Map<String, Object> response = new HashMap<>();
                response.put("success", false);
                response.put("message", "物料不存在");
                return ResponseEntity.ok(response);
            }

            Material material = materialOpt.get();
            BigDecimal unitPrice = material.getPrice() != null ? material.getPrice() : BigDecimal.ZERO;
            BigDecimal totalPrice = unitPrice.multiply(new BigDecimal(quantity));

            Map<String, Object> result = warehouseService.processSingleInbound(
                    material.getId(), quantity, unitPrice, totalPrice, username, username, remark);

            Map<String, Object> response = new HashMap<>();
            if (Integer.parseInt(result.get("result").toString()) == 1) {
                response.put("success", true);
                response.put("message", "进仓成功，库存已更新");
                response.put("data", result.get("data"));
            } else {
                response.put("success", false);
                response.put("message", result.get("message") != null ? result.get("message").toString() : "进仓失败");
            }

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "进仓失败: " + e.getMessage());
            return ResponseEntity.ok(response);
        }
    }

    /**
     * 单物料出仓
     */
    @PostMapping("/outbound/single")
    public ResponseEntity<Map<String, Object>> singleOutbound(@RequestBody Map<String, Object> request) {
        try {
            String materialCode = request.get("materialCode").toString();
            int quantity = Integer.parseInt(request.get("quantity").toString());
            String remark = request.getOrDefault("remark", "").toString();
            String username = request.get("username").toString();

            // 通过物料编码获取物料
            Optional<Material> materialOpt = materialRepository.findByMaterialCode(materialCode);
            if (!materialOpt.isPresent()) {
                Map<String, Object> response = new HashMap<>();
                response.put("success", false);
                response.put("message", "物料不存在");
                return ResponseEntity.ok(response);
            }

            Material material = materialOpt.get();
            BigDecimal unitPrice = material.getPrice() != null ? material.getPrice() : BigDecimal.ZERO;
            BigDecimal totalPrice = unitPrice.multiply(new BigDecimal(quantity));

            Map<String, Object> result = warehouseService.processSingleOutbound(
                    material.getId(), quantity, unitPrice, totalPrice, username, username, remark);

            Map<String, Object> response = new HashMap<>();
            if (Integer.parseInt(result.get("result").toString()) == 1) {
                response.put("success", true);
                response.put("message", "出仓成功，库存已更新");
                response.put("data", result.get("data"));
            } else {
                response.put("success", false);
                response.put("message", result.get("message") != null ? result.get("message").toString() : "出仓失败");
            }

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "出仓失败: " + e.getMessage());
            return ResponseEntity.ok(response);
        }
    }

    /**
     * 进出仓单查询
     */
    @GetMapping("/inout/all")
    public ResponseEntity<Map<String, Object>> queryInOutRecords(
            @RequestParam String startDate,
            @RequestParam String endDate,
            @RequestParam(required = false) String materialCode,
            @RequestParam(required = false) String operatorCode,
            @RequestParam(required = false) String operationType,
            @RequestParam(required = false) String remark) {
        Map<String, Object> response = new HashMap<>();
        try {
            Map<String, Object> result = warehouseService.queryInOutRecords(
                    startDate, endDate, materialCode, operatorCode, operationType, remark);

            if (Integer.parseInt(result.get("result").toString()) == 1) {
                response.put("success", true);
                response.put("data", result.get("data"));
            } else {
                response.put("success", false);
                response.put("message", result.get("message") != null ? result.get("message").toString() : "查询失败");
            }
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "查询失败: " + e.getMessage());
            return ResponseEntity.ok(response);
        }
    }

    /**
     * 进仓单查询
     */
    @GetMapping("/inbound")
    public ResponseEntity<Map<String, Object>> queryInboundRecords(
            @RequestParam String startDate,
            @RequestParam String endDate,
            @RequestParam(required = false) String materialCode,
            @RequestParam(required = false) String operatorCode,
            @RequestParam(required = false) String remark) {
        Map<String, Object> response = new HashMap<>();
        try {
            Map<String, Object> result = warehouseService.queryInOutRecords(
                    startDate, endDate, materialCode, operatorCode, "INBOUND", remark);

            if (Integer.parseInt(result.get("result").toString()) == 1) {
                response.put("success", true);
                response.put("data", result.get("data"));
            } else {
                response.put("success", false);
                response.put("message", result.get("message") != null ? result.get("message").toString() : "查询失败");
            }
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "查询失败: " + e.getMessage());
            return ResponseEntity.ok(response);
        }
    }

    /**
     * 出仓单查询
     */
    @GetMapping("/outbound")
    public ResponseEntity<Map<String, Object>> queryOutboundRecords(
            @RequestParam String startDate,
            @RequestParam String endDate,
            @RequestParam(required = false) String materialCode,
            @RequestParam(required = false) String operatorCode,
            @RequestParam(required = false) String remark) {
        Map<String, Object> response = new HashMap<>();
        try {
            Map<String, Object> result = warehouseService.queryInOutRecords(
                    startDate, endDate, materialCode, operatorCode, "OUTBOUND", remark);

            if (Integer.parseInt(result.get("result").toString()) == 1) {
                response.put("success", true);
                response.put("data", result.get("data"));
            } else {
                response.put("success", false);
                response.put("message", result.get("message") != null ? result.get("message").toString() : "查询失败");
            }
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "查询失败: " + e.getMessage());
            return ResponseEntity.ok(response);
        }
    }

    /**
     * 获取所有库存
     */
    @GetMapping("/inventories")
    public ResponseEntity<Map<String, Object>> getAllInventories(
            @RequestParam(required = false) String materialCode,
            @RequestParam(required = false) String materialName) {
        Map<String, Object> response = new HashMap<>();
        try {
            List<Inventory> inventories;

            // 如果提供了搜索参数，则根据参数进行搜索
            if ((materialCode != null && !materialCode.isEmpty()) ||
                    (materialName != null && !materialName.isEmpty())) {
                inventories = warehouseService.searchInventories(materialCode, materialName);
            } else {
                // 否则获取所有库存
                inventories = inventoryRepository.findAll();
            }

            // 转换为包含详细信息的列表
            List<Map<String, Object>> result = warehouseService.getAllInventoryWithDetails(inventories);

            response.put("success", true);
            response.put("data", result);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "获取库存列表失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * 完成多物料进仓单
     */
    @PostMapping("/multi-inout/inbound/complete")
    public ResponseEntity<Map<String, Object>> completeMultiInbound(@RequestBody Map<String, Object> request) {
        Map<String, Object> response = new HashMap<>();
        try {
            String documentCode = request.get("documentCode").toString();
            String username = request.get("username").toString();

            Map<String, Object> result = warehouseService.completeMultiInbound(documentCode, username);

            if (Integer.parseInt(result.get("result").toString()) == 1) {
                response.put("success", true);
                response.put("message", "多物料进仓单完成成功");
                response.put("data", result.get("data"));
            } else {
                response.put("success", false);
                response.put("message", result.get("message") != null ? result.get("message").toString() : "完成进仓单失败");
            }
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "完成进仓单失败: " + e.getMessage());
            return ResponseEntity.ok(response);
        }
    }

    /**
     * 完成多物料出仓单
     */
    @PostMapping("/multi-inout/outbound/complete")
    public ResponseEntity<Map<String, Object>> completeMultiOutbound(@RequestBody Map<String, Object> request) {
        Map<String, Object> response = new HashMap<>();
        try {
            String documentCode = request.get("documentCode").toString();
            String username = request.get("username").toString();

            Map<String, Object> result = warehouseService.completeMultiOutbound(documentCode, username);

            if (Integer.parseInt(result.get("result").toString()) == 1) {
                response.put("success", true);
                response.put("message", "多物料出仓单完成成功");
                response.put("data", result.get("data"));
            } else {
                response.put("success", false);
                response.put("message", result.get("message") != null ? result.get("message").toString() : "完成出仓单失败");
            }
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "完成出仓单失败: " + e.getMessage());
            return ResponseEntity.ok(response);
        }
    }
}