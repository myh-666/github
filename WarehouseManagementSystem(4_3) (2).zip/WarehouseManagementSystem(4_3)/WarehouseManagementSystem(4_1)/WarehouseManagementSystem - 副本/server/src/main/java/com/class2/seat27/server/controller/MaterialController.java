package com.class2.seat27.server.controller;

import com.class2.seat27.server.entity.Material;
import com.class2.seat27.server.service.WarehouseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * 物料管理控制器
 * 处理物料的增删改查操作
 */
@RestController
@RequestMapping("/api/warehouse/materials")
@CrossOrigin(origins = "*")
public class MaterialController {

    @Autowired
    private WarehouseService warehouseService;

    /**
     * 获取所有物料列表
     */
    @GetMapping
    public ResponseEntity<Map<String, Object>> getAllMaterials() {
        Map<String, Object> response = new HashMap<>();
        try {
            List<Material> materials = warehouseService.getAllMaterials();
            response.put("success", true);
            response.put("data", materials);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "获取物料列表失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * 多条件搜索物料
     */
    @GetMapping("/search")
    public ResponseEntity<Map<String, Object>> searchMaterials(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String code,
            @RequestParam(required = false) String spec,
            @RequestParam(required = false) String unit) {
        Map<String, Object> response = new HashMap<>();
        try {
            List<Material> materials = warehouseService.searchMaterials(name, code, spec, unit);
            response.put("success", true);
            response.put("data", materials);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "搜索物料失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * 根据ID获取物料
     */
    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getMaterialById(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();
        try {
            Optional<Material> material = warehouseService.getMaterialById(id);
            if (material.isPresent()) {
                response.put("success", true);
                response.put("data", material.get());
                return ResponseEntity.ok(response);
            } else {
                response.put("success", false);
                response.put("message", "物料不存在");
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "获取物料失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * 新增物料
     */
    @PostMapping
    public ResponseEntity<Map<String, Object>> createMaterial(@RequestBody Material material) {
        Map<String, Object> response = new HashMap<>();
        try {
            // 检查物料编码是否已存在
            if (warehouseService.checkMaterialCodeExists(material.getMaterialCode())) {
                response.put("success", false);
                response.put("message", "物料编码已存在");
                return ResponseEntity.badRequest().body(response);
            }

            Material savedMaterial = warehouseService.saveMaterial(material);
            response.put("success", true);
            response.put("message", "物料创建成功");
            response.put("data", savedMaterial);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "创建物料失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * 更新物料
     */
    @PutMapping("/{id}")
    public ResponseEntity<Map<String, Object>> updateMaterial(@PathVariable Long id, @RequestBody Material material) {
        Map<String, Object> response = new HashMap<>();
        try {
            // 检查物料是否存在
            Optional<Material> existingMaterial = warehouseService.getMaterialById(id);
            if (!existingMaterial.isPresent()) {
                response.put("success", false);
                response.put("message", "物料不存在");
                return ResponseEntity.notFound().build();
            }

            // 禁止修改物料编码，保持原有编码不变
            Material originalMaterial = existingMaterial.get();
            material.setMaterialCode(originalMaterial.getMaterialCode());

            // 设置ID确保更新正确的物料
            material.setId(id);
            Material updatedMaterial = warehouseService.saveMaterial(material);
            response.put("success", true);
            response.put("message", "物料更新成功（物料编码不可修改）");
            response.put("data", updatedMaterial);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "更新物料失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * 删除物料
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Object>> deleteMaterial(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();
        try {
            // 检查物料是否存在
            Optional<Material> existingMaterial = warehouseService.getMaterialById(id);
            if (!existingMaterial.isPresent()) {
                response.put("success", false);
                response.put("message", "物料不存在");
                return ResponseEntity.notFound().build();
            }

            warehouseService.deleteMaterial(id);
            response.put("success", true);
            response.put("message", "物料删除成功");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "删除物料失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * 检查物料编码是否存在
     */
    @GetMapping("/check")
    public ResponseEntity<Map<String, Object>> checkMaterialCode(@RequestParam String code) {
        Map<String, Object> response = new HashMap<>();
        try {
            boolean exists = warehouseService.checkMaterialCodeExists(code);
            response.put("success", true);
            response.put("exists", exists);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "检查物料编码失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * 获取所有不重复的单位
     */
    @GetMapping("/units")
    public ResponseEntity<Map<String, Object>> getAllUnits() {
        Map<String, Object> response = new HashMap<>();
        try {
            List<String> units = warehouseService.getAllDistinctUnits();
            response.put("success", true);
            response.put("data", units);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "获取单位列表失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }
}