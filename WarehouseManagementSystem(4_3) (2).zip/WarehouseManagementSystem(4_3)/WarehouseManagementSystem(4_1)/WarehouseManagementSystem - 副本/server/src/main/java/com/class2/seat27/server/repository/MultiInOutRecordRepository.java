
package com.class2.seat27.server.repository;

import com.class2.seat27.server.entity.MultiInOutRecord;
import com.class2.seat27.server.entity.User;
import com.class2.seat27.server.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * 多物料进出仓记录仓库接口
 */
@Repository
public interface MultiInOutRecordRepository extends JpaRepository<MultiInOutRecord, Long> {
    Optional<MultiInOutRecord> findByDocumentCode(String documentCode);

    List<MultiInOutRecord> findByOperatorCode(User operatorCode);

    List<MultiInOutRecord> findByStatus(Status status);

    List<MultiInOutRecord> findByOperationDateBetween(LocalDateTime startDate, LocalDateTime endDate);

    List<MultiInOutRecord> findByOperationType(String operationType);

    @Query("SELECT m FROM MultiInOutRecord m WHERE m.status = :status AND m.operationDate >= :startDate")
    List<MultiInOutRecord> findByStatusAndOperationDateAfter(@Param("status") Status status, @Param("startDate") LocalDateTime startDate);

    @Query("SELECT m FROM MultiInOutRecord m WHERE m.status = :status ORDER BY m.operationDate DESC")
    List<MultiInOutRecord> findByStatusOrderByOperationDateDesc(@Param("status") Status status);

    @Query("SELECT MAX(m.documentCode) FROM MultiInOutRecord m WHERE m.operationType = :operationType")
    String findMaxDocumentCodeByOperationType(@Param("operationType") String operationType);
}
