package com.class2.seat27.server.repository;

public interface PersonnelRepository {
}
