package com.class2.seat27.server.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "class2_seat27_outbound_detail")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class OutboundDetail {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "outbound_id", nullable = false)
    @JsonIgnore
    private Outbound outbound;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "material_id", nullable = false)
    private Material material;

    @Column(nullable = false)
    private Integer quantity;

    @Column(name = "unit_price")
    private BigDecimal unitPrice;

    @Column(name = "total_price")
    private BigDecimal totalPrice;

    @Column(length = 500)
    private String remark;

    @Column(name = "created_time")
    private LocalDateTime createdTime;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by")
    private User createdBy;

    // 构造器、getter、setter
    public OutboundDetail() {
        this.createdTime = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Outbound getOutbound() { return outbound; }
    public void setOutbound(Outbound outbound) { 
        this.outbound = outbound; 
        this.createdTime = LocalDateTime.now();
    }

    public Long getOutboundId() {
        return outbound != null ? outbound.getId() : null;
    }

    public Material getMaterial() { return material; }
    public void setMaterial(Material material) { 
        this.material = material; 
        this.createdTime = LocalDateTime.now();
    }

    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { 
        this.quantity = quantity; 
        this.calculateTotalPrice();
        this.createdTime = LocalDateTime.now();
    }

    public BigDecimal getUnitPrice() { return unitPrice; }
    public void setUnitPrice(BigDecimal unitPrice) { 
        this.unitPrice = unitPrice; 
        this.calculateTotalPrice();
        this.createdTime = LocalDateTime.now();
    }

    public BigDecimal getTotalPrice() { return totalPrice; }
    public void setTotalPrice(BigDecimal totalPrice) { 
        this.totalPrice = totalPrice; 
        this.createdTime = LocalDateTime.now();
    }

    public String getRemark() { return remark; }
    public void setRemark(String remark) { 
        this.remark = remark; 
        this.createdTime = LocalDateTime.now();
    }

    public LocalDateTime getCreatedTime() { return createdTime; }
    public void setCreatedTime(LocalDateTime createdTime) { this.createdTime = createdTime; }
    
    public User getCreatedBy() { return createdBy; }
    public void setCreatedBy(User createdBy) { this.createdBy = createdBy; }

    // 计算总价
    private void calculateTotalPrice() {
        if (this.quantity != null && this.unitPrice != null) {
            this.totalPrice = BigDecimal.valueOf(this.quantity).multiply(this.unitPrice);
        } else {
            this.totalPrice = BigDecimal.ZERO;
        }
    }
}