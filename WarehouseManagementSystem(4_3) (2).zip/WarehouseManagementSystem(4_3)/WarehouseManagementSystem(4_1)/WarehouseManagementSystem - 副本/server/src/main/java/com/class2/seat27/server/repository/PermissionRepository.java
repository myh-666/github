package com.class2.seat27.server.repository;

import com.class2.seat27.server.entity.Permission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PermissionRepository extends JpaRepository<Permission, Long> {
    Optional<Permission> findByResourceCode(String resourceCode);
    List<Permission> findAllByOrderByMenuPathAsc();

    @Query("SELECT p FROM Permission p WHERE p.menuPath LIKE CONCAT(:menuPath, '%')")
    List<Permission> findByMenuPathStartingWith(String menuPath);
}