
package com.class2.seat27.server.repository;

import com.class2.seat27.server.entity.MultiInOutDetail;
import com.class2.seat27.server.entity.MultiInOutRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 多物料进出仓明细仓库接口
 */
@Repository
public interface MultiInOutDetailRepository extends JpaRepository<MultiInOutDetail, Long> {
    List<MultiInOutDetail> findByMultiInOutRecord(MultiInOutRecord multiInOutRecord);

    List<MultiInOutDetail> findByMultiInOutRecordId(Long recordId);

    List<MultiInOutDetail> findByMaterialCode(String materialCode);

    @Query("SELECT d FROM MultiInOutDetail d WHERE d.multiInOutRecord.documentCode = :documentCode")
    List<MultiInOutDetail> findByDocumentCode(@Param("documentCode") String documentCode);

    @Query("SELECT d FROM MultiInOutDetail d WHERE d.multiInOutRecord.operationDate BETWEEN :startDate AND :endDate")
    List<MultiInOutDetail> findByOperationDateBetween(@Param("startDate") java.time.LocalDateTime startDate, @Param("endDate") java.time.LocalDateTime endDate);
}
