
package com.class2.seat27.server.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.math.BigDecimal;

/**
 * 物料统计实体类
 * 用于记录物料的进出仓统计信息
 */
@Entity
@Table(name = "class2_seat27_material_statistics")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class MaterialStatistics {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "material_id", nullable = false)
    private Material material;

    @Column(name = "start_date", nullable = false)
    private java.time.LocalDate startDate;

    @Column(name = "end_date", nullable = false)
    private java.time.LocalDate endDate;

    @Column(name = "inbound_quantity")
    private Integer inboundQuantity;

    @Column(name = "inbound_amount")
    private BigDecimal inboundAmount;

    @Column(name = "outbound_quantity")
    private Integer outboundQuantity;

    @Column(name = "outbound_amount")
    private BigDecimal outboundAmount;

    @Column(name = "net_flow")
    private Integer netFlow;

    @Column(name = "net_amount")
    private BigDecimal netAmount;

    @Column(name = "created_time")
    private java.time.LocalDateTime createdTime;

    // 构造器
    public MaterialStatistics() {
        this.createdTime = java.time.LocalDateTime.now();
    }

    // getter 和 setter 方法
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Material getMaterial() { return material; }
    public void setMaterial(Material material) {
        this.material = material;
    }

    public java.time.LocalDate getStartDate() { return startDate; }
    public void setStartDate(java.time.LocalDate startDate) {
        this.startDate = startDate;
    }

    public java.time.LocalDate getEndDate() { return endDate; }
    public void setEndDate(java.time.LocalDate endDate) {
        this.endDate = endDate;
    }

    public Integer getInboundQuantity() { return inboundQuantity; }
    public void setInboundQuantity(Integer inboundQuantity) {
        this.inboundQuantity = inboundQuantity;
    }

    public BigDecimal getInboundAmount() { return inboundAmount; }
    public void setInboundAmount(BigDecimal inboundAmount) {
        this.inboundAmount = inboundAmount;
    }

    public Integer getOutboundQuantity() { return outboundQuantity; }
    public void setOutboundQuantity(Integer outboundQuantity) {
        this.outboundQuantity = outboundQuantity;
    }

    public BigDecimal getOutboundAmount() { return outboundAmount; }
    public void setOutboundAmount(BigDecimal outboundAmount) {
        this.outboundAmount = outboundAmount;
    }

    public Integer getNetFlow() { return netFlow; }
    public void setNetFlow(Integer netFlow) {
        this.netFlow = netFlow;
    }

    public BigDecimal getNetAmount() { return netAmount; }
    public void setNetAmount(BigDecimal netAmount) {
        this.netAmount = netAmount;
    }

    public java.time.LocalDateTime getCreatedTime() { return createdTime; }
    public void setCreatedTime(java.time.LocalDateTime createdTime) { this.createdTime = createdTime; }
}
