package com.class2.seat27.server.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "class2_seat27_multi_inout_record")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class MultiInOutRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String documentCode;

    @Column(name = "operation_type", nullable = false)
    private String operationType; // INBOUND 或 OUTBOUND

    @Column(name = "operation_date", nullable = false)
    private LocalDateTime operationDate;

    @Column(name = "operator_code", nullable = false)
    private String operatorCode;

    @Column(name = "handler_code")
    private String handlerCode;

    private String remark;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private Status status; // DRAFT, CONFIRMED, COMPLETED, CANCELLED

    @Column(name = "created_time")
    private LocalDateTime createdTime;

    @Column(name = "updated_time")
    private LocalDateTime updatedTime;

    // 多对一关系，关联到明细记录
    @OneToMany(mappedBy = "multiInOutRecord", fetch = FetchType.LAZY)
    @JsonIgnore // 添加此注解以打破循环引用
    private List<MultiInOutDetail> details;

    // 构造器、getter、setter
    public MultiInOutRecord() {
        this.createdTime = LocalDateTime.now();
        this.updatedTime = LocalDateTime.now();
        this.status = Status.DRAFT;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getDocumentCode() { return documentCode; }
    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode;
        this.updatedTime = LocalDateTime.now();
    }

    public String getOperationType() { return operationType; }
    public void setOperationType(String operationType) {
        this.operationType = operationType;
        this.updatedTime = LocalDateTime.now();
    }

    public LocalDateTime getOperationDate() { return operationDate; }
    public void setOperationDate(LocalDateTime operationDate) {
        this.operationDate = operationDate;
        this.updatedTime = LocalDateTime.now();
    }

    public String getOperatorCode() { return operatorCode; }
    public void setOperatorCode(String operatorCode) {
        this.operatorCode = operatorCode;
        this.updatedTime = LocalDateTime.now();
    }

    public String getHandlerCode() { return handlerCode; }
    public void setHandlerCode(String handlerCode) {
        this.handlerCode = handlerCode;
        this.updatedTime = LocalDateTime.now();
    }

    public String getRemark() { return remark; }
    public void setRemark(String remark) {
        this.remark = remark;
        this.updatedTime = LocalDateTime.now();
    }

    public Status getStatus() { return status; }
    public void setStatus(Status status) {
        this.status = status;
        this.updatedTime = LocalDateTime.now();
    }

    public LocalDateTime getCreatedTime() { return createdTime; }
    public void setCreatedTime(LocalDateTime createdTime) { this.createdTime = createdTime; }

    public LocalDateTime getUpdatedTime() { return updatedTime; }
    public void setUpdatedTime(LocalDateTime updatedTime) { this.updatedTime = updatedTime; }

    public List<MultiInOutDetail> getDetails() { return details; }
    public void setDetails(List<MultiInOutDetail> details) {
        this.details = details;
    }
}
