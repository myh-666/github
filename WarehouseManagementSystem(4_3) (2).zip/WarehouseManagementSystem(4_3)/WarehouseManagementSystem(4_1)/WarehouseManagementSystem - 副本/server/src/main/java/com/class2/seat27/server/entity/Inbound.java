package com.class2.seat27.server.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "class2_seat27_inbound")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Inbound {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String inboundCode;

    @Column(name = "inbound_date", nullable = false)
    private LocalDateTime inboundDate;

    @Column(length = 1000)
    private String remark;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status;

    @Column(name = "created_time")
    private LocalDateTime createdTime;

    @Column(name = "updated_time")
    private LocalDateTime updatedTime;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by", nullable = false)
    private User createdBy;

    @OneToMany(mappedBy = "inbound", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<InboundDetail> details;

    // 构造器、getter、setter
    public Inbound() {
        this.status = Status.DRAFT;
        this.inboundDate = LocalDateTime.now();
        this.createdTime = LocalDateTime.now();
        this.updatedTime = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getInboundCode() { return inboundCode; }
    public void setInboundCode(String inboundCode) { 
        this.inboundCode = inboundCode; 
        this.updatedTime = LocalDateTime.now();
    }

    public LocalDateTime getInboundDate() { return inboundDate; }
    public void setInboundDate(LocalDateTime inboundDate) { 
        this.inboundDate = inboundDate; 
        this.updatedTime = LocalDateTime.now();
    }

    public String getRemark() { return remark; }
    public void setRemark(String remark) { 
        this.remark = remark; 
        this.updatedTime = LocalDateTime.now();
    }

    public Status getStatus() { return status; }
    public void setStatus(Status status) { 
        this.status = status; 
        this.updatedTime = LocalDateTime.now();
    }

    public LocalDateTime getCreatedTime() { return createdTime; }
    public void setCreatedTime(LocalDateTime createdTime) { this.createdTime = createdTime; }

    public LocalDateTime getUpdatedTime() { return updatedTime; }
    public void setUpdatedTime(LocalDateTime updatedTime) { this.updatedTime = updatedTime; }

    public User getCreatedBy() { return createdBy; }
    public void setCreatedBy(User createdBy) { this.createdBy = createdBy; }
    
    public String getOperatorCode() {
        return createdBy != null ? createdBy.getUsername() : null;
    }

    public List<InboundDetail> getDetails() { return details; }
    public void setDetails(List<InboundDetail> details) { this.details = details; }
}