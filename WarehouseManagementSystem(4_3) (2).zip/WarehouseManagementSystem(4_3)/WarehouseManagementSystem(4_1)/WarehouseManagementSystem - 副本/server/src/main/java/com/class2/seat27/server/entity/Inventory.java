package com.class2.seat27.server.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "class2_seat27_inventory")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Inventory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "material_id", nullable = false)
    private Material material;

    @Column(nullable = false)
    private Integer quantity;

    @Column(name = "last_inbound_time")
    private LocalDateTime lastInboundTime;

    @Column(name = "last_outbound_time")
    private LocalDateTime lastOutboundTime;

    @Column(name = "updated_time")
    private LocalDateTime updatedTime;

    // 为了兼容性，添加lastUpdated方法
    public LocalDateTime getLastUpdated() {
        return updatedTime;
    }

    public void setLastUpdated(LocalDateTime lastUpdated) {
        this.updatedTime = lastUpdated;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "updated_by")
    private User updatedBy;

    // 构造器、getter、setter
    public Inventory() {
        this.quantity = 0;
        this.updatedTime = LocalDateTime.now();
    }

    public Inventory(Material material, Integer quantity) {
        this.material = material;
        this.quantity = quantity != null ? quantity : 0;
        this.updatedTime = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Material getMaterial() { return material; }
    public void setMaterial(Material material) {
        this.material = material;
        this.updatedTime = LocalDateTime.now();
    }

    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) {
        this.quantity = quantity != null ? quantity : 0;
        this.updatedTime = LocalDateTime.now();
    }

    public LocalDateTime getLastInboundTime() { return lastInboundTime; }
    public void setLastInboundTime(LocalDateTime lastInboundTime) {
        this.lastInboundTime = lastInboundTime;
        this.updatedTime = LocalDateTime.now();
    }

    public LocalDateTime getLastOutboundTime() { return lastOutboundTime; }
    public void setLastOutboundTime(LocalDateTime lastOutboundTime) {
        this.lastOutboundTime = lastOutboundTime;
        this.updatedTime = LocalDateTime.now();
    }

    public LocalDateTime getUpdatedTime() { return updatedTime; }
    public void setUpdatedTime(LocalDateTime updatedTime) { this.updatedTime = updatedTime; }

    public User getUpdatedBy() { return updatedBy; }
    public void setUpdatedBy(User updatedBy) { this.updatedBy = updatedBy; }
}