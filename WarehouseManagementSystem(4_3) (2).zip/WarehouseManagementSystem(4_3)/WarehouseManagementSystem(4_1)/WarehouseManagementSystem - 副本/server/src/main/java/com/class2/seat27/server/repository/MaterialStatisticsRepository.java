
package com.class2.seat27.server.repository;

import com.class2.seat27.server.entity.MaterialStatistics;
import com.class2.seat27.server.entity.Material;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

/**
 * 物料统计仓库接口
 */
@Repository
public interface MaterialStatisticsRepository extends JpaRepository<MaterialStatistics, Long> {

    /**
     * 根据物料和日期范围查询物料统计
     */
    List<MaterialStatistics> findByMaterialAndStartDateBetweenAndEndDateBetween(
        Material material, LocalDate start1, LocalDate end1, LocalDate start2, LocalDate end2);

    /**
     * 根据日期范围查询物料统计
     */
    List<MaterialStatistics> findByStartDateBetweenAndEndDateBetween(
        LocalDate startDate1, LocalDate endDate1, LocalDate startDate2, LocalDate endDate2);

    /**
     * 查询指定日期范围内的物料统计，按物料代码排序
     */
    @Query("SELECT ms FROM MaterialStatistics ms WHERE ms.startDate >= :startDate AND ms.endDate <= :endDate ORDER BY ms.material.materialCode")
    List<MaterialStatistics> findByDateRange(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);

    /**
     * 查询指定物料在指定日期范围内的统计
     */
    @Query("SELECT ms FROM MaterialStatistics ms WHERE ms.material = :material AND ms.startDate >= :startDate AND ms.endDate <= :endDate")
    List<MaterialStatistics> findByMaterialAndDateRange(
        @Param("material") Material material, @Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);

    /**
     * 查询流动量最小的物料
     */
    @Query("SELECT ms FROM MaterialStatistics ms WHERE ms.netFlow = (SELECT MIN(ms2.netFlow) FROM MaterialStatistics ms2) ORDER BY ms.material.materialCode")
    List<MaterialStatistics> findMinFlowMaterials();

    /**
     * 删除特定物料的统计记录
     */
    void deleteByMaterialId(Long materialId);
}
