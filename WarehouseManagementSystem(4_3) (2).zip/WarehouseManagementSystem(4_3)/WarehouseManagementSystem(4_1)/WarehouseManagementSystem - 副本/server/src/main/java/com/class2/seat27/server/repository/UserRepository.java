package com.class2.seat27.server.repository;
import com.class2.seat27.server.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;
public interface UserRepository extends JpaRepository<User, Long>{
    Optional<User> findByUsername(String username);
    Optional<User> findByPersonnelCode(String personnelCode);
    boolean existsByUsername(String username);

    boolean existsByIdCard(String idCard);
    // 添加这个方法 - 只需要添加这一行
    @Query("SELECT MAX(u.personnelCode) FROM User u WHERE u.personnelCode LIKE 'P%'")
    String findMaxPersonnelCode();
}
