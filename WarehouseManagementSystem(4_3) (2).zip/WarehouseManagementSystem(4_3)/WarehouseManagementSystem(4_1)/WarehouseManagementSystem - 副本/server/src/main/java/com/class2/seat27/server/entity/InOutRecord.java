package com.class2.seat27.server.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "class2_seat27_inout_record")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class InOutRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String documentCode;

    @Column(name = "operation_type", nullable = false)
    private String operationType; // INBOUND 或 OUTBOUND

    @Column(name = "operation_date", nullable = false)
    private LocalDateTime operationDate;

    @Column(name = "operator_code", nullable = false)
    private String operatorCode;

    @Column(name = "handler_code")
    private String handlerCode;

    @Column(name = "material_code", nullable = false)
    private String materialCode;

    @Column(name = "quantity", nullable = false)
    private Integer quantity;

    @Column(name = "unit_price")
    private BigDecimal unitPrice;

    @Column(name = "total_price")
    private BigDecimal totalPrice;

    private String remark;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private Status status; // DRAFT, CONFIRMED, COMPLETED, CANCELLED

    @Column(name = "created_time")
    private LocalDateTime createdTime;

    @Column(name = "updated_time")
    private LocalDateTime updatedTime;

    // 构造器、getter、setter
    public InOutRecord() {
        this.createdTime = LocalDateTime.now();
        this.updatedTime = LocalDateTime.now();
        this.status = Status.DRAFT;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getDocumentCode() { return documentCode; }
    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode;
        this.updatedTime = LocalDateTime.now();
    }

    public String getOperationType() { return operationType; }
    public void setOperationType(String operationType) {
        this.operationType = operationType;
        this.updatedTime = LocalDateTime.now();
    }

    public LocalDateTime getOperationDate() { return operationDate; }
    public void setOperationDate(LocalDateTime operationDate) {
        this.operationDate = operationDate;
        this.updatedTime = LocalDateTime.now();
    }

    public String getOperatorCode() { return operatorCode; }
    public void setOperatorCode(String operatorCode) {
        this.operatorCode = operatorCode;
        this.updatedTime = LocalDateTime.now();
    }

    public String getHandlerCode() { return handlerCode; }
    public void setHandlerCode(String handlerCode) {
        this.handlerCode = handlerCode;
        this.updatedTime = LocalDateTime.now();
    }

    public String getMaterialCode() { return materialCode; }
    public void setMaterialCode(String materialCode) {
        this.materialCode = materialCode;
        this.updatedTime = LocalDateTime.now();
    }

    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
        this.updatedTime = LocalDateTime.now();
    }

    public BigDecimal getUnitPrice() { return unitPrice; }
    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
        this.updatedTime = LocalDateTime.now();
    }

    public BigDecimal getTotalPrice() { return totalPrice; }
    public void setTotalPrice(BigDecimal totalPrice) {
        this.totalPrice = totalPrice;
        this.updatedTime = LocalDateTime.now();
    }

    public String getRemark() { return remark; }
    public void setRemark(String remark) {
        this.remark = remark;
        this.updatedTime = LocalDateTime.now();
    }

    public Status getStatus() { return status; }
    public void setStatus(Status status) {
        this.status = status;
        this.updatedTime = LocalDateTime.now();
    }

    public LocalDateTime getCreatedTime() { return createdTime; }
    public void setCreatedTime(LocalDateTime createdTime) { this.createdTime = createdTime; }

    public LocalDateTime getUpdatedTime() { return updatedTime; }
    public void setUpdatedTime(LocalDateTime updatedTime) { this.updatedTime = updatedTime; }
}
