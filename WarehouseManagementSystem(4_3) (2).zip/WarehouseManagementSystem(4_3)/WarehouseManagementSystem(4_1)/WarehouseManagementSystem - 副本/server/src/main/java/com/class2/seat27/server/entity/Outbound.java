package com.class2.seat27.server.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "class2_seat27_outbound")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Outbound {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String outboundCode;

    @Column(name = "outbound_date", nullable = false)
    private LocalDateTime outboundDate;

    @Column(length = 1000)
    private String remark;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status;

    @Column(name = "created_time")
    private LocalDateTime createdTime;

    @Column(name = "updated_time")
    private LocalDateTime updatedTime;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by", nullable = false)
    private User createdBy;

    @OneToMany(mappedBy = "outbound", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<OutboundDetail> details;

    // 构造器、getter、setter
    public Outbound() {
        this.status = Status.DRAFT;
        this.outboundDate = LocalDateTime.now();
        this.createdTime = LocalDateTime.now();
        this.updatedTime = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getOutboundCode() { return outboundCode; }
    public void setOutboundCode(String outboundCode) { 
        this.outboundCode = outboundCode; 
        this.updatedTime = LocalDateTime.now();
    }

    public LocalDateTime getOutboundDate() { return outboundDate; }
    public void setOutboundDate(LocalDateTime outboundDate) { 
        this.outboundDate = outboundDate; 
        this.updatedTime = LocalDateTime.now();
    }

    public String getRemark() { return remark; }
    public void setRemark(String remark) { 
        this.remark = remark; 
        this.updatedTime = LocalDateTime.now();
    }

    public Status getStatus() { return status; }
    public void setStatus(Status status) { 
        this.status = status; 
        this.updatedTime = LocalDateTime.now();
    }

    public LocalDateTime getCreatedTime() { return createdTime; }
    public void setCreatedTime(LocalDateTime createdTime) { this.createdTime = createdTime; }

    public LocalDateTime getUpdatedTime() { return updatedTime; }
    public void setUpdatedTime(LocalDateTime updatedTime) { this.updatedTime = updatedTime; }

    public User getCreatedBy() { return createdBy; }
    public void setCreatedBy(User createdBy) { this.createdBy = createdBy; }
    
    public String getOperatorCode() {
        return createdBy != null ? createdBy.getUsername() : null;
    }

    public List<OutboundDetail> getDetails() { return details; }
    public void setDetails(List<OutboundDetail> details) { this.details = details; }
}