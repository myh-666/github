package com.class2.seat27.server.service;

import com.class2.seat27.server.entity.*;
import com.class2.seat27.server.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.sql.Types;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * 报表服务类（新版）
 * 处理各类报表统计和打印功能
 */
@Service
public class ReportService {

    @Autowired
    private MaterialRepository materialRepository;

    @Autowired
    private InventoryRepository inventoryRepository;

    @Autowired
    private InboundRepository inboundRepository;

    @Autowired
    private InboundDetailRepository inboundDetailRepository;

    @Autowired
    private OutboundRepository outboundRepository;

    @Autowired
    private OutboundDetailRepository outboundDetailRepository;

    @Autowired
    private WarehouseLedgerRepository warehouseLedgerRepository;

    @Autowired
    private MaterialStatisticsRepository materialStatisticsRepository;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * 使用存储过程生成物料统计信息
     */
    public Map<String, Object> getMaterialStatisticsByProcedure(LocalDate startDate, LocalDate endDate) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 使用SimpleJdbcCall调用存储过程
            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("class2_seat27_material_flow_statistics")
                .declareParameters(
                    new SqlParameter("p_start_date", Types.DATE),
                    new SqlParameter("p_end_date", Types.DATE),
                    new SqlOutParameter("p_result", Types.INTEGER),
                    new SqlOutParameter("p_message", Types.VARCHAR)
                );

            // 准备输入参数
            Map<String, Object> inParams = new HashMap<>();
            inParams.put("p_start_date", startDate);
            inParams.put("p_end_date", endDate);

            // 执行存储过程
            Map<String, Object> outParams = jdbcCall.execute(inParams);
            
            // 获取输出参数
            int procResult = (Integer) outParams.get("p_result");
            String procMessage = (String) outParams.get("p_message");

            if (procResult == 1) {
                // 再次调用存储过程获取数据结果集
                List<Map<String, Object>> records = jdbcTemplate.queryForList(
                    "CALL class2_seat27_material_flow_statistics(?, ?)", 
                    startDate, endDate);
                
                result.put("success", true);
                result.put("data", records);
                result.put("message", procMessage);
            } else {
                result.put("success", false);
                result.put("message", procMessage);
            }
            
            return result;
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "物料统计数据生成失败: " + e.getMessage());
            return result;
        }
    }
    
    /**
     * 获取物料统计信息
     */
    public Map<String, Object> getMaterialStatistics(LocalDate startDate, LocalDate endDate) {
        Map<String, Object> result = new HashMap<>();

        try {
            // 获取所有物料
            List<Material> materials = materialRepository.findAll();
            List<Map<String, Object>> statistics = new ArrayList<>();

            // 计算每个物料的统计信息
            for (Material material : materials) {
                Map<String, Object> stat = new HashMap<>();
                stat.put("materialId", material.getId());
                stat.put("material_code", material.getMaterialCode()); // 修改为下划线命名
                stat.put("material_name", material.getName()); // 修改为下划线命名
                stat.put("specification", material.getSpecification());
                stat.put("unit", material.getUnit());

                // 获取当前库存
                Optional<Inventory> inventoryOpt = inventoryRepository.findByMaterialId(material.getId());
                Integer currentQuantity = inventoryOpt.isPresent() ? 
                    inventoryOpt.get().getQuantity() : 0;
                stat.put("current_quantity", currentQuantity); // 修改为下划线命名

                // 计算期间进仓总量和金额
                Integer inboundQuantity = 0;
                BigDecimal inboundAmount = BigDecimal.ZERO;

                List<InboundDetail> inboundDetails = inboundDetailRepository.findByMaterialId(material.getId());
                for (InboundDetail detail : inboundDetails) {
                    Inbound inbound = inboundRepository.findById(detail.getInboundId()).orElse(null);
                    if (inbound != null && 
                        !inbound.getInboundDate().toLocalDate().isBefore(startDate) && 
                        !inbound.getInboundDate().toLocalDate().isAfter(endDate) &&
                        inbound.getStatus() == Status.COMPLETED) {
                        inboundQuantity = inboundQuantity + detail.getQuantity();
                        inboundAmount = inboundAmount.add(detail.getTotalPrice());
                    }
                }
                stat.put("inbound_quantity", inboundQuantity); // 修改为下划线命名
                stat.put("inbound_amount", inboundAmount); // 修改为下划线命名

                // 计算期间出仓总量和金额
                Integer outboundQuantity = 0;
                BigDecimal outboundAmount = BigDecimal.ZERO;

                List<OutboundDetail> outboundDetails = outboundDetailRepository.findByMaterialId(material.getId());
                for (OutboundDetail detail : outboundDetails) {
                    Outbound outbound = outboundRepository.findById(detail.getOutboundId()).orElse(null);
                    if (outbound != null && 
                        !outbound.getOutboundDate().toLocalDate().isBefore(startDate) && 
                        !outbound.getOutboundDate().toLocalDate().isAfter(endDate) &&
                        outbound.getStatus() == Status.COMPLETED) {
                        outboundQuantity = outboundQuantity + detail.getQuantity();
                        outboundAmount = outboundAmount.add(detail.getTotalPrice());
                    }
                }
                stat.put("outbound_quantity", outboundQuantity); // 修改为下划线命名
                stat.put("outbound_amount", outboundAmount); // 修改为下划线命名

                // 计算净流量
                Integer netFlow = inboundQuantity - outboundQuantity;
                stat.put("net_flow", netFlow); // 修改为下划线命名

                // 计算净金额
                BigDecimal netAmount = inboundAmount.subtract(outboundAmount);
                stat.put("net_amount", netAmount); // 修改为下划线命名

                statistics.add(stat);
            }

            result.put("success", true);
            result.put("data", statistics);
            return result;
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "获取物料统计失败: " + e.getMessage());
            return result;
        }
    }

    /**
     * 获取进出仓单数据
     */
    public Map<String, Object> getInOutData(LocalDate startDate, LocalDate endDate, String type) {
        Map<String, Object> result = new HashMap<>();

        try {
            List<Map<String, Object>> data = new ArrayList<>();

            if ("INBOUND".equals(type) || "ALL".equals(type)) {
                // 获取进仓单数据
                List<Inbound> inbounds = inboundRepository.findByInboundDateBetween(
                    startDate.atStartOfDay(), endDate.atTime(23, 59, 59));

                for (Inbound inbound : inbounds) {
                    if (inbound.getStatus() != Status.COMPLETED) continue;

                    Map<String, Object> item = new HashMap<>();
                    item.put("document_code", inbound.getInboundCode()); // 修改为下划线命名
                    item.put("operation_type", "进仓"); // 修改为下划线命名
                    item.put("operation_date", inbound.getInboundDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))); // 修改为下划线命名
                    item.put("operator_code", inbound.getCreatedBy().getUsername()); // 修改为下划线命名
                    item.put("operator_name", inbound.getCreatedBy().getName()); // 修改为下划线命名
                    item.put("remark", inbound.getRemark());

                    // 获取明细
                    List<Map<String, Object>> details = new ArrayList<>();
                    List<InboundDetail> inboundDetails = inboundDetailRepository.findByInboundId(inbound.getId());
                    for (InboundDetail detail : inboundDetails) {
                        Map<String, Object> detailItem = new HashMap<>();
                        detailItem.put("material_code", detail.getMaterial().getMaterialCode()); // 修改为下划线命名
                        detailItem.put("material_name", detail.getMaterial().getName()); // 修改为下划线命名
                        detailItem.put("specification", detail.getMaterial().getSpecification());
                        detailItem.put("unit", detail.getMaterial().getUnit());
                        detailItem.put("quantity", detail.getQuantity());
                        detailItem.put("unit_price", detail.getUnitPrice()); // 修改为下划线命名
                        detailItem.put("total_price", detail.getTotalPrice()); // 修改为下划线命名
                        detailItem.put("remark", detail.getRemark());
                        details.add(detailItem);
                    }
                    item.put("details", details);
                    data.add(item);
                }
            }

            if ("OUTBOUND".equals(type) || "ALL".equals(type)) {
                // 获取出仓单数据
                List<Outbound> outbounds = outboundRepository.findByOutboundDateBetween(
                    startDate.atStartOfDay(), endDate.atTime(23, 59, 59));

                for (Outbound outbound : outbounds) {
                    if (outbound.getStatus() != Status.COMPLETED) continue;

                    Map<String, Object> item = new HashMap<>();
                    item.put("document_code", outbound.getOutboundCode()); // 修改为下划线命名
                    item.put("operation_type", "出仓"); // 修改为下划线命名
                    item.put("operation_date", outbound.getOutboundDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))); // 修改为下划线命名
                    item.put("operator_code", outbound.getCreatedBy().getUsername()); // 修改为下划线命名
                    item.put("operator_name", outbound.getCreatedBy().getName()); // 修改为下划线命名
                    item.put("remark", outbound.getRemark());

                    // 获取明细
                    List<Map<String, Object>> details = new ArrayList<>();
                    List<OutboundDetail> outboundDetails = outboundDetailRepository.findByOutboundId(outbound.getId());
                    for (OutboundDetail detail : outboundDetails) {
                        Map<String, Object> detailItem = new HashMap<>();
                        detailItem.put("material_code", detail.getMaterial().getMaterialCode()); // 修改为下划线命名
                        detailItem.put("material_name", detail.getMaterial().getName()); // 修改为下划线命名
                        detailItem.put("specification", detail.getMaterial().getSpecification());
                        detailItem.put("unit", detail.getMaterial().getUnit());
                        detailItem.put("quantity", detail.getQuantity());
                        detailItem.put("unit_price", detail.getUnitPrice()); // 修改为下划线命名
                        detailItem.put("total_price", detail.getTotalPrice()); // 修改为下划线命名
                        detailItem.put("remark", detail.getRemark());
                        details.add(detailItem);
                    }
                    item.put("details", details);
                    data.add(item);
                }
            }

            result.put("success", true);
            result.put("data", data);
            return result;
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "获取进出仓单数据失败: " + e.getMessage());
            return result;
        }
    }

    /**
     * 使用存储过程生成月度进出仓单数据
     */
    public Map<String, Object> getMonthlyRecordsByProcedure(int year, int month) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 使用SimpleJdbcCall调用存储过程
            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("class2_seat27_print_monthly_records")
                .declareParameters(
                    new SqlParameter("p_year", Types.INTEGER),
                    new SqlParameter("p_month", Types.INTEGER),
                    new SqlOutParameter("p_result", Types.INTEGER),
                    new SqlOutParameter("p_message", Types.VARCHAR)
                );

            // 准备输入参数
            Map<String, Object> inParams = new HashMap<>();
            inParams.put("p_year", year);
            inParams.put("p_month", month);

            // 执行存储过程
            Map<String, Object> outParams = jdbcCall.execute(inParams);
            
            // 获取输出参数
            int procResult = (Integer) outParams.get("p_result");
            String procMessage = (String) outParams.get("p_message");

            if (procResult == 1) {
                // 再次调用存储过程获取数据结果集
                List<Map<String, Object>> records = jdbcTemplate.queryForList(
                    "CALL class2_seat27_print_monthly_records(?, ?)", 
                    year, month);
                
                result.put("success", true);
                result.put("data", records);
                result.put("message", procMessage);
            } else {
                result.put("success", false);
                result.put("message", procMessage);
            }
            
            return result;
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "月度进出仓单数据生成失败: " + e.getMessage());
            return result;
        }
    }
    
    /**
     * 使用存储过程生成仓库账本数据
     */
    public Map<String, Object> getWarehouseLedgerByProcedure(int year, String materialCode) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 使用SimpleJdbcCall调用存储过程
            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("class2_seat27_print_warehouse_ledger")
                .declareParameters(
                    new SqlParameter("p_year", Types.INTEGER),
                    new SqlParameter("p_material_code", Types.VARCHAR),
                    new SqlOutParameter("p_result", Types.INTEGER),
                    new SqlOutParameter("p_message", Types.VARCHAR)
                );

            // 准备输入参数
            Map<String, Object> inParams = new HashMap<>();
            inParams.put("p_year", year);
            inParams.put("p_material_code", materialCode != null ? materialCode : "");

            // 执行存储过程
            Map<String, Object> outParams = jdbcCall.execute(inParams);
            
            // 获取输出参数
            int procResult = (Integer) outParams.get("p_result");
            String procMessage = (String) outParams.get("p_message");

            if (procResult == 1) {
                // 再次调用存储过程获取数据结果集
                List<Map<String, Object>> records = jdbcTemplate.queryForList(
                    "CALL class2_seat27_print_warehouse_ledger(?, ?)", 
                    year, materialCode != null ? materialCode : "");
                
                result.put("success", true);
                result.put("data", records);
                result.put("message", procMessage);
            } else {
                result.put("success", false);
                result.put("message", procMessage);
            }
            
            return result;
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "仓库账本数据生成失败: " + e.getMessage());
            return result;
        }
    }
    
    /**
     * 获取仓库账本数据
     */
    public Map<String, Object> getWarehouseLedger(LocalDate startDate, LocalDate endDate, Long materialId) {
        Map<String, Object> result = new HashMap<>();

        try {
            List<WarehouseLedger> ledgers;

            if (materialId != null && materialId > 0) {
                // 获取特定物料的账本
                ledgers = warehouseLedgerRepository.findByMaterialIdAndLedgerDateBetweenOrderByLedgerDateAsc(
                    materialId, startDate, endDate);
            } else {
                // 获取所有物料的账本
                ledgers = warehouseLedgerRepository.findByLedgerDateBetweenOrderByLedgerDateAsc(
                    startDate, endDate);
            }

            List<Map<String, Object>> data = new ArrayList<>();
            for (WarehouseLedger ledger : ledgers) {
                Map<String, Object> item = new HashMap<>();
                item.put("ledger_date", ledger.getLedgerDate()); // 修改为下划线命名
                item.put("document_code", ledger.getDocumentCode()); // 修改为下划线命名
                item.put("operation_type", ledger.getOperationType()); // 修改为下划线命名
                item.put("material_code", ledger.getMaterial().getMaterialCode()); // 修改为下划线命名
                item.put("material_name", ledger.getMaterial().getName()); // 修改为下划线命名
                item.put("specification", ledger.getMaterial().getSpecification());
                item.put("unit", ledger.getMaterial().getUnit());
                item.put("in_quantity", ledger.getInQuantity()); // 修改为下划线命名
                item.put("in_amount", ledger.getInAmount()); // 修改为下划线命名
                item.put("out_quantity", ledger.getOutQuantity()); // 修改为下划线命名
                item.put("out_amount", ledger.getOutAmount()); // 修改为下划线命名
                item.put("balance_quantity", ledger.getBalanceQuantity()); // 修改为下划线命名
                item.put("balance_amount", ledger.getBalanceAmount()); // 修改为下划线命名
                item.put("remark", ledger.getRemark());
                data.add(item);
            }

            result.put("success", true);
            result.put("data", data);
            return result;
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "获取仓库账本数据失败: " + e.getMessage());
            return result;
        }
    }

    /**
     * 进出仓单查询
     */
    public Map<String, Object> getInOutRecordsByProcedure(LocalDate startDate, LocalDate endDate, 
                                                         String materialCode, String operatorCode, String remarkKeyword) {
        Map<String, Object> result = new HashMap<>();

        try {
            // 使用存储过程查询进出仓单
            List<Map<String, Object>> records = jdbcTemplate.queryForList(
                "CALL class2_seat27_进出仓单查询(?, ?, ?, ?, ?)", 
                startDate, endDate, materialCode, operatorCode, remarkKeyword);

            result.put("success", true);
            result.put("data", records);
            result.put("message", "进出仓单查询完成");
            return result;
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "进出仓单查询失败: " + e.getMessage());
            return result;
        }
    }
}