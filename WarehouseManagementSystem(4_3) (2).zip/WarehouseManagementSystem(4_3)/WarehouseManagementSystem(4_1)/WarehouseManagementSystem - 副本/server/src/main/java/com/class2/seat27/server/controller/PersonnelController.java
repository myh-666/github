package com.class2.seat27.server.controller;

import com.class2.seat27.server.entity.User;
import com.class2.seat27.server.service.PersonnelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/personnel")
@CrossOrigin(origins = "*")
public class PersonnelController {

    @Autowired
    private PersonnelService personnelService;

    // 增加人员
    @PostMapping("/add")
    public ResponseEntity<Map<String, Object>> addPersonnel(@RequestBody User user) {
        Map<String, Object> response = new HashMap<>();
        try {
            User savedUser = personnelService.addPersonnel(user);
            response.put("success", true);
            response.put("message", "人员添加成功");
            response.put("data", savedUser);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return ResponseEntity.ok(response);
    }

    // 修改人员
    @PostMapping("/update")
    public ResponseEntity<Map<String, Object>> updatePersonnel(@RequestBody User user) {
        Map<String, Object> response = new HashMap<>();
        try {
            User updatedUser = personnelService.updatePersonnel(user);
            response.put("success", true);
            response.put("message", "人员修改成功");
            response.put("data", updatedUser);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return ResponseEntity.ok(response);
    }

    // 删除人员
    @PostMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> deletePersonnel(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();
        try {
            personnelService.deletePersonnel(id);
            response.put("success", true);
            response.put("message", "人员删除成功");
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return ResponseEntity.ok(response);
    }

    // 查询所有人员
    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllPersonnel() {
        Map<String, Object> response = new HashMap<>();
        try {
            List<User> personnelList = personnelService.getAllPersonnel();
            response.put("success", true);
            response.put("data", personnelList);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return ResponseEntity.ok(response);
    }


    @PostMapping("/addFromMap")
    public ResponseEntity<Map<String, Object>> addPersonnelFromMap(@RequestBody Map<String, Object> userData) {
        Map<String, Object> response = new HashMap<>();
        try {
            User savedUser = personnelService.addPersonnelFromMap(userData);
            response.put("success", true);
            response.put("message", "人员添加成功");
            response.put("data", savedUser);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return ResponseEntity.ok(response);
    }

    @PostMapping("/updateFromMap")
    public ResponseEntity<Map<String, Object>> updatePersonnelFromMap(@RequestBody Map<String, Object> userData) {
        Map<String, Object> response = new HashMap<>();
        try {
            User updatedUser = personnelService.updatePersonnelFromMap(userData);
            response.put("success", true);
            response.put("message", "人员修改成功");
            response.put("data", updatedUser);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return ResponseEntity.ok(response);
    }




    // 根据姓名模糊查询
    @GetMapping("/search/{name}")
    public ResponseEntity<Map<String, Object>> searchPersonnelByName(@PathVariable String name) {
        Map<String, Object> response = new HashMap<>();
        try {
            List<User> personnelList = personnelService.searchPersonnelByName(name);
            response.put("success", true);
            response.put("data", personnelList);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return ResponseEntity.ok(response);
    }

    // 根据人员代码查询
    @GetMapping("/code/{personnelCode}")
    public ResponseEntity<Map<String, Object>> getPersonnelByCode(@PathVariable String personnelCode) {
        Map<String, Object> response = new HashMap<>();
        try {
            User user = personnelService.getPersonnelByCode(personnelCode);
            response.put("success", true);
            response.put("data", user);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return ResponseEntity.ok(response);
    }

    // 根据ID查询人员
    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getPersonnelById(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();
        try {
            User user = personnelService.getPersonnelById(id);
            response.put("success", true);
            response.put("data", user);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return ResponseEntity.ok(response);
    }


//    // 用户授权
//    @PostMapping("/authorize")
//    public ResponseEntity<Map<String, Object>> authorizeUser(@RequestBody Map<String, Object> authRequest) {
//        Map<String, Object> response = new HashMap<>();
//        try {
//            Long personnelId = Long.valueOf(authRequest.get("personnelId").toString());
//            String role = (String) authRequest.get("role");
//
//            // 调用服务层进行授权
//            User user = personnelService.authorizeUser(personnelId, role);
//            response.put("success", true);
//            response.put("message", "用户授权成功");
//            response.put("data", user);
//        } catch (Exception e) {
//            response.put("success", false);
//            response.put("message", e.getMessage());
//        }
//        return ResponseEntity.ok(response);
//    }
}