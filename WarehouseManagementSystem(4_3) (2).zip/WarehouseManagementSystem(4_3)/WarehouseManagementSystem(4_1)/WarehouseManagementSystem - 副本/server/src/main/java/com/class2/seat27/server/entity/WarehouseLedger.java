
package com.class2.seat27.server.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * 仓库账本实体类
 * 用于记录物料的每日进出仓情况
 */
@Entity
@Table(name = "class2_seat27_warehouse_ledger")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class WarehouseLedger {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "ledger_date", nullable = false)
    private LocalDate ledgerDate;

    @Column(name = "document_code", nullable = false)
    private String documentCode;

    @Column(name = "operation_type", nullable = false)
    private String operationType; // "进仓" 或 "出仓"

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "material_id", nullable = false)
    private Material material;

    @Column(name = "in_quantity")
    private Integer inQuantity;

    @Column(name = "in_amount")
    private BigDecimal inAmount;

    @Column(name = "out_quantity")
    private Integer outQuantity;

    @Column(name = "out_amount")
    private BigDecimal outAmount;

    @Column(name = "balance_quantity", nullable = false)
    private Integer balanceQuantity;

    @Column(name = "balance_amount", nullable = false)
    private BigDecimal balanceAmount;

    @Column(name = "created_time")
    private LocalDate createdTime;

    @Column(name = "remark")
    private String remark;

    // 构造器
    public WarehouseLedger() {
        this.createdTime = LocalDate.now();
    }

    // getter 和 setter 方法
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public LocalDate getLedgerDate() { return ledgerDate; }
    public void setLedgerDate(LocalDate ledgerDate) {
        this.ledgerDate = ledgerDate;
    }

    public String getDocumentCode() { return documentCode; }
    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode;
    }

    public String getOperationType() { return operationType; }
    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public Material getMaterial() { return material; }
    public void setMaterial(Material material) {
        this.material = material;
    }

    public Integer getInQuantity() { return inQuantity; }
    public void setInQuantity(Integer inQuantity) {
        this.inQuantity = inQuantity;
    }

    public BigDecimal getInAmount() { return inAmount; }
    public void setInAmount(BigDecimal inAmount) {
        this.inAmount = inAmount;
    }

    public Integer getOutQuantity() { return outQuantity; }
    public void setOutQuantity(Integer outQuantity) {
        this.outQuantity = outQuantity;
    }

    public BigDecimal getOutAmount() { return outAmount; }
    public void setOutAmount(BigDecimal outAmount) {
        this.outAmount = outAmount;
    }

    public Integer getBalanceQuantity() { return balanceQuantity; }
    public void setBalanceQuantity(Integer balanceQuantity) {
        this.balanceQuantity = balanceQuantity;
    }

    public BigDecimal getBalanceAmount() { return balanceAmount; }
    public void setBalanceAmount(BigDecimal balanceAmount) {
        this.balanceAmount = balanceAmount;
    }

    public LocalDate getCreatedTime() { return createdTime; }
    public void setCreatedTime(LocalDate createdTime) { this.createdTime = createdTime; }

    public String getRemark() { return remark; }
    public void setRemark(String remark) { this.remark = remark; }
}
