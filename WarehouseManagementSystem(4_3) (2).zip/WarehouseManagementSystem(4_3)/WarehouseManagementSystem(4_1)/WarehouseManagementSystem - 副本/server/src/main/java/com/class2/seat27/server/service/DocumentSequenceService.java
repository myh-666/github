
package com.class2.seat27.server.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 单号序列服务
 * 用于生成唯一的进出仓单号，解决高并发下的单号重复问题
 */
@Service
public class DocumentSequenceService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // 使用本地缓存减少数据库访问
    private final Map<String, SequenceCache> sequenceCache = new ConcurrentHashMap<>();

    // 为每种单号类型使用单独的锁
    private final Map<String, ReentrantLock> locks = new ConcurrentHashMap<>();

    /**
     * 序列缓存类
     */
    private static class SequenceCache {
        private final String prefix;
        private final String date;
        private int currentSequence;
        private int maxSequence;
        private LocalDateTime lastUpdateTime;

        public SequenceCache(String prefix, String date, int currentSequence, int maxSequence) {
            this.prefix = prefix;
            this.date = date;
            this.currentSequence = currentSequence;
            this.maxSequence = maxSequence;
            this.lastUpdateTime = LocalDateTime.now();
        }

        public synchronized String getNextSequence() {
            // 如果已达到缓存的最大序列号，需要从数据库重新获取
            if (currentSequence >= maxSequence) {
                return null; // 表示需要重新加载
            }

            currentSequence++;
            lastUpdateTime = LocalDateTime.now();
            return prefix + date + String.format("%03d", currentSequence);
        }

        public boolean isExpired() {
            // 缓存5分钟后过期
            return lastUpdateTime.isBefore(LocalDateTime.now().minusMinutes(5));
        }
    }

    /**
     * 获取指定类型的下一个单号
     * @param documentType 单号类型 (INB, OUT, MIIN, MIOUT)
     * @return 唯一的单号
     */
    @Transactional
    public String getNextDocumentNumber(String documentType) {
        // 确保每种单号类型有对应的锁
        locks.putIfAbsent(documentType, new ReentrantLock());
        ReentrantLock lock = locks.get(documentType);

        lock.lock();
        try {
            String today = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));

            // 检查缓存是否有效
            SequenceCache cache = sequenceCache.get(documentType);
            if (cache != null && cache.date.equals(today) && !cache.isExpired()) {
                String nextSequence = cache.getNextSequence();
                if (nextSequence != null) {
                    return nextSequence;
                }
            }

            // 缓存无效或需要重新加载，从数据库获取
            return getNextNumberFromDatabase(documentType, today);
        } finally {
            lock.unlock();
        }
    }

    /**
     * 从数据库获取下一个单号
     * @param documentType 单号类型
     * @param today 今天的日期字符串
     * @return 唯一的单号
     */
    private String getNextNumberFromDatabase(String documentType, String today) {
        // 使用数据库序列表确保单号唯一性
        // 如果表不存在，创建它
        createSequenceTableIfNotExists();

        // 查询当前最大单号
        String sql = "SELECT max_document_code FROM document_sequence WHERE document_type = ? AND date_part = ?";
        String maxCode = null;
        try {
            maxCode = jdbcTemplate.queryForObject(sql, String.class, documentType, today);
        } catch (Exception e) {
            // 处理没有记录的情况，maxCode保持为null
            maxCode = null;
        }

        int nextSequence = 1;
        if (maxCode != null && !maxCode.isEmpty()) {
            try {
                // 提取序号部分并加1
                String sequenceStr = maxCode.substring(documentType.length() + 8);
                nextSequence = Integer.parseInt(sequenceStr) + 1;
            } catch (Exception e) {
                // 解析失败，从1开始
                nextSequence = 1;
            }
        }

        // 生成新的单号
        String newCode = documentType + today + String.format("%03d", nextSequence);

        // 更新数据库中的序列记录
        upsertDocumentSequence(documentType, today, newCode);

        // 更新缓存，预取10个序列号
        sequenceCache.put(documentType, new SequenceCache(documentType, today, nextSequence, nextSequence + 9));

        return newCode;
    }

    /**
     * 创建序列表（如果不存在）
     */
    private void createSequenceTableIfNotExists() {
        String createTableSql = """
            CREATE TABLE IF NOT EXISTS document_sequence (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                document_type VARCHAR(10) NOT NULL,
                date_part VARCHAR(8) NOT NULL,
                max_document_code VARCHAR(20) NOT NULL,
                created_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY uk_document_type_date (document_type, date_part)
            )
            """;

        jdbcTemplate.execute(createTableSql);
    }

    /**
     * 更新或插入序列记录
     * @param documentType 单号类型
     * @param date 日期部分
     * @param documentCode 单号
     */
    private void upsertDocumentSequence(String documentType, String date, String documentCode) {
        String upsertSql = """
            INSERT INTO document_sequence (document_type, date_part, max_document_code) 
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE 
            max_document_code = VALUES(max_document_code),
            updated_time = CURRENT_TIMESTAMP
            """;

        jdbcTemplate.update(upsertSql, documentType, date, documentCode);
    }
}
