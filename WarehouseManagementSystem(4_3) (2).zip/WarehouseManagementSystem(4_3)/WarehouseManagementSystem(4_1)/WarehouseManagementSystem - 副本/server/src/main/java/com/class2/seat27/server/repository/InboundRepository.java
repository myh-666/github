package com.class2.seat27.server.repository;

import com.class2.seat27.server.entity.Inbound;
import com.class2.seat27.server.entity.User;
import com.class2.seat27.server.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface InboundRepository extends JpaRepository<Inbound, Long> {
    Optional<Inbound> findByInboundCode(String inboundCode);

    List<Inbound> findByCreatedBy(User createdBy);

    List<Inbound> findByStatus(Status status);

    List<Inbound> findByInboundDateBetween(LocalDateTime startDate, LocalDateTime endDate);

    @Query("SELECT i FROM Inbound i WHERE i.status = :status AND i.inboundDate >= :startDate")
    List<Inbound> findByStatusAndInboundDateAfter(@Param("status") Status status, @Param("startDate") LocalDateTime startDate);

    @Query("SELECT i FROM Inbound i WHERE i.status = :status ORDER BY i.inboundDate DESC")
    List<Inbound> findByStatusOrderByInboundDateDesc(@Param("status") Status status);
    
    @Query("SELECT MAX(i.inboundCode) FROM Inbound i")
    String findMaxInboundCode();
    
    // 添加按创建时间倒序排列的第一个记录查询方法
    List<Inbound> findTop1ByOrderByCreatedTimeDesc();
    
    // 按日期范围查询进仓记录
    @Query("SELECT i FROM Inbound i WHERE DATE(i.inboundDate) BETWEEN DATE(:startDate) AND DATE(:endDate)")
    List<Inbound> findByDateRange(@Param("startDate") String startDate, @Param("endDate") String endDate);
    
    // 按物料ID和日期范围查询进仓记录
    @Query("SELECT i FROM Inbound i JOIN i.details d WHERE d.material.id = :materialId AND DATE(i.inboundDate) BETWEEN DATE(:startDate) AND DATE(:endDate)")
    List<Inbound> findByMaterialIdAndDateRange(@Param("materialId") Long materialId, @Param("startDate") String startDate, @Param("endDate") String endDate);
}