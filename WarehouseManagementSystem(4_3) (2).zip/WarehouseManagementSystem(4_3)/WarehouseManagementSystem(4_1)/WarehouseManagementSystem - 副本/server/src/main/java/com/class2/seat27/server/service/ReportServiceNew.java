package com.class2.seat27.server.service;

import com.class2.seat27.server.entity.*;
import com.class2.seat27.server.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.sql.Types;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * 报表服务类（新版）
 * 处理各类报表统计和打印功能
 */
@Service
public class ReportServiceNew {

    @Autowired
    private MaterialRepository materialRepository;

    @Autowired
    private InventoryRepository inventoryRepository;

    @Autowired
    private InboundRepository inboundRepository;

    @Autowired
    private InboundDetailRepository inboundDetailRepository;

    @Autowired
    private OutboundRepository outboundRepository;

    @Autowired
    private OutboundDetailRepository outboundDetailRepository;

    @Autowired
    private WarehouseLedgerRepository warehouseLedgerRepository;

    @Autowired
    private MaterialStatisticsRepository materialStatisticsRepository;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * 使用存储过程生成物料统计信息
     */
    public Map<String, Object> getMaterialStatisticsByProcedure(LocalDate startDate, LocalDate endDate) {
        Map<String, Object> result = new HashMap<>();

        try {
            // 直接调用存储过程获取数据结果集
            List<Map<String, Object>> records = jdbcTemplate.queryForList(
                "CALL class2_seat27_material_flow_statistics(?, ?)",
                startDate, endDate);

            result.put("success", true);
            result.put("data", records);
            result.put("message", "物料流量统计查询完成");

            return result;
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "物料统计数据生成失败: " + e.getMessage());
            return result;
        }
    }

    /**
     * 使用存储过程生成月度进出仓单数据
     */
    public Map<String, Object> getMonthlyRecordsByProcedure(int year, int month) {
        Map<String, Object> result = new HashMap<>();

        try {
            // 直接调用存储过程获取数据结果集
            List<Map<String, Object>> records = jdbcTemplate.queryForList(
                "CALL class2_seat27_monthly_records(?, ?)",
                year, month);

            result.put("success", true);
            result.put("data", records);
            result.put("message", "月度进出仓单查询完成");

            return result;
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "月度进出仓单数据生成失败: " + e.getMessage());
            return result;
        }
    }

    /**
     * 使用存储过程生成仓库账本数据
     */
    public Map<String, Object> getWarehouseLedgerByProcedure(int year, String materialCode) {
        Map<String, Object> result = new HashMap<>();

        try {
            // 使用SimpleJdbcCall调用存储过程
            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("class2_seat27_warehouse_ledger")
                .declareParameters(
                    new SqlParameter("p_year", Types.INTEGER),
                    new SqlParameter("p_material_code", Types.VARCHAR),
                    new SqlOutParameter("p_result", Types.INTEGER),
                    new SqlOutParameter("p_message", Types.VARCHAR)
                );

            // 准备输入参数
            Map<String, Object> inParams = new HashMap<>();
            inParams.put("p_year", year);
            inParams.put("p_material_code", materialCode != null ? materialCode : "");

            // 执行存储过程
            Map<String, Object> outParams = jdbcCall.execute(inParams);

            // 获取输出参数
            int procResult = (Integer) outParams.get("p_result");
            String procMessage = (String) outParams.get("p_message");

            if (procResult == 1) {
                // 直接调用存储过程获取数据结果集
                List<Map<String, Object>> records = jdbcTemplate.queryForList(
                    "CALL class2_seat27_warehouse_ledger(?, ?)",
                    year, materialCode);

                // 处理可能的空值
                for (Map<String, Object> record : records) {
                    for (String key : record.keySet()) {
                        if (record.get(key) == null) {
                            if (key.endsWith("quantity") || key.endsWith("amount")) {
                                record.put(key, 0);
                            } else {
                                record.put(key, "");
                            }
                        }
                    }
                }

                result.put("success", true);
                result.put("data", records);
                result.put("message", "仓库账本查询完成");
            } else {
                result.put("success", false);
                result.put("message", procMessage);
            }

            return result;
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "仓库账本数据生成失败: " + e.getMessage());
            return result;
        }
    }
}
