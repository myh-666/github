
package com.class2.seat27.server.service;

import com.class2.seat27.server.entity.Material;
import com.class2.seat27.server.repository.MaterialRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 低库存预警服务类
 * 用于生成低库存预警报表
 */
@Service
public class LowInventoryServiceV2 {

    @Autowired
    private MaterialRepository materialRepository;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * 生成低库存预警报表
     */
    @Transactional
    public Map<String, Object> generateLowInventoryWarning(LocalDate startDate, LocalDate endDate) {
        Map<String, Object> result = new HashMap<>();

        try {
            // 首先创建一个临时表，存储每种物料的最新库存记录
            String tempTableSql = "CREATE TEMPORARY TABLE IF NOT EXISTS latest_inventory AS " +
                    "SELECT i1.material_id, i1.quantity " +
                    "FROM class2_seat27_inventory i1 " +
                    "INNER JOIN (" +
                    "  SELECT material_id, MAX(id) as max_id " +
                    "  FROM class2_seat27_inventory " +
                    "  GROUP BY material_id" +
                    ") i2 ON i1.material_id = i2.material_id AND i1.id = i2.max_id";

            jdbcTemplate.execute(tempTableSql);

            // 查询低库存物料
            String sql = "SELECT " +
                "m.id AS materialId, " +
                "m.material_code AS materialCode, " +
                "m.name AS materialName, " +
                "m.specification, " +
                "m.unit, " +
                "COALESCE(i.quantity, 0) AS quantity, " +
                "m.min_stock, " +
                "CASE " +
                "  WHEN COALESCE(i.quantity, 0) = 0 THEN '缺货' " +
                "  WHEN COALESCE(i.quantity, 0) < m.min_stock THEN '库存不足' " +
                "  ELSE '库存正常' " +
                "END AS stock_status, " +
                "CASE " +
                "  WHEN COALESCE(i.quantity, 0) = 0 THEN '紧急' " +
                "  WHEN COALESCE(i.quantity, 0) < m.min_stock * 0.5 THEN '高' " +
                "  WHEN COALESCE(i.quantity, 0) < m.min_stock THEN '中' " +
                "  ELSE '低' " +
                "END AS warning_level " +
                "FROM " +
                "class2_seat27_material m " +
                "LEFT JOIN latest_inventory i ON m.id = i.material_id " +
                "WHERE " +
                "  COALESCE(i.quantity, 0) <= m.min_stock " +
                "  AND m.min_stock > 0 " +
                "ORDER BY " +
                "  stock_status, warning_level, quantity";
                
            // 输出SQL日志
            System.out.println("执行的SQL查询: " + sql);
            
            List<Map<String, Object>> lowInventoryMaterials = jdbcTemplate.queryForList(sql, new Object[]{});
            
            // 输出查询结果
            System.out.println("查询到的低库存物料数量: " + lowInventoryMaterials.size());
            for (Map<String, Object> material : lowInventoryMaterials) {
                System.out.println("物料信息: " + material.toString());
            }

            // 确保数据正确处理
            for (Map<String, Object> material : lowInventoryMaterials) {
                // 确保规格不为空
                if (material.get("specification") == null) {
                    material.put("specification", "");
                }

                // 确保最低库存不为空
                if (material.get("min_stock") == null) {
                    material.put("min_stock", 0);
                }
                
                // 添加阈值字段，用于前端显示
                material.put("threshold", material.get("min_stock"));
                
                // 添加当前库存字段，用于前端显示
                material.put("current_quantity", material.get("quantity"));
            }

            result.put("success", true);
            result.put("data", lowInventoryMaterials);
            result.put("message", "低库存预警查询完成");
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "低库存预警生成失败: " + e.getMessage());
        }

        return result;
    }
    
    /**
     * 根据指定阈值生成低库存预警报表
     */
    @Transactional
    public Map<String, Object> generateLowInventoryWarningByThreshold(LocalDate startDate, LocalDate endDate, BigDecimal threshold) {
        Map<String, Object> result = new HashMap<>();

        try {
            // 首先创建一个临时表，存储每种物料的最新库存记录
            String tempTableSql = "CREATE TEMPORARY TABLE IF NOT EXISTS latest_inventory AS " +
                    "SELECT i1.material_id, i1.quantity " +
                    "FROM class2_seat27_inventory i1 " +
                    "INNER JOIN (" +
                    "  SELECT material_id, MAX(id) as max_id " +
                    "  FROM class2_seat27_inventory " +
                    "  GROUP BY material_id" +
                    ") i2 ON i1.material_id = i2.material_id AND i1.id = i2.max_id";

            jdbcTemplate.execute(tempTableSql);

            // 查询低于阈值的物料
            String sql = "SELECT " +
                "m.id AS materialId, " +
                "m.material_code AS materialCode, " +
                "m.name AS materialName, " +
                "m.specification, " +
                "m.unit, " +
                "COALESCE(i.quantity, 0) AS quantity, " +
                "m.min_stock, " +
                "CASE " +
                "  WHEN COALESCE(i.quantity, 0) = 0 THEN '缺货' " +
                "  WHEN COALESCE(i.quantity, 0) < ? THEN '库存不足' " +
                "  ELSE '库存正常' " +
                "END AS stock_status, " +
                "CASE " +
                "  WHEN COALESCE(i.quantity, 0) = 0 THEN '紧急' " +
                "  WHEN COALESCE(i.quantity, 0) < ? * 0.5 THEN '高' " +
                "  WHEN COALESCE(i.quantity, 0) < ? THEN '中' " +
                "  ELSE '低' " +
                "END AS warning_level " +
                "FROM " +
                "class2_seat27_material m " +
                "LEFT JOIN latest_inventory i ON m.id = i.material_id " +
                "WHERE " +
                "  COALESCE(i.quantity, 0) <= ? " +
                "ORDER BY " +
                "  stock_status, warning_level, quantity";

            // 输出SQL日志
            System.out.println("执行的SQL查询(阈值模式): " + sql);

            // 使用参数化查询
            List<Map<String, Object>> lowInventoryMaterials = jdbcTemplate.queryForList(sql, new Object[]{threshold, threshold, threshold, threshold});

            // 输出查询结果
            System.out.println("查询到的低库存物料数量(阈值模式): " + lowInventoryMaterials.size());

            // 确保数据正确处理
            for (Map<String, Object> material : lowInventoryMaterials) {
                // 确保规格不为空
                if (material.get("specification") == null) {
                    material.put("specification", "");
                }

                // 确保最低库存不为空
                if (material.get("min_stock") == null) {
                    material.put("min_stock", 0);
                }

                // 添加阈值字段，用于前端显示
                material.put("threshold", threshold);

                // 添加当前库存字段，用于前端显示
                material.put("current_quantity", material.get("quantity"));
            }

            result.put("success", true);
            result.put("data", lowInventoryMaterials);
            result.put("message", "低库存预警查询完成");
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "低库存预警生成失败: " + e.getMessage());
        }

        return result;
    }
}
