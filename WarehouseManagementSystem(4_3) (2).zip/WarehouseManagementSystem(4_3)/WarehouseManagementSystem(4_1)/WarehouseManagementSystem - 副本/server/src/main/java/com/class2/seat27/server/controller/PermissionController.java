package com.class2.seat27.server.controller;

import com.class2.seat27.server.service.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/permissions")
@CrossOrigin(origins = "*")
public class PermissionController {

    @Autowired
    private PermissionService permissionService;

    /**
     * 获取所有权限资源
     */
    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllPermissions() {
        Map<String, Object> response = new HashMap<>();
        try {
            List<?> permissions = permissionService.getAllPermissions();
            response.put("success", true);
            response.put("data", permissions);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return ResponseEntity.ok(response);
    }

    /**
     * 获取用户的完整权限信息
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<Map<String, Object>> getUserPermissions(@PathVariable Long userId) {
        Map<String, Object> response = new HashMap<>();
        try {
            List<Map<String, Object>> userPermissions = permissionService.getUserFullPermissions(userId);
            response.put("success", true);
            response.put("data", userPermissions);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return ResponseEntity.ok(response);
    }

    /**
     * 更新用户权限
     */
    @PostMapping("/user/{userId}/update")
    public ResponseEntity<Map<String, Object>> updateUserPermissions(
            @PathVariable Long userId,
            @RequestBody Map<String, Object> request) {

        Map<String, Object> response = new HashMap<>();
        try {
            @SuppressWarnings("unchecked")
            Map<String, Boolean> permissions = (Map<String, Boolean>) request.get("permissions");
            String updateUser = (String) request.get("updateUser");

            boolean result = permissionService.updateUserPermissions(userId, permissions, updateUser);
            if (result) {
                response.put("success", true);
                response.put("message", "权限更新成功");
            } else {
                response.put("success", false);
                response.put("message", "权限更新失败");
            }
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return ResponseEntity.ok(response);
    }

    /**
     * 检查用户权限
     */
    @GetMapping("/user/{userId}/check/{resourceCode}")
    public ResponseEntity<Map<String, Object>> checkPermission(
            @PathVariable Long userId,
            @PathVariable String resourceCode) {

        Map<String, Object> response = new HashMap<>();
        try {
            boolean hasPermission = permissionService.checkPermission(userId, resourceCode);
            response.put("success", true);
            response.put("hasPermission", hasPermission);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return ResponseEntity.ok(response);
    }

    /**
     * 重置用户权限
     */
    @PostMapping("/user/{userId}/reset")
    public ResponseEntity<Map<String, Object>> resetUserPermissions(@PathVariable Long userId) {
        Map<String, Object> response = new HashMap<>();
        try {
            boolean result = permissionService.resetUserPermissions(userId);
            if (result) {
                response.put("success", true);
                response.put("message", "权限重置成功");
            } else {
                response.put("success", false);
                response.put("message", "权限重置失败");
            }
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return ResponseEntity.ok(response);
    }

    /**
     * 获取用户有权限的菜单
     */
    @GetMapping("/user/{userId}/menus")
    public ResponseEntity<Map<String, Object>> getUserMenus(@PathVariable Long userId) {
        Map<String, Object> response = new HashMap<>();
        try {
            List<String> menus = permissionService.getUserAllowedMenus(userId);
            response.put("success", true);
            response.put("data", menus);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return ResponseEntity.ok(response);
    }
}