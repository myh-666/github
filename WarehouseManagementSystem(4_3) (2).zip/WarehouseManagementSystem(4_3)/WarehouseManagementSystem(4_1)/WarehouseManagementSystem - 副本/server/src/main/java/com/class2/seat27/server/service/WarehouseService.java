package com.class2.seat27.server.service;

import com.class2.seat27.server.entity.*;
import com.class2.seat27.server.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Types;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class WarehouseService {

    @Autowired
    private MaterialRepository materialRepository;

    @Autowired
    private InventoryRepository inventoryRepository;

    @Autowired
    private InboundRepository inboundRepository;

    @Autowired
    private InboundDetailRepository inboundDetailRepository;

    @Autowired
    private OutboundRepository outboundRepository;

    @Autowired
    private OutboundDetailRepository outboundDetailRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private MultiInOutService multiInOutService;

    @Autowired
    private MultiInOutRecordRepository multiInOutRecordRepository;

    @Autowired
    private MultiInOutDetailRepository multiInOutDetailRepository;

    @Autowired
    private WarehouseLedgerRepository warehouseLedgerRepository;

    @Autowired
    private MaterialStatisticsRepository materialStatisticsRepository;

    @Autowired
    private javax.sql.DataSource dataSource;

    @Autowired
    private DocumentSequenceService documentSequenceService;

    private com.fasterxml.jackson.databind.ObjectMapper objectMapper = new com.fasterxml.jackson.databind.ObjectMapper();

    // 物料管理
    public List<Material> getAllMaterials() {
        return materialRepository.findAll();
    }

    // 获取所有物料列表，用于下拉框选择
    public List<Map<String, Object>> getAllMaterialsForSelection() {
        List<Material> materials = materialRepository.findAll();
        List<Map<String, Object>> result = new ArrayList<>();

        for (Material material : materials) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", material.getId());
            item.put("materialCode", material.getMaterialCode());
            item.put("name", material.getName());
            item.put("specification", material.getSpecification());
            item.put("unit", material.getUnit());
            result.add(item);
        }

        return result;
    }

    // 获取所有人员列表，用于经手人下拉框选择
    public List<Map<String, Object>> getAllPersonnelForSelection() {
        List<User> users = userService.getAllUsers();
        List<Map<String, Object>> result = new ArrayList<>();

        for (User user : users) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", user.getId());
            item.put("personnelCode", user.getPersonnelCode());
            item.put("username", user.getUsername());
            item.put("realName", user.getName());
            item.put("name", user.getName());
            result.add(item);
        }

        return result;
    }

    public Optional<Material> getMaterialById(Long id) {
        return materialRepository.findById(id);
    }

    public Optional<Material> getMaterialByCode(String materialCode) {
        return materialRepository.findByMaterialCode(materialCode);
    }

    @Transactional
    public Material saveMaterial(Material material) {
        // 确保新增物料时不会误更新已有物料
        if (material.getId() == null) {
            // 新物料，总是自动生成物料编码，确保唯一性
            String maxCode = materialRepository.findMaxMaterialCode();
            // 处理数据库中没有物料记录的情况
            if (maxCode == null) {
                maxCode = "";
            }
            String newCode = generateMaterialCode(maxCode);
            material.setMaterialCode(newCode);

            // 确保createdTime为null，让JPA自动设置
            material.setCreatedTime(null);

            // 保存物料
            Material savedMaterial = materialRepository.save(material);

            // 如果新物料有初始数量，创建库存记录
            if (material.getQuantity() != null && material.getQuantity() > 0) {
                Inventory inventory = new Inventory();
                inventory.setMaterial(savedMaterial);
                inventory.setQuantity(material.getQuantity());
                inventoryRepository.save(inventory);

                // 同时更新物料表中的数量
                savedMaterial.setQuantity(material.getQuantity());
                materialRepository.save(savedMaterial);
            }

            return savedMaterial;
        } else {
            // 更新已有物料，保持原有创建时间
            Material existing = materialRepository.findById(material.getId()).orElse(null);
            if (existing != null) {
                material.setCreatedTime(existing.getCreatedTime());

                // 如果数量发生变化，使用存储过程更新
                if (!Objects.equals(existing.getQuantity(), material.getQuantity())) {
                    SimpleJdbcCall jdbcCall = new SimpleJdbcCall(dataSource)
                            .withProcedureName("update_material_quantity")
                            .declareParameters(
                                    new SqlParameter("p_material_id", Types.BIGINT),
                                    new SqlParameter("p_new_quantity", Types.INTEGER),
                                    new SqlOutParameter("p_result", Types.INTEGER),
                                    new SqlOutParameter("p_message", Types.VARCHAR)
                            );

                    Map<String, Object> inParams = new HashMap<>();
                    inParams.put("p_material_id", material.getId());
                    inParams.put("p_new_quantity", material.getQuantity());

                    Map<String, Object> outParams = jdbcCall.execute(inParams);
                    int result = (Integer) outParams.get("p_result");
                    String message = (String) outParams.get("p_message");

                    if (result != 1) {
                        throw new RuntimeException("更新物料数量失败: " + message);
                    }

                    // 存储过程已经更新了物料表中的数量，所以不需要再更新
                    // 重新获取最新的物料数据
                    return materialRepository.findById(material.getId()).orElse(null);
                }
            }

            // 保存物料的其他属性（不包括数量，数量已通过存储过程更新）
            Integer quantity = material.getQuantity();
            material.setQuantity(existing.getQuantity()); // 临时设置旧值，避免直接修改数量
            Material savedMaterial = materialRepository.save(material);
            savedMaterial.setQuantity(quantity); // 恢复新值用于显示

            return savedMaterial;
        }
    }

    @Transactional
    public void deleteMaterial(Long id) {
        // 先删除相关的仓库账本记录
        warehouseLedgerRepository.deleteByMaterialId(id);
        // 再删除相关的物料统计记录
        materialStatisticsRepository.deleteByMaterialId(id);
        // 然后删除相关的进仓明细记录
        inboundDetailRepository.deleteByMaterialId(id);
        // 接着删除相关的出仓明细记录
        outboundDetailRepository.deleteByMaterialId(id);
        // 再删除相关的库存记录
        inventoryRepository.deleteByMaterialId(id);
        // 最后删除物料
        materialRepository.deleteById(id);
    }

    public List<Material> searchMaterials(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return materialRepository.findAll();
        }
        return materialRepository.findByNameContainingIgnoreCase(keyword);
    }

    /**
     * 多条件搜索物料
     * @param name 物料名称
     * @param code 物料编码
     * @param spec 物料规格
     * @param unit 物料单位
     * @return 符合条件的物料列表
     */
    public List<Material> searchMaterials(String name, String code, String spec, String unit) {
        // 构建查询条件
        boolean hasName = name != null && !name.trim().isEmpty();
        boolean hasCode = code != null && !code.trim().isEmpty();
        boolean hasSpec = spec != null && !spec.trim().isEmpty();
        boolean hasUnit = unit != null && !unit.trim().isEmpty();

        // 如果没有任何条件，返回所有物料
        if (!hasName && !hasCode && !hasSpec && !hasUnit) {
            return materialRepository.findAll();
        }

        // 使用自定义查询方法进行多条件搜索
        List<Material> materials = materialRepository.findByMultipleConditions(
                hasName ? name.trim() : null,
                hasCode ? code.trim() : null,
                hasSpec ? spec.trim() : null,
                hasUnit ? unit.trim() : null
        );

        return materials;
    }

    /**
     * 检查物料编码是否存在
     * @param materialCode 物料编码
     * @return 是否存在
     */
    public boolean checkMaterialCodeExists(String materialCode) {
        return materialRepository.findByMaterialCode(materialCode).isPresent();
    }

    /**
     * 获取所有不重复的单位
     * @return 所有不重复的单位列表
     */
    public List<String> getAllDistinctUnits() {
        return materialRepository.findAllDistinctUnits();
    }

    // 库存管理
    public List<Inventory> getAllInventories() {
        return inventoryRepository.findAll();
    }

    public List<Map<String, Object>> getAllInventoryWithDetails() {
        List<Inventory> inventories = inventoryRepository.findAll();
        return getAllInventoryWithDetails(inventories);
    }

    public List<Map<String, Object>> getAllInventoryWithDetails(List<Inventory> inventories) {
        List<Map<String, Object>> result = new ArrayList<>();

        for (Inventory inventory : inventories) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", inventory.getId());

            // 获取物料信息
            Material material = inventory.getMaterial();
            if (material != null) {
                item.put("materialId", material.getId());
                item.put("materialCode", material.getMaterialCode());
                item.put("materialName", material.getName());
                item.put("specification", material.getSpecification());
                item.put("unit", material.getUnit());
                item.put("minStock", material.getMinStock());
            } else {
                item.put("materialId", null);
                item.put("materialCode", null);
                item.put("materialName", null);
                item.put("specification", null);
                item.put("unit", null);
                item.put("minStock", null);
            }

            item.put("quantity", inventory.getQuantity() != null ? inventory.getQuantity() : 0);
            item.put("lastInboundTime", inventory.getLastInboundTime());
            item.put("lastOutboundTime", inventory.getLastOutboundTime());
            item.put("updatedTime", inventory.getUpdatedTime());

            // 计算库存价值（这里可以根据业务需求调整）
            BigDecimal unitPrice = getAverageUnitPrice(material != null ? material.getId() : null);
            BigDecimal totalValue = unitPrice.multiply(new BigDecimal(inventory.getQuantity() != null ? inventory.getQuantity() : 0));
            item.put("unitPrice", unitPrice);
            item.put("totalValue", totalValue);

            result.add(item);
        }

        return result;
    }

    // 辅助方法：获取物料的平均单价
    private BigDecimal getAverageUnitPrice(Long materialId) {
        if (materialId == null) {
            return BigDecimal.ZERO;
        }

        try {
            // 查询最近的进仓记录获取平均单价
            String sql = "SELECT AVG(unit_price) as avg_price FROM class2_seat27_inbound_detail " +
                    "WHERE material_id = ? ORDER BY id DESC LIMIT 5";

            org.springframework.jdbc.core.JdbcTemplate jdbcTemplate = new org.springframework.jdbc.core.JdbcTemplate(dataSource);
            BigDecimal avgPrice = jdbcTemplate.queryForObject(sql, BigDecimal.class, materialId);

            return avgPrice != null ? avgPrice : BigDecimal.ZERO;
        } catch (Exception e) {
            return BigDecimal.ZERO;
        }
    }

    public Optional<Inventory> getInventoryByMaterialId(Long materialId) {
        return inventoryRepository.findByMaterialId(materialId);
    }

    public List<Inventory> getLowStockInventories() {
        return inventoryRepository.findLowStockInventories();
    }

    public List<Inventory> getLowStockInventories(BigDecimal threshold) {
        return inventoryRepository.findLowStockInventories(threshold);
    }

    public List<Inventory> searchInventories(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return inventoryRepository.findAll();
        }
        return inventoryRepository.findByMaterialNameContainingIgnoreCase(keyword);
    }

    /**
     * 根据物料编码和物料名称搜索库存
     * @param materialCode 物料编码
     * @param materialName 物料名称
     * @return 符合条件的库存列表
     */
    public List<Inventory> searchInventories(String materialCode, String materialName) {
        // 如果两个参数都为空，则返回所有库存
        if ((materialCode == null || materialCode.trim().isEmpty()) &&
                (materialName == null || materialName.trim().isEmpty())) {
            return inventoryRepository.findAll();
        }

        // 如果只提供了物料编码，则只按物料编码搜索
        if ((materialName == null || materialName.trim().isEmpty()) &&
                (materialCode != null && !materialCode.trim().isEmpty())) {
            return inventoryRepository.findByMaterialCodeContainingIgnoreCase(materialCode);
        }

        // 如果只提供了物料名称，则只按物料名称搜索
        if ((materialCode == null || materialCode.trim().isEmpty()) &&
                (materialName != null && !materialName.trim().isEmpty())) {
            return inventoryRepository.findByMaterialNameContainingIgnoreCase(materialName);
        }

        // 如果两个参数都提供了，则同时按两个条件搜索
        return inventoryRepository.findByMaterialCodeAndNameContainingIgnoreCase(materialCode, materialName);
    }

    @Transactional
    public Inventory updateInventory(Long materialId, Integer quantity, User updatedBy) {
        // 添加悲观锁，防止并发问题
        Inventory inventory = inventoryRepository.findByMaterialIdWithLock(materialId)
                .orElse(new Inventory());

        Material material = materialRepository.findById(materialId)
                .orElseThrow(() -> new RuntimeException("物料不存在"));

        inventory.setMaterial(material);
        inventory.setQuantity(quantity);
        inventory.setUpdatedBy(updatedBy);
        inventory.setUpdatedTime(LocalDateTime.now());

        // 记录仓库账本
        WarehouseLedger ledger = new WarehouseLedger();
        ledger.setLedgerDate(LocalDate.now());
        ledger.setDocumentCode("手动调整");
        ledger.setOperationType("库存调整");
        ledger.setMaterial(material);

        Integer currentQuantity = inventory.getQuantity() != null ? inventory.getQuantity() : 0;
        if (quantity > currentQuantity) {
            // 增加库存
            ledger.setInQuantity(quantity - currentQuantity);
            ledger.setInAmount(BigDecimal.ZERO);
            ledger.setOutQuantity(0);
            ledger.setOutAmount(BigDecimal.ZERO);
        } else {
            // 减少库存
            ledger.setInQuantity(0);
            ledger.setInAmount(BigDecimal.ZERO);
            ledger.setOutQuantity(currentQuantity - quantity);
            ledger.setOutAmount(BigDecimal.ZERO);
        }

        ledger.setBalanceQuantity(quantity);
        ledger.setBalanceAmount(BigDecimal.ZERO);
        ledger.setRemark("手动库存调整");
        warehouseLedgerRepository.save(ledger);

        return inventoryRepository.save(inventory);
    }

    // 进仓管理
    public List<Inbound> getAllInbounds() {
        return inboundRepository.findAll();
    }

    public List<Inbound> getInboundsByStatus(Status status) {
        return inboundRepository.findByStatus(status);
    }

    public Optional<Inbound> getInboundById(Long id) {
        return inboundRepository.findById(id);
    }

    public Optional<Inbound> getInboundByCode(String inboundCode) {
        return inboundRepository.findByInboundCode(inboundCode);
    }

    @Transactional
    public Inbound saveInbound(Inbound inbound, List<InboundDetail> details) {
        // 设置进仓单号
        if (inbound.getInboundCode() == null || inbound.getInboundCode().isEmpty()) {
            String maxCode = inboundRepository.findMaxInboundCode();
            String newCode = generateInboundCode(maxCode);
            inbound.setInboundCode(newCode);
        }

        // 设置创建时间和创建人
        if (inbound.getCreatedTime() == null) {
            inbound.setCreatedTime(LocalDateTime.now());
        }
        if (inbound.getCreatedBy() == null) {
            throw new RuntimeException("进仓单必须指定创建人");
        }

        // 保存进仓单
        inbound = inboundRepository.save(inbound);

        // 设置明细并保存
        for (InboundDetail detail : details) {
            detail.setInbound(inbound);
            inboundDetailRepository.save(detail);
        }

        inbound.setDetails(details);
        return inbound;
    }

    @Transactional
    public Inbound confirmInbound(Long inboundId) {
        Inbound inbound = inboundRepository.findById(inboundId)
                .orElseThrow(() -> new RuntimeException("进仓单不存在"));

        if (inbound.getStatus() != Status.DRAFT) {
            throw new RuntimeException("只能确认草稿状态的进仓单");
        }

        // 更新进仓单状态
        inbound.setStatus(Status.CONFIRMED);
        inboundRepository.save(inbound);

        return inbound;
    }

    @Transactional
    public Inbound completeInbound(Long inboundId) {
        Inbound inbound = inboundRepository.findById(inboundId)
                .orElseThrow(() -> new RuntimeException("进仓单不存在"));

        if (inbound.getStatus() != Status.CONFIRMED) {
            throw new RuntimeException("只能完成已确认的进仓单");
        }

        // 检查明细
        List<InboundDetail> details = inboundDetailRepository.findByInbound(inbound);
        if (details.isEmpty()) {
            throw new RuntimeException("进仓单明细不能为空");
        }

        // 更新库存
        for (InboundDetail detail : details) {
            Long materialId = detail.getMaterial().getId();
            Integer inboundQuantity = detail.getQuantity().intValue();

            // 使用悲观锁获取库存记录，确保高并发下数据一致性
            Inventory inventory = inventoryRepository.findByMaterialIdWithLock(materialId)
                    .orElse(new Inventory());

            Material material = materialRepository.findById(materialId)
                    .orElseThrow(() -> new RuntimeException("物料不存在"));

            inventory.setMaterial(material);

            // 更新库存数量
            Integer currentQuantity = inventory.getQuantity() != null ? inventory.getQuantity() : 0;
            Integer newQuantity = currentQuantity + inboundQuantity;
            inventory.setQuantity(newQuantity);

            // 更新最后进仓时间
            inventory.setLastInboundTime(LocalDateTime.now());

            // 设置更新人和更新时间
            inventory.setUpdatedBy(inbound.getCreatedBy());
            inventory.setUpdatedTime(LocalDateTime.now());

            inventoryRepository.save(inventory);

            // 记录仓库账本
            WarehouseLedger ledger = new WarehouseLedger();
            ledger.setLedgerDate(LocalDate.now());
            ledger.setDocumentCode(inbound.getInboundCode());
            ledger.setOperationType("进仓");
            ledger.setMaterial(material);
            ledger.setInQuantity(inboundQuantity);
            ledger.setInAmount(detail.getTotalPrice());
            ledger.setOutQuantity(0);
            ledger.setOutAmount(BigDecimal.ZERO);
            ledger.setBalanceQuantity(newQuantity);
            ledger.setBalanceAmount(new BigDecimal(newQuantity).multiply(detail.getUnitPrice() != null ? detail.getUnitPrice() : BigDecimal.ONE));
            ledger.setRemark(detail.getRemark());
            warehouseLedgerRepository.save(ledger);
        }

        // 更新进仓单状态
        inbound.setStatus(Status.COMPLETED);
        inboundRepository.save(inbound);

        return inbound;
    }

    // 出仓管理
    public List<Outbound> getAllOutbounds() {
        return outboundRepository.findAll();
    }

    public List<Outbound> getOutboundsByStatus(Status status) {
        return outboundRepository.findByStatus(status);
    }

    public Optional<Outbound> getOutboundById(Long id) {
        return outboundRepository.findById(id);
    }

    public Optional<Outbound> getOutboundByCode(String outboundCode) {
        return outboundRepository.findByOutboundCode(outboundCode);
    }

    @Transactional
    public Outbound saveOutbound(Outbound outbound, List<OutboundDetail> details) {
        // 设置出仓单号
        if (outbound.getOutboundCode() == null || outbound.getOutboundCode().isEmpty()) {
            String maxCode = outboundRepository.findMaxOutboundCode();
            String newCode = generateOutboundCode(maxCode);
            outbound.setOutboundCode(newCode);
        }

        // 设置创建时间和创建人
        if (outbound.getCreatedTime() == null) {
            outbound.setCreatedTime(LocalDateTime.now());
        }
        if (outbound.getCreatedBy() == null) {
            throw new RuntimeException("出仓单必须指定创建人");
        }

        // 保存出仓单
        outbound = outboundRepository.save(outbound);

        // 设置明细并保存
        for (OutboundDetail detail : details) {
            detail.setOutbound(outbound);
            outboundDetailRepository.save(detail);
        }

        outbound.setDetails(details);
        return outbound;
    }

    @Transactional
    public Outbound confirmOutbound(Long outboundId) {
        Outbound outbound = outboundRepository.findById(outboundId)
                .orElseThrow(() -> new RuntimeException("出仓单不存在"));

        if (outbound.getStatus() != Status.DRAFT) {
            throw new RuntimeException("只能确认草稿状态的出仓单");
        }

        // 更新出仓单状态
        outbound.setStatus(Status.CONFIRMED);
        outboundRepository.save(outbound);

        return outbound;
    }

    @Transactional
    public Outbound completeOutbound(Long outboundId) {
        Outbound outbound = outboundRepository.findById(outboundId)
                .orElseThrow(() -> new RuntimeException("出仓单不存在"));

        if (outbound.getStatus() != Status.CONFIRMED) {
            throw new RuntimeException("只能完成已确认的出仓单");
        }

        // 检查明细
        List<OutboundDetail> details = outboundDetailRepository.findByOutbound(outbound);
        if (details.isEmpty()) {
            throw new RuntimeException("出仓单明细不能为空");
        }

        // 检查库存并更新
        for (OutboundDetail detail : details) {
            Long materialId = detail.getMaterial().getId();
            Integer outboundQuantity = detail.getQuantity();

            Inventory inventory = inventoryRepository.findByMaterialId(materialId)
                    .orElseThrow(() -> new RuntimeException("物料库存不存在"));

            Integer currentQuantity = inventory.getQuantity() != null ? inventory.getQuantity() : 0;

            // 检查库存是否足够
            if (currentQuantity < outboundQuantity) {
                throw new RuntimeException("物料 " + inventory.getMaterial().getName() + " 库存不足，当前库存：" + currentQuantity + "，需要：" + outboundQuantity);
            }

            // 更新库存数量
            Integer newQuantity = currentQuantity - outboundQuantity;
            inventory.setQuantity(newQuantity);

            // 更新最后出仓时间
            inventory.setLastOutboundTime(LocalDateTime.now());

            // 设置更新人和更新时间
            inventory.setUpdatedBy(outbound.getCreatedBy());
            inventory.setUpdatedTime(LocalDateTime.now());

            inventoryRepository.save(inventory);

            // 记录仓库账本
            Material material = detail.getMaterial();
            WarehouseLedger ledger = new WarehouseLedger();
            ledger.setLedgerDate(LocalDate.now());
            ledger.setDocumentCode(outbound.getOutboundCode());
            ledger.setOperationType("出仓");
            ledger.setMaterial(material);
            ledger.setInQuantity(0);
            ledger.setInAmount(BigDecimal.ZERO);
            ledger.setOutQuantity(outboundQuantity);
            ledger.setOutAmount(detail.getTotalPrice());
            ledger.setBalanceQuantity(newQuantity);
            ledger.setBalanceAmount(new BigDecimal(newQuantity).multiply(detail.getUnitPrice() != null ? detail.getUnitPrice() : BigDecimal.ONE));
            ledger.setRemark(detail.getRemark());
            warehouseLedgerRepository.save(ledger);
        }

        // 更新出仓单状态
        outbound.setStatus(Status.COMPLETED);
        outboundRepository.save(outbound);

        return outbound;
    }

    // 辅助方法：查找最大物料编码
    public String findMaxMaterialCode() {
        return materialRepository.findMaxMaterialCode();
    }

    // 辅助方法：生成物料编码
    public String generateMaterialCode(String maxCode) {
        return documentSequenceService.getNextDocumentNumber("MAT");
    }

    // 辅助方法：生成进仓单号
    public String generateInboundCode(String maxCode) {
        return documentSequenceService.getNextDocumentNumber("INB");
    }

    // 辅助方法：生成出仓单号
    public String generateOutboundCode(String maxCode) {
        return documentSequenceService.getNextDocumentNumber("OUT");
    }

    // 生成多物料进仓单号
    public String generateMultiInboundCode() {
        return documentSequenceService.getNextDocumentNumber("MIIN");
    }

    // 生成多物料出仓单号
    public String generateMultiOutboundCode() {
        return documentSequenceService.getNextDocumentNumber("MIOUT");
    }

    // 多物料进仓服务方法
    @Transactional
    public Map<String, Object> processMultiInbound(String documentCode, String operatorCode, String handlerCode, String remark, List<Map<String, Object>> materials) {
        // 直接调用MultiInOutService处理
        return multiInOutService.processMultiInbound(documentCode, operatorCode, handlerCode, remark, materials);
    }

    // 多物料出仓服务方法
    @Transactional
    public Map<String, Object> processMultiOutbound(String documentCode, String operatorCode, String handlerCode, String remark, List<Map<String, Object>> materials) {
        // 直接调用MultiInOutService处理
        return multiInOutService.processMultiOutbound(documentCode, operatorCode, handlerCode, remark, materials);
    }

    // 获取所有多物料进出仓记录
    public List<MultiInOutRecord> getAllMultiInOutRecords() {
        return multiInOutRecordRepository.findAll();
    }

    // 根据操作类型获取多物料进出仓记录
    public List<MultiInOutRecord> getMultiInOutRecordsByType(String operationType) {
        return multiInOutRecordRepository.findByOperationType(operationType);
    }

    // 单物料进仓服务方法
    @Transactional
    public Map<String, Object> processSingleInbound(Long materialId, Integer quantity, BigDecimal unitPrice, BigDecimal totalPrice, String operatorCode, String handlerCode, String remark) {
        // 确保数量为int类型
        if (quantity == null) {
            throw new RuntimeException("数量不能为空");
        }

        try {
            // 获取物料信息
            Material material = materialRepository.findById(materialId)
                    .orElseThrow(() -> new RuntimeException("物料不存在"));

            // 创建进仓单
            Inbound inbound = new Inbound();
            inbound.setInboundCode(generateInboundCode(inboundRepository.findMaxInboundCode()));
            inbound.setInboundDate(LocalDateTime.now());
            inbound.setRemark(remark != null ? remark : "单物料进仓");
            inbound.setStatus(Status.DRAFT);

            // 获取操作人
            User operator = userService.getUserByUsername(operatorCode);
            if (operator == null) {
                throw new RuntimeException("操作人不存在");
            }
            inbound.setCreatedBy(operator);

            // 保存进仓单
            inbound = inboundRepository.save(inbound);

            // 创建进仓明细
            InboundDetail detail = new InboundDetail();
            detail.setInbound(inbound);
            detail.setMaterial(material);
            detail.setQuantity(quantity);
            detail.setUnitPrice(unitPrice);
            detail.setTotalPrice(totalPrice);
            detail.setRemark(remark != null ? remark : "单物料进仓明细");

            // 保存明细
            inboundDetailRepository.save(detail);

            // 准备返回结果
            Map<String, Object> result = new HashMap<>();
            result.put("result", 1);
            result.put("message", "单物料进仓成功");

            Map<String, Object> data = new HashMap<>();
            data.put("inboundId", inbound.getId());
            data.put("inboundCode", inbound.getInboundCode());
            data.put("materialId", material.getId());
            data.put("materialName", material.getName());
            data.put("quantity", quantity);
            data.put("unitPrice", unitPrice);
            data.put("totalPrice", totalPrice);
            data.put("status", inbound.getStatus().name());

            result.put("data", data);
            return result;
        } catch (Exception e) {
            Map<String, Object> result = new HashMap<>();
            result.put("result", 0);
            result.put("message", "单物料进仓失败: " + e.getMessage());
            return result;
        }
    }

    // 单物料出仓服务方法
    @Transactional
    public Map<String, Object> processSingleOutbound(Long materialId, Integer quantity, BigDecimal unitPrice, BigDecimal totalPrice, String operatorCode, String handlerCode, String remark) {
        // 确保数量为int类型
        if (quantity == null) {
            throw new RuntimeException("数量不能为空");
        }

        try {
            // 获取物料信息
            Material material = materialRepository.findById(materialId)
                    .orElseThrow(() -> new RuntimeException("物料不存在"));

            // 检查库存
            Inventory inventory = inventoryRepository.findByMaterialId(materialId)
                    .orElseThrow(() -> new RuntimeException("物料库存不存在"));

            Integer currentQuantity = inventory.getQuantity() != null ? inventory.getQuantity() : 0;
            if (currentQuantity < quantity) {
                throw new RuntimeException("物料 " + material.getName() + " 库存不足，当前库存：" + currentQuantity + "，需要：" + quantity);
            }

            // 创建出仓单
            Outbound outbound = new Outbound();
            outbound.setOutboundCode(generateOutboundCode(outboundRepository.findMaxOutboundCode()));
            outbound.setOutboundDate(LocalDateTime.now());
            outbound.setRemark(remark != null ? remark : "单物料出仓");
            outbound.setStatus(Status.DRAFT);

            // 获取操作人
            User operator = userService.getUserByUsername(operatorCode);
            if (operator == null) {
                throw new RuntimeException("操作人不存在");
            }
            outbound.setCreatedBy(operator);

            // 保存出仓单
            outbound = outboundRepository.save(outbound);

            // 创建出仓明细
            OutboundDetail detail = new OutboundDetail();
            detail.setOutbound(outbound);
            detail.setMaterial(material);
            detail.setQuantity(quantity);
            detail.setUnitPrice(unitPrice);
            detail.setTotalPrice(totalPrice);
            detail.setRemark(remark != null ? remark : "单物料出仓明细");

            // 保存明细
            outboundDetailRepository.save(detail);

            // 准备返回结果
            Map<String, Object> result = new HashMap<>();
            result.put("result", 1);
            result.put("message", "单物料出仓成功");

            Map<String, Object> data = new HashMap<>();
            data.put("outboundId", outbound.getId());
            data.put("outboundCode", outbound.getOutboundCode());
            data.put("materialId", material.getId());
            data.put("materialName", material.getName());
            data.put("quantity", quantity);
            data.put("unitPrice", unitPrice);
            data.put("totalPrice", totalPrice);
            data.put("status", outbound.getStatus().name());

            result.put("data", data);
            return result;
        } catch (Exception e) {
            Map<String, Object> result = new HashMap<>();
            result.put("result", 0);
            result.put("message", "单物料出仓失败: " + e.getMessage());
            return result;
        }
    }

    // 根据单据编号获取多物料进出仓记录
    public Optional<MultiInOutRecord> getMultiInOutRecordByCode(String documentCode) {
        return multiInOutRecordRepository.findByDocumentCode(documentCode);
    }

    // 根据状态获取多物料进出仓记录
    public List<MultiInOutRecord> getMultiInOutRecordsByStatus(Status status) {
        return multiInOutRecordRepository.findByStatus(status);
    }

    // 获取多物料进出仓记录详情
    public Map<String, Object> getMultiInOutRecordDetails(String documentCode) {
        Optional<MultiInOutRecord> record = multiInOutRecordRepository.findByDocumentCode(documentCode);
        if (!record.isPresent()) {
            Map<String, Object> result = new HashMap<>();
            result.put("success", false);
            result.put("message", "多物料进出仓记录不存在");
            return result;
        }

        MultiInOutRecord multiRecord = record.get();
        List<MultiInOutDetail> details = multiInOutDetailRepository.findByMultiInOutRecord(multiRecord);

        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("record", multiRecord);
        result.put("details", details);
        return result;
    }

    // 将列表转换为JSON字符串
    private String convertToJson(List<Map<String, Object>> list) {
        try {
            return objectMapper.writeValueAsString(list);
        } catch (Exception e) {
            throw new RuntimeException("JSON转换失败: " + e.getMessage());
        }
    }

    // 调用存储过程
    @SuppressWarnings("unchecked")
    private Map<String, Object> callStoredProcedure(String procedureName, Object[] params) {
        try {
            // 使用JdbcTemplate调用存储过程
            org.springframework.jdbc.core.JdbcTemplate jdbcTemplate = new org.springframework.jdbc.core.JdbcTemplate(dataSource);

            // 创建存储过程调用
            org.springframework.jdbc.core.simple.SimpleJdbcCall jdbcCall = new org.springframework.jdbc.core.simple.SimpleJdbcCall(jdbcTemplate)
                    .withProcedureName(procedureName);

            // 执行存储过程
            Map<String, Object> out = jdbcCall.execute(params);

            // 处理返回结果
            Map<String, Object> result = new HashMap<>();

            // 根据存储过程名称处理不同的返回值
            if (procedureName.equals("class2_seat27_多物料进仓") || procedureName.equals("class2_seat27_多物料出仓")) {
                result.put("result", out.get("p_result"));
                result.put("message", out.get("p_message"));
            } else {
                result.put("result", out.get("p_result"));
                result.put("message", out.get("p_message"));
            }

            // 处理返回的数据
            Object data = out.get("p_data");
            if (data != null) {
                if (data instanceof java.sql.Array) {
                    // 如果是数组类型，转换为List
                    java.sql.Array array = (java.sql.Array) data;
                    result.put("data", Arrays.asList((Object[]) array.getArray()));
                } else {
                    result.put("data", data);
                }
            } else {
                result.put("data", new ArrayList<>());
            }

            return result;
        } catch (Exception e) {
            // 记录错误日志
            System.err.println("调用存储过程失败: " + e.getMessage());
            e.printStackTrace();

            // 返回错误结果
            Map<String, Object> result = new HashMap<>();
            result.put("result", 0);
            result.put("message", "调用存储过程失败: " + e.getMessage());
            result.put("data", new ArrayList<>());
            return result;
        }
    }

    /**
     * 获取物料的历史最低库存
     * @param material 物料
     * @return 历史最低库存
     */
    public BigDecimal getHistoryMinStock(Material material) {
        // 从仓库账本中查询该物料的所有记录
        List<WarehouseLedger> ledgerRecords = warehouseLedgerRepository
                .findByMaterialAndLedgerDateBetween(material,
                        LocalDate.now().minusYears(1), // 默认查询最近一年的数据
                        LocalDate.now());

        // 如果没有历史记录，返回当前库存
        if (ledgerRecords.isEmpty()) {
            Integer quantity = material.getQuantity();
            return quantity != null ? new BigDecimal(quantity) : BigDecimal.ZERO;
        }

        // 从仓库账本记录中找出最小的结存数量
        return ledgerRecords.stream()
                .map(ledger -> {
                    Integer balanceQuantity = ledger.getBalanceQuantity();
                    return balanceQuantity != null ? new BigDecimal(balanceQuantity) : BigDecimal.ZERO;
                })
                .min(BigDecimal::compareTo)
                .orElseGet(() -> {
                    Integer quantity = material.getQuantity();
                    return quantity != null ? new BigDecimal(quantity) : BigDecimal.ZERO;
                }); // 如果没有找到，返回当前库存
    }

    /**
     * 确认多物料进仓单
     * @param documentCode 单据编号
     * @param username 操作用户名
     * @return 操作结果
     */
    @Transactional
    public Map<String, Object> confirmMultiInbound(String documentCode, String username) {
        Map<String, Object> result = new HashMap<>();

        try {
            // 查找多物料进出仓记录
            Optional<MultiInOutRecord> recordOpt = multiInOutRecordRepository.findByDocumentCode(documentCode);
            if (!recordOpt.isPresent()) {
                result.put("result", 0);
                result.put("message", "找不到单据编号为 " + documentCode + " 的多物料进出仓记录");
                return result;
            }

            MultiInOutRecord record = recordOpt.get();

            // 检查操作类型是否为进仓
            if (!"INBOUND".equals(record.getOperationType())) {
                result.put("result", 0);
                result.put("message", "单据编号 " + documentCode + " 不是进仓单");
                return result;
            }

            // 检查状态是否为草稿
            if (!Status.DRAFT.equals(record.getStatus())) {
                result.put("result", 0);
                result.put("message", "只能确认草稿状态的进仓单");
                return result;
            }

            // 更新状态为已确认
            record.setStatus(Status.CONFIRMED);
            record.setUpdatedTime(LocalDateTime.now());
            multiInOutRecordRepository.save(record);

            result.put("result", 1);
            result.put("message", "多物料进仓单确认成功");
            result.put("data", record);

            return result;
        } catch (Exception e) {
            result.put("result", 0);
            result.put("message", "确认多物料进仓单失败: " + e.getMessage());
            return result;
        }
    }

    /**
     * 确认多物料出仓单
     * @param documentCode 单据编号
     * @param username 操作用户名
     * @return 操作结果
     */
    @Transactional
    public Map<String, Object> confirmMultiOutbound(String documentCode, String username) {
        Map<String, Object> result = new HashMap<>();

        try {
            // 查找多物料进出仓记录
            Optional<MultiInOutRecord> recordOpt = multiInOutRecordRepository.findByDocumentCode(documentCode);
            if (!recordOpt.isPresent()) {
                result.put("result", 0);
                result.put("message", "找不到单据编号为 " + documentCode + " 的多物料进出仓记录");
                return result;
            }

            MultiInOutRecord record = recordOpt.get();

            // 检查操作类型是否为出仓
            if (!"OUTBOUND".equals(record.getOperationType())) {
                result.put("result", 0);
                result.put("message", "单据编号 " + documentCode + " 不是出仓单");
                return result;
            }

            // 检查状态是否为草稿
            if (!Status.DRAFT.equals(record.getStatus())) {
                result.put("result", 0);
                result.put("message", "只能确认草稿状态的出仓单");
                return result;
            }

            // 更新状态为已确认
            record.setStatus(Status.CONFIRMED);
            record.setUpdatedTime(LocalDateTime.now());
            multiInOutRecordRepository.save(record);

            result.put("result", 1);
            result.put("message", "多物料出仓单确认成功");
            result.put("data", record);

            return result;
        } catch (Exception e) {
            result.put("result", 0);
            result.put("message", "确认多物料出仓单失败: " + e.getMessage());
            return result;
        }
    }

    /**
     * 完成多物料进仓单
     * @param documentCode 单据编号
     * @param username 操作用户名
     * @return 操作结果
     */
    @Transactional
    public Map<String, Object> completeMultiInbound(String documentCode, String username) {
        Map<String, Object> result = new HashMap<>();

        try {
            // 查找多物料进出仓记录
            Optional<MultiInOutRecord> recordOpt = multiInOutRecordRepository.findByDocumentCode(documentCode);
            if (!recordOpt.isPresent()) {
                result.put("result", 0);
                result.put("message", "找不到单据编号为 " + documentCode + " 的多物料进出仓记录");
                return result;
            }

            MultiInOutRecord record = recordOpt.get();

            // 检查操作类型是否为进仓
            if (!"INBOUND".equals(record.getOperationType())) {
                result.put("result", 0);
                result.put("message", "单据编号 " + documentCode + " 不是进仓单");
                return result;
            }

            // 检查状态是否为已确认
            if (!Status.CONFIRMED.equals(record.getStatus())) {
                result.put("result", 0);
                result.put("message", "只能完成已确认的进仓单");
                return result;
            }

            // 获取明细记录
            List<MultiInOutDetail> details = multiInOutDetailRepository.findByMultiInOutRecord(record);
            if (details.isEmpty()) {
                result.put("result", 0);
                result.put("message", "进仓单明细不能为空");
                return result;
            }

            // 获取操作人
            User operator = userService.getUserByUsername(username);
            if (operator == null) {
                result.put("result", 0);
                result.put("message", "操作人不存在");
                return result;
            }

            // 更新库存
            for (MultiInOutDetail detail : details) {
                // 通过物料编码获取物料ID
                Optional<Material> materialOpt = materialRepository.findByMaterialCode(detail.getMaterialCode());
                if (!materialOpt.isPresent()) {
                    result.put("result", 0);
                    result.put("message", "物料编码 " + detail.getMaterialCode() + " 不存在");
                    return result;
                }

                Material material = materialOpt.get();
                Long materialId = material.getId();
                Integer quantity = detail.getQuantity();

                // 使用悲观锁获取库存记录
                Inventory inventory = inventoryRepository.findByMaterialIdWithLock(materialId)
                        .orElse(new Inventory());

                inventory.setMaterial(material);

                // 更新库存数量
                Integer currentQuantity = inventory.getQuantity() != null ? inventory.getQuantity() : 0;
                Integer newQuantity = currentQuantity + quantity;
                inventory.setQuantity(newQuantity);

                // 更新最后进仓时间
                inventory.setLastInboundTime(LocalDateTime.now());

                // 设置更新人和更新时间
                inventory.setUpdatedBy(operator);
                inventory.setUpdatedTime(LocalDateTime.now());

                inventoryRepository.save(inventory);

                // 记录仓库账本
                WarehouseLedger ledger = new WarehouseLedger();
                ledger.setLedgerDate(LocalDate.now());
                ledger.setDocumentCode(record.getDocumentCode());
                ledger.setOperationType("进仓");
                ledger.setMaterial(material);
                ledger.setInQuantity(quantity);
                ledger.setInAmount(detail.getTotalPrice() != null ? detail.getTotalPrice() : BigDecimal.ZERO);
                ledger.setOutQuantity(0);
                ledger.setOutAmount(BigDecimal.ZERO);
                ledger.setBalanceQuantity(newQuantity);
                ledger.setBalanceAmount(new BigDecimal(newQuantity).multiply(detail.getUnitPrice() != null ? detail.getUnitPrice() : BigDecimal.ONE));
                ledger.setRemark(detail.getRemark());
                warehouseLedgerRepository.save(ledger);
            }

            // 更新状态为已完成
            record.setStatus(Status.COMPLETED);
            record.setUpdatedTime(LocalDateTime.now());
            multiInOutRecordRepository.save(record);

            result.put("result", 1);
            result.put("message", "多物料进仓单完成成功");
            result.put("data", record);

            return result;
        } catch (Exception e) {
            result.put("result", 0);
            result.put("message", "完成多物料进仓单失败: " + e.getMessage());
            return result;
        }
    }

    /**
     * 完成多物料出仓单
     * @param documentCode 单据编号
     * @param username 操作用户名
     * @return 操作结果
     */
    @Transactional
    public Map<String, Object> completeMultiOutbound(String documentCode, String username) {
        Map<String, Object> result = new HashMap<>();

        try {
            // 查找多物料进出仓记录
            Optional<MultiInOutRecord> recordOpt = multiInOutRecordRepository.findByDocumentCode(documentCode);
            if (!recordOpt.isPresent()) {
                result.put("result", 0);
                result.put("message", "找不到单据编号为 " + documentCode + " 的多物料进出仓记录");
                return result;
            }

            MultiInOutRecord record = recordOpt.get();

            // 检查操作类型是否为出仓
            if (!"OUTBOUND".equals(record.getOperationType())) {
                result.put("result", 0);
                result.put("message", "单据编号 " + documentCode + " 不是出仓单");
                return result;
            }

            // 检查状态是否为已确认
            if (!Status.CONFIRMED.equals(record.getStatus())) {
                result.put("result", 0);
                result.put("message", "只能完成已确认的出仓单");
                return result;
            }

            // 获取明细记录
            List<MultiInOutDetail> details = multiInOutDetailRepository.findByMultiInOutRecord(record);
            if (details.isEmpty()) {
                result.put("result", 0);
                result.put("message", "出仓单明细不能为空");
                return result;
            }

            // 获取操作人
            User operator = userService.getUserByUsername(username);
            if (operator == null) {
                result.put("result", 0);
                result.put("message", "操作人不存在");
                return result;
            }

            // 更新库存
            for (MultiInOutDetail detail : details) {
                // 通过物料编码获取物料ID
                Optional<Material> materialOpt = materialRepository.findByMaterialCode(detail.getMaterialCode());
                if (!materialOpt.isPresent()) {
                    result.put("result", 0);
                    result.put("message", "物料编码 " + detail.getMaterialCode() + " 不存在");
                    return result;
                }

                Material material = materialOpt.get();
                Long materialId = material.getId();
                Integer quantity = detail.getQuantity();

                // 使用悲观锁检查库存，确保高并发下数据一致性
                Inventory inventory = inventoryRepository.findByMaterialIdWithLock(materialId)
                        .orElseThrow(() -> new RuntimeException("物料库存不存在"));

                Integer currentQuantity = inventory.getQuantity() != null ? inventory.getQuantity() : 0;

                // 检查库存是否足够
                if (currentQuantity < quantity) {
                    result.put("result", 0);
                    result.put("message", "物料 " + material.getName() + " 库存不足，当前库存：" + currentQuantity + "，需要：" + quantity);
                    return result;
                }

                // 更新库存数量
                Integer newQuantity = currentQuantity - quantity;
                inventory.setQuantity(newQuantity);

                // 更新最后出仓时间
                inventory.setLastOutboundTime(LocalDateTime.now());

                // 设置更新人和更新时间
                inventory.setUpdatedBy(operator);
                inventory.setUpdatedTime(LocalDateTime.now());

                inventoryRepository.save(inventory);

                // 记录仓库账本
                WarehouseLedger ledger = new WarehouseLedger();
                ledger.setLedgerDate(LocalDate.now());
                ledger.setDocumentCode(record.getDocumentCode());
                ledger.setOperationType("出仓");
                ledger.setMaterial(material);
                ledger.setInQuantity(0);
                ledger.setInAmount(BigDecimal.ZERO);
                ledger.setOutQuantity(quantity);
                ledger.setOutAmount(detail.getTotalPrice() != null ? detail.getTotalPrice() : BigDecimal.ZERO);
                ledger.setBalanceQuantity(newQuantity);
                ledger.setBalanceAmount(new BigDecimal(newQuantity).multiply(detail.getUnitPrice() != null ? detail.getUnitPrice() : BigDecimal.ONE));
                ledger.setRemark(detail.getRemark());
                warehouseLedgerRepository.save(ledger);
            }

            // 更新状态为已完成
            record.setStatus(Status.COMPLETED);
            record.setUpdatedTime(LocalDateTime.now());
            multiInOutRecordRepository.save(record);

            result.put("result", 1);
            result.put("message", "多物料出仓单完成成功");
            result.put("data", record);

            return result;
        } catch (Exception e) {
            result.put("result", 0);
            result.put("message", "完成多物料出仓单失败: " + e.getMessage());
            return result;
        }
    }

    /**
     * 获取物料单价
     * @param materialId 物料ID
     * @return 物料单价
     */
    public BigDecimal getMaterialPrice(Long materialId) {
        Optional<Material> materialOpt = materialRepository.findById(materialId);
        if (materialOpt.isPresent()) {
            BigDecimal price = materialOpt.get().getPrice();
            return price != null ? price : BigDecimal.ZERO;
        }
        return BigDecimal.ZERO;
    }

    /**
     * 进出仓单查询
     * @param startDate 起始日期
     * @param endDate 结束日期
     * @param materialCode 物料编码
     * @param operatorCode 操作人编码
     * @param operationType 操作类型（INBOUND/OUTBOUND）
     * @param remark 备注关键字
     * @return 查询结果
     */
    public Map<String, Object> queryInOutRecords(
            String startDate, String endDate, String materialCode,
            String operatorCode, String operationType, String remark) {
        Map<String, Object> result = new HashMap<>();

        try {
            // 使用SimpleJdbcCall调用存储过程
            org.springframework.jdbc.core.simple.SimpleJdbcCall jdbcCall =
                    new org.springframework.jdbc.core.simple.SimpleJdbcCall(dataSource)
                            .withProcedureName("class2_seat27_进出仓单查询")
                            .declareParameters(
                                    new org.springframework.jdbc.core.SqlParameter("p_start_date", java.sql.Types.DATE),
                                    new org.springframework.jdbc.core.SqlParameter("p_end_date", java.sql.Types.DATE),
                                    new org.springframework.jdbc.core.SqlParameter("p_material_code", java.sql.Types.VARCHAR),
                                    new org.springframework.jdbc.core.SqlParameter("p_operator_code", java.sql.Types.VARCHAR),
                                    new org.springframework.jdbc.core.SqlParameter("p_operation_type", java.sql.Types.VARCHAR),
                                    new org.springframework.jdbc.core.SqlParameter("p_remark_keyword", java.sql.Types.VARCHAR),
                                    new org.springframework.jdbc.core.SqlOutParameter("p_result", java.sql.Types.INTEGER),
                                    new org.springframework.jdbc.core.SqlOutParameter("p_message", java.sql.Types.VARCHAR)
                            );

            // 构建输入参数
            Map<String, Object> inParams = new HashMap<>();
            inParams.put("p_start_date", java.sql.Date.valueOf(startDate));
            inParams.put("p_end_date", java.sql.Date.valueOf(endDate));
            inParams.put("p_material_code", materialCode);
            inParams.put("p_operator_code", operatorCode);
            inParams.put("p_operation_type", operationType);
            inParams.put("p_remark_keyword", remark);

            // 执行存储过程
            Map<String, Object> outParams = jdbcCall.execute(inParams);

            // 获取输出参数
            int procResult = (Integer) outParams.get("p_result");
            String procMessage = (String) outParams.get("p_message");

            // 设置返回结果
            result.put("result", procResult);
            result.put("message", procMessage);

            // 获取查询结果
            List<Map<String, Object>> records = (List<Map<String, Object>>) outParams.get("#result-set-1");
            if (records != null && !records.isEmpty()) {
                result.put("data", records);
            } else {
                result.put("data", new ArrayList<>());
            }

            return result;
        } catch (Exception e) {
            result.put("result", 0);
            result.put("message", "查询进出仓单失败: " + e.getMessage());
            result.put("data", new ArrayList<>());
            return result;
        }
    }
}