package com.class2.seat27.server.repository;

import com.class2.seat27.server.entity.Material;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface MaterialRepository extends JpaRepository<Material, Long> {
    Optional<Material> findByMaterialCode(String materialCode);
    List<Material> findByNameContainingIgnoreCase(String name);
    boolean existsByMaterialCode(String materialCode);
    
    @Query("SELECT MAX(m.materialCode) FROM Material m")
    String findMaxMaterialCode();

    /**
     * 多条件查询物料
     * @param name 物料名称，可为null
     * @param code 物料编码，可为null
     * @param spec 物料规格，可为null
     * @param unit 物料单位，可为null
     * @return 符合条件的物料列表
     */
    @Query("SELECT m FROM Material m WHERE " +
           "(:name IS NULL OR LOWER(m.name) LIKE LOWER(CONCAT('%', :name, '%'))) AND " +
           "(:code IS NULL OR LOWER(m.materialCode) LIKE LOWER(CONCAT('%', :code, '%'))) AND " +
           "(:spec IS NULL OR LOWER(m.specification) LIKE LOWER(CONCAT('%', :spec, '%'))) AND " +
           "(:unit IS NULL OR LOWER(m.unit) = LOWER(:unit))")
    List<Material> findByMultipleConditions(String name, String code, String spec, String unit);

    /**
     * 查询所有不重复的单位
     * @return 所有不重复的单位列表
     */
    @Query("SELECT DISTINCT m.unit FROM Material m WHERE m.unit IS NOT NULL ORDER BY m.unit")
    List<String> findAllDistinctUnits();
}
