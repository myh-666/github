-- 修复统计报表相关存储过程
-- 1. 修复月度记录存储过程中的操作员和经手人关联问题
DROP PROCEDURE IF EXISTS `class2_seat27_monthly_records`;
delimiter ;;
CREATE PROCEDURE `class2_seat27_monthly_records`(IN p_year INT,
    IN p_month INT,
    OUT p_result INT,
    OUT p_message VARCHAR(500))
BEGIN
    -- 创建临时表存储月度进出仓单数据
    DROP TEMPORARY TABLE IF EXISTS temp_monthly_records;
    CREATE TEMPORARY TABLE temp_monthly_records (
        record_id BIGINT,
        document_code VARCHAR(255),
        operation_type VARCHAR(255),
        operation_date DATETIME,
        operator_code VARCHAR(255),
        operator_name VARCHAR(255),
        handler_code VARCHAR(255),
        handler_name VARCHAR(255),
        status VARCHAR(20),
        material_code VARCHAR(255),
        material_name VARCHAR(255),
        specification VARCHAR(255),
        unit VARCHAR(20),
        quantity INT,
        unit_price DECIMAL(38, 2),
        total_price DECIMAL(38, 2)
    );

    -- 查询指定年月的进出仓单数据
    INSERT INTO temp_monthly_records
    SELECT
        r.id AS record_id,
        r.document_code,
        r.operation_type,
        r.operation_date,
        r.operator_code,
        p1.name AS operator_name,
        r.handler_code,
        p2.name AS handler_name,
        r.status,
        d.material_code,
        d.material_name,
        d.specification,
        d.unit,
        d.quantity,
        d.unit_price,
        d.total_price
    FROM
        class2_seat27_multi_inout_record r
    JOIN
        class2_seat27_multi_inout_detail d ON r.id = d.multi_inout_record_id
    LEFT JOIN
        class2_seat27_personnel p1 ON r.operator_code = p1.username OR r.operator_code = p1.personnel_code
    LEFT JOIN
        class2_seat27_personnel p2 ON r.handler_code = p2.username OR r.handler_code = p2.personnel_code
    WHERE
        YEAR(r.operation_date) = p_year
        AND MONTH(r.operation_date) = p_month
    ORDER BY
        r.operation_date, r.document_code;

    -- 返回月度进出仓单数据
    SELECT * FROM temp_monthly_records;

    SET p_result = 1;
    SET p_message = '月度进出仓单查询完成';
END
;;
delimiter ;

-- 2. 修复物料统计存储过程，添加当前库存信息
DROP PROCEDURE IF EXISTS `class2_seat27_material_flow_statistics`;
delimiter ;;
CREATE PROCEDURE `class2_seat27_material_flow_statistics`(IN p_start_date DATE,
    IN p_end_date DATE,
    OUT p_result INT,
    OUT p_message VARCHAR(500))
BEGIN
    -- 创建临时表存储物料统计数据
    DROP TEMPORARY TABLE IF EXISTS temp_material_statistics;
    CREATE TEMPORARY TABLE temp_material_statistics (
        material_id BIGINT,
        material_code VARCHAR(255),
        material_name VARCHAR(255),
        specification VARCHAR(255),
        unit VARCHAR(20),
        inbound_quantity INT,
        inbound_amount DECIMAL(38, 2),
        outbound_quantity INT,
        outbound_amount DECIMAL(38, 2),
        net_flow INT,
        net_amount DECIMAL(38, 2),
        current_quantity INT
    );

    -- 查询指定时间范围内的进仓数据
    INSERT INTO temp_material_statistics(
        material_id, material_code, material_name, specification, unit,
        inbound_quantity, inbound_amount, outbound_quantity, outbound_amount, net_flow, net_amount
    )
    SELECT
        m.id AS material_id,
        m.material_code,
        m.name AS material_name,
        m.specification,
        m.unit,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'INBOUND' THEN d.quantity
            ELSE 0
        END), 0) AS inbound_quantity,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'INBOUND' THEN d.total_price
            ELSE 0
        END), 0) AS inbound_amount,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'OUTBOUND' THEN d.quantity
            ELSE 0
        END), 0) AS outbound_quantity,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'OUTBOUND' THEN d.total_price
            ELSE 0
        END), 0) AS outbound_amount,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'INBOUND' THEN d.quantity
            ELSE -d.quantity
        END), 0) AS net_flow,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'INBOUND' THEN d.total_price
            ELSE -d.total_price
        END), 0) AS net_amount
    FROM
        class2_seat27_material m
    LEFT JOIN
        class2_seat27_multi_inout_detail d ON m.material_code = d.material_code
    LEFT JOIN
        class2_seat27_multi_inout_record r ON d.multi_inout_record_id = r.id
    WHERE
        r.status = 'COMPLETED'
        AND (p_start_date IS NULL OR DATE(r.operation_date) >= p_start_date)
        AND (p_end_date IS NULL OR DATE(r.operation_date) <= p_end_date)
    GROUP BY
        m.id, m.material_code, m.name, m.specification, m.unit
    HAVING
        inbound_quantity > 0 OR outbound_quantity > 0;

    -- 更新当前库存信息
    UPDATE temp_material_statistics t
    JOIN (
        SELECT i1.material_id, i1.quantity
        FROM class2_seat27_inventory i1
        INNER JOIN (
            SELECT material_id, MAX(id) as max_id
            FROM class2_seat27_inventory
            GROUP BY material_id
        ) i2 ON i1.material_id = i2.material_id AND i1.id = i2.max_id
    ) inv ON t.material_id = inv.material_id
    SET t.current_quantity = inv.quantity;

    -- 返回物料统计数据
    SELECT
        material_id, material_code, material_name, specification, unit,
        inbound_quantity, inbound_amount, outbound_quantity, outbound_amount, net_flow, net_amount,
        current_quantity
    FROM temp_material_statistics;

    SET p_result = 1;
    SET p_message = '物料流量统计查询完成';
END
;;
delimiter ;