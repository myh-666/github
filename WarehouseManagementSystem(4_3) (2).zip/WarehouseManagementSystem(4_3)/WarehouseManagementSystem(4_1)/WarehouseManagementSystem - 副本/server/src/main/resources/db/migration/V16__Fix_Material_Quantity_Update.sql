-- 使用数据库
USE class2_seat27_warehouse;

-- 删除现有的触发器，避免在触发器中更新库存表导致错误
DROP TRIGGER IF EXISTS tr_material_quantity_before;

-- 创建一个新的存储过程，用于在物料管理中更新物料数量
DELIMITER //
CREATE PROCEDURE update_material_quantity(
    IN p_material_id BIGINT,
    IN p_new_quantity INT,
    OUT p_result INT,
    OUT p_message VARCHAR(500)
)
BEGIN
    DECLARE v_inventory_id BIGINT;
    DECLARE v_current_quantity INT;

    -- 开始事务
    START TRANSACTION;

    -- 检查物料是否存在
    IF NOT EXISTS (SELECT 1 FROM class2_seat27_material WHERE id = p_material_id) THEN
        SET p_result = 0;
        SET p_message = '物料不存在';
        ROLLBACK;
    ELSE
        -- 检查库存记录是否存在
        SELECT id, quantity INTO v_inventory_id, v_current_quantity 
        FROM class2_seat27_inventory 
        WHERE material_id = p_material_id;

        IF v_inventory_id IS NULL THEN
            -- 创建新的库存记录
            INSERT INTO class2_seat27_inventory(
                material_id,
                quantity,
                created_time,
                updated_time
            ) VALUES (
                p_material_id,
                p_new_quantity,
                NOW(),
                NOW()
            );
        ELSE
            -- 更新现有库存记录
            UPDATE class2_seat27_inventory 
            SET quantity = p_new_quantity,
                updated_time = NOW()
            WHERE id = v_inventory_id;
        END IF;

        -- 更新物料表中的数量
        UPDATE class2_seat27_material
        SET quantity = p_new_quantity,
            updated_time = NOW()
        WHERE id = p_material_id;

        -- 记录库存调整日志
        INSERT INTO class2_seat27_warehouse_ledger(
            ledger_date,
            document_code,
            operation_type,
            material_id,
            in_quantity,
            in_amount,
            out_quantity,
            out_amount,
            balance_quantity,
            balance_amount,
            remark
        ) VALUES (
            CURDATE(),
            CONCAT('ADJ-', DATE_FORMAT(NOW(), '%Y%m%d%H%i%s')),
            '库存调整',
            p_material_id,
            CASE WHEN p_new_quantity > IFNULL(v_current_quantity, 0) THEN p_new_quantity - IFNULL(v_current_quantity, 0) ELSE 0 END,
            0,
            CASE WHEN p_new_quantity < IFNULL(v_current_quantity, 0) THEN IFNULL(v_current_quantity, 0) - p_new_quantity ELSE 0 END,
            0,
            p_new_quantity,
            0,
            '物料档案管理中调整库存数量'
        );

        COMMIT;
        SET p_result = 1;
        SET p_message = '物料数量更新成功';
    END IF;
END//
DELIMITER ;
