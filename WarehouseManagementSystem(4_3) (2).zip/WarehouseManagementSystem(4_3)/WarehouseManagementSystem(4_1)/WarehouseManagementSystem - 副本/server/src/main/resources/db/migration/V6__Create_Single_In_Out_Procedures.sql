- 使用数据库
USE class2_seat27_warehouse;

-- 删除已存在的存储过程（如果存在）
DROP PROCEDURE IF EXISTS class2_seat27_single_inbound;
DROP PROCEDURE IF EXISTS class2_seat27_single_outbound;

DELIMITER //

CREATE PROCEDURE class2_seat27_single_inbound(
    IN p_material_id BIGINT,
    IN p_quantity INT,  -- 修改为INT
    IN p_unit_price DECIMAL(38,2),
    IN p_operator_code VARCHAR(50),
    IN p_handler_code VARCHAR(50),
    IN p_remark VARCHAR(500),
    OUT p_result INT,
    OUT p_message VARCHAR(500)
)
BEGIN
    DECLARE v_material_exists INT DEFAULT 0;
    DECLARE v_operator_id BIGINT;
    DECLARE v_inbound_code VARCHAR(50);
    DECLARE v_total_price DECIMAL(38,2);
    DECLARE v_current_quantity INT;  -- 修改为INT
    DECLARE v_new_quantity INT;      -- 修改为INT
    DECLARE v_inventory_id BIGINT;
    DECLARE v_material_name VARCHAR(255);
    DECLARE v_material_code VARCHAR(255);
    DECLARE v_current_date VARCHAR(8);
    DECLARE v_today_count INT DEFAULT 0;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
            SET p_result = 0;
            SET p_message = '进仓操作失败';
        END;

    SET v_current_date = DATE_FORMAT(NOW(), '%Y%m%d');
    START TRANSACTION;

    SELECT COUNT(*), name, material_code INTO v_material_exists, v_material_name, v_material_code
    FROM class2_seat27_material WHERE id = p_material_id;

    IF v_material_exists = 0 THEN
        SET p_result = 0;
        SET p_message = '物料不存在';
        ROLLBACK;
    ELSE
        SELECT id INTO v_operator_id
        FROM class2_seat27_personnel
        WHERE personnel_code = p_operator_code OR username = p_operator_code;

        IF v_operator_id IS NULL THEN
            SET p_result = 0;
            SET p_message = '操作员不存在';
            ROLLBACK;
        ELSE
            SELECT COUNT(*) INTO v_today_count
            FROM class2_seat27_inbound
            WHERE inbound_code LIKE CONCAT('IN', v_current_date, '%');

            SET v_inbound_code = CONCAT('IN', v_current_date, LPAD(v_today_count + 1, 5, '0'));
            SET v_total_price = p_quantity * p_unit_price;

            INSERT INTO class2_seat27_inbound(
                inbound_code, inbound_date, remark, status, created_by
            ) VALUES (v_inbound_code, NOW(), p_remark, 'COMPLETED', v_operator_id);

            INSERT INTO class2_seat27_inbound_detail(
                inbound_id, material_id, quantity, unit_price, total_price, remark, created_by
            ) VALUES (LAST_INSERT_ID(), p_material_id, p_quantity, p_unit_price, v_total_price, p_remark, v_operator_id);

            SELECT id, quantity INTO v_inventory_id, v_current_quantity
            FROM class2_seat27_inventory
            WHERE material_id = p_material_id;

            SET v_new_quantity = IFNULL(v_current_quantity, 0) + p_quantity;

            IF v_inventory_id IS NULL THEN
                INSERT INTO class2_seat27_inventory(
                    material_id, quantity, last_inbound_time, created_by, updated_by
                ) VALUES (p_material_id, v_new_quantity, NOW(), v_operator_id, v_operator_id);
            ELSE
                UPDATE class2_seat27_inventory
                SET quantity = v_new_quantity, last_inbound_time = NOW(), updated_by = v_operator_id, updated_time = NOW()
                WHERE id = v_inventory_id;
            END IF;

            INSERT INTO class2_seat27_warehouse_ledger(
                ledger_date, document_code, operation_type, material_id,
                in_quantity, in_amount, out_quantity, out_amount,
                balance_quantity, balance_amount, remark
            ) VALUES (
                         CURDATE(), v_inbound_code, '进仓', p_material_id,
                         p_quantity, v_total_price, 0, 0,
                         v_new_quantity, v_new_quantity * p_unit_price, p_remark
                     );

            COMMIT;
            SET p_result = 1;
            SET p_message = CONCAT('物料进仓成功，数量: ', p_quantity);
        END IF;
    END IF;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE class2_seat27_single_outbound(
    IN p_material_id BIGINT,
    IN p_quantity INT,  -- 修改为INT
    IN p_unit_price DECIMAL(38,2),
    IN p_operator_code VARCHAR(50),
    IN p_handler_code VARCHAR(50),
    IN p_remark VARCHAR(500),
    OUT p_result INT,
    OUT p_message VARCHAR(500)
)
BEGIN
    DECLARE v_material_exists INT DEFAULT 0;
    DECLARE v_operator_id BIGINT;
    DECLARE v_outbound_code VARCHAR(50);
    DECLARE v_total_price DECIMAL(38,2);
    DECLARE v_current_quantity INT;  -- 修改为INT
    DECLARE v_new_quantity INT;      -- 修改为INT
    DECLARE v_inventory_id BIGINT;
    DECLARE v_material_name VARCHAR(255);
    DECLARE v_material_code VARCHAR(255);
    DECLARE v_current_date VARCHAR(8);
    DECLARE v_today_count INT DEFAULT 0;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
            SET p_result = 0;
            SET p_message = '出仓操作失败';
        END;

    SET v_current_date = DATE_FORMAT(NOW(), '%Y%m%d');
    START TRANSACTION;

    SELECT COUNT(*), name, material_code INTO v_material_exists, v_material_name, v_material_code
    FROM class2_seat27_material WHERE id = p_material_id;

    IF v_material_exists = 0 THEN
        SET p_result = 0;
        SET p_message = '物料不存在';
        ROLLBACK;
    ELSE
        SELECT id INTO v_operator_id
        FROM class2_seat27_personnel
        WHERE personnel_code = p_operator_code OR username = p_operator_code;

        IF v_operator_id IS NULL THEN
            SET p_result = 0;
            SET p_message = '操作员不存在';
            ROLLBACK;
        ELSE
            SELECT id, quantity INTO v_inventory_id, v_current_quantity
            FROM class2_seat27_inventory
            WHERE material_id = p_material_id;

            IF v_inventory_id IS NULL OR v_current_quantity IS NULL OR v_current_quantity < p_quantity THEN
                SET p_result = 0;
                SET p_message = CONCAT('库存不足，当前库存: ', IFNULL(v_current_quantity, 0), '，需要: ', p_quantity);
                ROLLBACK;
            ELSE
                SELECT COUNT(*) INTO v_today_count
                FROM class2_seat27_outbound
                WHERE outbound_code LIKE CONCAT('OUT', v_current_date, '%');

                SET v_outbound_code = CONCAT('OUT', v_current_date, LPAD(v_today_count + 1, 5, '0'));
                SET v_total_price = p_quantity * p_unit_price;

                INSERT INTO class2_seat27_outbound(
                    outbound_code, outbound_date, remark, status, created_by
                ) VALUES (v_outbound_code, NOW(), p_remark, 'COMPLETED', v_operator_id);

                INSERT INTO class2_seat27_outbound_detail(
                    outbound_id, material_id, quantity, unit_price, total_price, remark, created_by
                ) VALUES (LAST_INSERT_ID(), p_material_id, p_quantity, p_unit_price, v_total_price, p_remark, v_operator_id);

                SET v_new_quantity = v_current_quantity - p_quantity;

                UPDATE class2_seat27_inventory
                SET quantity = v_new_quantity, last_outbound_time = NOW(), updated_by = v_operator_id, updated_time = NOW()
                WHERE id = v_inventory_id;

                INSERT INTO class2_seat27_warehouse_ledger(
                    ledger_date, document_code, operation_type, material_id,
                    in_quantity, in_amount, out_quantity, out_amount,
                    balance_quantity, balance_amount, remark
                ) VALUES (
                             CURDATE(), v_outbound_code, '出仓', p_material_id,
                             0, 0, p_quantity, v_total_price,
                             v_new_quantity, v_new_quantity * p_unit_price, p_remark
                         );

                COMMIT;
                SET p_result = 1;
                SET p_message = CONCAT('物料出仓成功，数量: ', p_quantity);
            END IF;
        END IF;
    END IF;
END //

DELIMITER ;