-- 简化存储过程调用，直接返回结果集
-- 1. 修复物料统计存储过程
DROP PROCEDURE IF EXISTS `class2_seat27_material_flow_statistics`;
delimiter ;;
CREATE PROCEDURE `class2_seat27_material_flow_statistics`(
    IN p_start_date DATE,
    IN p_end_date DATE
)
BEGIN
    -- 查询指定时间范围内的进出仓数据
    SELECT
        m.id AS material_id,
        m.material_code,
        m.name AS material_name,
        m.specification,
        m.unit,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'INBOUND' THEN d.quantity
            ELSE 0
        END), 0) AS inbound_quantity,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'INBOUND' THEN d.total_price
            ELSE 0
        END), 0) AS inbound_amount,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'OUTBOUND' THEN d.quantity
            ELSE 0
        END), 0) AS outbound_quantity,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'OUTBOUND' THEN d.total_price
            ELSE 0
        END), 0) AS outbound_amount,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'INBOUND' THEN d.quantity
            ELSE -d.quantity
        END), 0) AS net_flow,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'INBOUND' THEN d.total_price
            ELSE -d.total_price
        END), 0) AS net_amount,
        COALESCE(inv.quantity, 0) AS current_quantity
    FROM
        class2_seat27_material m
    LEFT JOIN
        class2_seat27_multi_inout_detail d ON m.material_code = d.material_code
    LEFT JOIN
        class2_seat27_multi_inout_record r ON d.multi_inout_record_id = r.id
    LEFT JOIN (
        SELECT i1.material_id, i1.quantity
        FROM class2_seat27_inventory i1
        INNER JOIN (
            SELECT material_id, MAX(id) as max_id
            FROM class2_seat27_inventory
            GROUP BY material_id
        ) i2 ON i1.material_id = i2.material_id AND i1.id = i2.max_id
    ) inv ON m.id = inv.material_id
    WHERE
        r.status = 'COMPLETED'
        AND (p_start_date IS NULL OR DATE(r.operation_date) >= p_start_date)
        AND (p_end_date IS NULL OR DATE(r.operation_date) <= p_end_date)
    GROUP BY
        m.id, m.material_code, m.name, m.specification, m.unit, inv.quantity
    HAVING
        inbound_quantity > 0 OR outbound_quantity > 0;
END
;;
delimiter ;

-- 2. 修复月度记录存储过程
DROP PROCEDURE IF EXISTS `class2_seat27_monthly_records`;
delimiter ;;
CREATE PROCEDURE `class2_seat27_monthly_records`(
    IN p_year INT,
    IN p_month INT
)
BEGIN
    -- 查询指定年月的进出仓单数据
    SELECT
        r.id AS record_id,
        r.document_code,
        r.operation_type,
        r.operation_date,
        r.operator_code,
        COALESCE(p1.name, '') AS operator_name,
        r.handler_code,
        COALESCE(p2.name, '') AS handler_name,
        r.status,
        d.material_code,
        d.material_name,
        d.specification,
        d.unit,
        d.quantity,
        d.unit_price,
        d.total_price
    FROM
        class2_seat27_multi_inout_record r
    JOIN
        class2_seat27_multi_inout_detail d ON r.id = d.multi_inout_record_id
    LEFT JOIN
        class2_seat27_personnel p1 ON r.operator_code = p1.username OR r.operator_code = p1.personnel_code
    LEFT JOIN
        class2_seat27_personnel p2 ON r.handler_code = p2.username OR r.handler_code = p2.personnel_code
    WHERE
        YEAR(r.operation_date) = p_year
        AND MONTH(r.operation_date) = p_month
    ORDER BY
        r.operation_date, r.document_code;
END
;;
delimiter ;

-- 3. 修复仓库账本存储过程
DROP PROCEDURE IF EXISTS `class2_seat27_warehouse_ledger`;
delimiter ;;
CREATE PROCEDURE `class2_seat27_warehouse_ledger`(
    IN p_year INT,
    IN p_material_code VARCHAR(255)
)
BEGIN
    -- 查询仓库账本数据
    SELECT
        wl.ledger_date,
        wl.document_code,
        wl.operation_type,
        wl.material_id,
        COALESCE(m.material_code, '') AS material_code,
        COALESCE(m.name, '') AS material_name,
        COALESCE(m.specification, '') AS specification,
        COALESCE(m.unit, '') AS unit,
        COALESCE(wl.in_quantity, 0) AS inbound_quantity,
        COALESCE(wl.in_amount, 0) AS inbound_amount,
        COALESCE(wl.out_quantity, 0) AS outbound_quantity,
        COALESCE(wl.out_amount, 0) AS outbound_amount,
        COALESCE(wl.balance_quantity, 0) AS balance_quantity,
        COALESCE(wl.balance_amount, 0) AS balance_amount,
        COALESCE(wl.remark, '') AS remark
    FROM
        class2_seat27_warehouse_ledger wl
    LEFT JOIN
        class2_seat27_material m ON wl.material_id = m.id
    WHERE
        YEAR(wl.ledger_date) = p_year
        AND (p_material_code IS NULL OR p_material_code = '' OR m.material_code = p_material_code)
    ORDER BY
        wl.ledger_date, wl.document_code;
END
;;
delimiter ;