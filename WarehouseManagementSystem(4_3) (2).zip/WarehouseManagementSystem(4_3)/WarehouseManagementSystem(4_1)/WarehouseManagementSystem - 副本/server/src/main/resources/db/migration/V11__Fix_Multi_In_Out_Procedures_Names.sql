-- 使用数据库
USE class2_seat27_warehouse;

-- 创建新的存储过程以匹配后端服务的调用
-- 创建多物料进仓记录存储过程
DELIMITER //
CREATE PROCEDURE class2_seat27_创建多物料进仓记录(
    IN p_document_code VARCHAR(50),
    IN p_operator_code VARCHAR(50),
    IN p_handler_code VARCHAR(50),
    IN p_remark VARCHAR(500),
    IN p_materials JSON,
    OUT p_result INT,
    OUT p_message VARCHAR(500)
)
BEGIN
    -- 直接调用现有的多物料进仓存储过程
    CALL class2_seat27_多物料进仓(
        p_document_code,
        NOW(),
        p_operator_code,
        p_handler_code,
        p_remark,
        p_materials,
        p_result,
        p_message
    );

    -- 如果成功，更新记录状态为COMPLETED
    IF p_result = 1 THEN
        UPDATE class2_seat27_multi_inout_record
        SET status = 'COMPLETED'
        WHERE document_code = p_document_code AND operation_type = 'INBOUND';
    END IF;
END //
DELIMITER ;

-- 完成多物料进仓存储过程
DELIMITER //
CREATE PROCEDURE class2_seat27_完成多物料进仓(
    IN p_document_code VARCHAR(50),
    IN p_operator_code VARCHAR(50),
    IN p_handler_code VARCHAR(50),
    IN p_remark VARCHAR(500),
    IN p_materials JSON,
    OUT p_result INT,
    OUT p_message VARCHAR(500)
)
BEGIN
    -- 由于多物料进仓已经完成，这里直接返回成功
    SET p_result = 1;
    SET p_message = CONCAT('多物料进仓已完成，单号: ', p_document_code);
END //
DELIMITER ;

-- 创建多物料出仓记录存储过程
DELIMITER //
CREATE PROCEDURE class2_seat27_创建多物料出仓记录(
    IN p_document_code VARCHAR(50),
    IN p_operator_code VARCHAR(50),
    IN p_handler_code VARCHAR(50),
    IN p_remark VARCHAR(500),
    IN p_materials JSON,
    OUT p_result INT,
    OUT p_message VARCHAR(500)
)
BEGIN
    -- 直接调用现有的多物料出仓存储过程
    CALL class2_seat27_多物料出仓(
        p_document_code,
        NOW(),
        p_operator_code,
        p_handler_code,
        p_remark,
        p_materials,
        p_result,
        p_message
    );

    -- 如果成功，更新记录状态为COMPLETED
    IF p_result = 1 THEN
        UPDATE class2_seat27_multi_inout_record
        SET status = 'COMPLETED'
        WHERE document_code = p_document_code AND operation_type = 'OUTBOUND';
    END IF;
END //
DELIMITER ;

-- 完成多物料出仓存储过程
DELIMITER //
CREATE PROCEDURE class2_seat27_完成多物料出仓(
    IN p_document_code VARCHAR(50),
    IN p_operator_code VARCHAR(50),
    IN p_handler_code VARCHAR(50),
    IN p_remark VARCHAR(500),
    IN p_materials JSON,
    OUT p_result INT,
    OUT p_message VARCHAR(500)
)
BEGIN
    -- 由于多物料出仓已经完成，这里直接返回成功
    SET p_result = 1;
    SET p_message = CONCAT('多物料出仓已完成，单号: ', p_document_code);
END //
DELIMITER ;

-- 创建进出仓单查询存储过程
DELIMITER //
CREATE PROCEDURE class2_seat27_进出仓单查询(
    IN p_start_date DATE,
    IN p_end_date DATE,
    IN p_material_code VARCHAR(50),
    IN p_operator_code VARCHAR(50),
    IN p_operation_type VARCHAR(20),
    IN p_remark_keyword VARCHAR(100),
    OUT p_result INT,
    OUT p_message VARCHAR(500)
)
BEGIN
    -- 创建临时表存储查询结果
    DROP TEMPORARY TABLE IF EXISTS temp_inout_records;
    CREATE TEMPORARY TABLE temp_inout_records (
        id BIGINT,
        document_code VARCHAR(255),
        operation_type VARCHAR(255),
        operation_date DATETIME,
        operator_code VARCHAR(255),
        handler_code VARCHAR(255),
        remark VARCHAR(255),
        status VARCHAR(20),
        created_time DATETIME,
        updated_time DATETIME
    );

    -- 插入查询结果
    INSERT INTO temp_inout_records
    SELECT 
        r.id,
        r.document_code,
        r.operation_type,
        r.operation_date,
        r.operator_code,
        r.handler_code,
        r.remark,
        r.status,
        r.created_time,
        r.updated_time
    FROM 
        class2_seat27_multi_inout_record r
    WHERE 
        (p_start_date IS NULL OR DATE(r.operation_date) >= p_start_date)
        AND (p_end_date IS NULL OR DATE(r.operation_date) <= p_end_date)
        AND (p_material_code IS NULL OR EXISTS (
            SELECT 1 FROM class2_seat27_multi_inout_detail d 
            WHERE d.multi_inout_record_id = r.id AND d.material_code = p_material_code
        ))
        AND (p_operator_code IS NULL OR r.operator_code = p_operator_code)
        AND (p_operation_type IS NULL OR r.operation_type = p_operation_type)
        AND (p_remark_keyword IS NULL OR r.remark LIKE CONCAT('%', p_remark_keyword, '%'))
    ORDER BY 
        r.operation_date DESC, r.document_code;

    -- 设置返回结果
    SET p_result = 1;
    SET p_message = '查询成功';
END //
DELIMITER ;
