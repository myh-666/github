
-- 添加外键约束
ALTER TABLE class2_seat27_inbound_detail 
ADD CONSTRAINT class2_seat27_inbound_detail_ibfk_3 
FOREIGN KEY (created_by) REFERENCES class2_seat27_personnel (id) 
ON DELETE SET NULL ON UPDATE RESTRICT;

ALTER TABLE class2_seat27_outbound_detail 
ADD CONSTRAINT class2_seat27_outbound_detail_ibfk_3 
FOREIGN KEY (created_by) REFERENCES class2_seat27_personnel (id) 
ON DELETE SET NULL ON UPDATE RESTRICT;

-- 为新字段添加索引
CREATE INDEX idx_inbound_detail_created_by ON class2_seat27_inbound_detail (created_by);
CREATE INDEX idx_outbound_detail_created_by ON class2_seat27_outbound_detail (created_by);
