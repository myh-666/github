-- 使用数据库
USE class2_seat27_warehouse;

-- 清理可能存在的不一致数据
DELETE FROM class2_seat27_multi_inout_detail
WHERE material_code NOT IN (SELECT material_code FROM class2_seat27_material);

-- 先删除可能存在的外键约束
SET @constraint_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
    WHERE CONSTRAINT_NAME = 'fk_multi_inout_detail_material' 
    AND TABLE_NAME = 'class2_seat27_multi_inout_detail'
    AND TABLE_SCHEMA = DATABASE()
);

SET @sql = IF(@constraint_exists > 0, 
    'ALTER TABLE class2_seat27_multi_inout_detail DROP FOREIGN KEY fk_multi_inout_detail_material',
    'SELECT "外键约束不存在，无需删除" AS message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 添加外键约束以确保数据完整性，支持级联删除
ALTER TABLE class2_seat27_multi_inout_detail
    ADD CONSTRAINT fk_multi_inout_detail_material
        FOREIGN KEY (material_code) REFERENCES class2_seat27_material(material_code)
        ON DELETE CASCADE;

-- 为多物料进出仓记录添加复合索引，提高查询性能
CREATE INDEX idx_multi_inout_record_type_date
    ON class2_seat27_multi_inout_record(operation_type, operation_date);

CREATE INDEX idx_multi_inout_record_status
    ON class2_seat27_multi_inout_record(status);

-- 注意：单号重复检查功能已移至V10存储过程中实现，避免功能重复

-- 为多物料进出仓明细表添加索引
CREATE INDEX idx_multi_inout_detail_record_id
    ON class2_seat27_multi_inout_detail(multi_inout_record_id);

CREATE INDEX idx_multi_inout_detail_material_code
    ON class2_seat27_multi_inout_detail(material_code);

-- 为仓库账本表添加索引以提高查询性能
CREATE INDEX idx_warehouse_ledger_date
    ON class2_seat27_warehouse_ledger(ledger_date);

CREATE INDEX idx_warehouse_ledger_material_id
    ON class2_seat27_warehouse_ledger(material_id);

CREATE INDEX idx_warehouse_ledger_document_code
    ON class2_seat27_warehouse_ledger(document_code);

-- 更新多物料进出仓记录表，添加创建人和更新人字段（如果不存在）
SET @dbname = DATABASE();
SET @tablename = 'class2_seat27_multi_inout_record';
SET @columnname = 'created_by';
SET @preparedStatement = (SELECT IF(
                                         (
                                             SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
                                             WHERE
                                                 (table_schema = @dbname)
                                               AND (table_name = @tablename)
                                               AND (column_name = @columnname)
                                         ) > 0,
                                         'SELECT 1',
                                         CONCAT('ALTER TABLE ', @tablename, ' ADD COLUMN created_by BIGINT NULL AFTER handler_code,
          ADD COLUMN updated_by BIGINT NULL AFTER created_by,
          ADD FOREIGN KEY (created_by) REFERENCES class2_seat27_personnel(id),
          ADD FOREIGN KEY (updated_by) REFERENCES class2_seat27_personnel(id);')
                                 ));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 创建视图，方便查询多物料进出仓详细信息
CREATE OR REPLACE VIEW view_multi_inout_details AS
SELECT
    r.id AS record_id,
    r.document_code,
    r.operation_type,
    r.operation_date,
    r.operator_code,
    r.handler_code,
    r.remark,
    r.status,
    r.created_time,
    r.updated_time,
    d.id AS detail_id,
    d.material_code,
    d.material_name,
    d.specification,
    d.unit,
    d.quantity,
    d.unit_price,
    d.total_price,
    d.remark AS detail_remark
FROM
    class2_seat27_multi_inout_record r
        JOIN class2_seat27_multi_inout_detail d ON r.id = d.multi_inout_record_id
ORDER BY
    r.operation_date DESC, r.document_code, d.id;
