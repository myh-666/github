
-- 修复报表显示问题
-- 1. 修复物料统计存储过程，确保返回所有符合条件的记录
DROP PROCEDURE IF EXISTS `class2_seat27_material_flow_statistics`;
delimiter ;;
CREATE PROCEDURE `class2_seat27_material_flow_statistics`(
    IN p_start_date DATE,
    IN p_end_date DATE
)
BEGIN
    -- 查询指定时间范围内的进出仓数据
    SELECT
        m.id AS material_id,
        m.material_code,
        m.name AS material_name,
        m.specification,
        m.unit,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'INBOUND' THEN d.quantity
            ELSE 0
        END), 0) AS inbound_quantity,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'INBOUND' THEN d.total_price
            ELSE 0
        END), 0) AS inbound_amount,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'OUTBOUND' THEN d.quantity
            ELSE 0
        END), 0) AS outbound_quantity,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'OUTBOUND' THEN d.total_price
            ELSE 0
        END), 0) AS outbound_amount,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'INBOUND' THEN d.quantity
            ELSE -d.quantity
        END), 0) AS net_flow,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'INBOUND' THEN d.total_price
            ELSE -d.total_price
        END), 0) AS net_amount,
        COALESCE(inv.quantity, 0) AS current_quantity
    FROM
        class2_seat27_material m
    LEFT JOIN
        class2_seat27_multi_inout_detail d ON m.material_code = d.material_code
    LEFT JOIN
        class2_seat27_multi_inout_record r ON d.multi_inout_record_id = r.id
        AND (r.status = 'COMPLETED' OR r.status IS NULL)
        AND (p_start_date IS NULL OR DATE(r.operation_date) >= p_start_date)
        AND (p_end_date IS NULL OR DATE(r.operation_date) <= p_end_date)
    LEFT JOIN (
        SELECT i1.material_id, i1.quantity
        FROM class2_seat27_inventory i1
        INNER JOIN (
            SELECT material_id, MAX(id) as max_id
            FROM class2_seat27_inventory
            GROUP BY material_id
        ) i2 ON i1.material_id = i2.material_id AND i1.id = i2.max_id
    ) inv ON m.id = inv.material_id
    GROUP BY
        m.id, m.material_code, m.name, m.specification, m.unit, inv.quantity
    ORDER BY
        m.material_code;
END
;;
delimiter ;
