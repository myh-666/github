-- 修复多物料进出仓存储过程，确保记录状态正确设置为COMPLETED
USE class2_seat27_warehouse;

-- 删除现有的存储过程
DROP PROCEDURE IF EXISTS class2_seat27_多物料进仓;
DROP PROCEDURE IF EXISTS class2_seat27_多物料出仓;

-- 创建修复后的多物料进仓存储过程
DELIMITER //
CREATE PROCEDURE class2_seat27_多物料进仓(
    IN p_document_code VARCHAR(50),
    IN p_operation_date DATETIME,
    IN p_operator_code VARCHAR(50),
    IN p_handler_code VARCHAR(50),
    IN p_remark VARCHAR(500),
    IN p_materials JSON,
    OUT p_result INT,
    OUT p_message VARCHAR(500)
)
BEGIN
    DECLARE v_operator_id BIGINT;
    DECLARE v_material_count INT;
    DECLARE v_material_id BIGINT;
    DECLARE v_quantity INT;
    DECLARE v_unit_price DECIMAL(38,2);
    DECLARE v_total_price DECIMAL(38,2);
    DECLARE v_material_remark VARCHAR(500);
    DECLARE v_inventory_id BIGINT;
    DECLARE v_current_quantity INT;
    DECLARE v_new_quantity INT;
    DECLARE v_material_name VARCHAR(255);
    DECLARE v_material_code VARCHAR(255);
    DECLARE v_material_spec VARCHAR(200);
    DECLARE v_material_unit VARCHAR(20);
    DECLARE v_i INT DEFAULT 0;
    DECLARE v_same_document_exists INT DEFAULT 0;
    DECLARE v_operation_type VARCHAR(20);
    DECLARE v_error_occurred BOOLEAN DEFAULT FALSE;
    DECLARE v_record_id BIGINT;

    -- 异常处理，确保失败时回滚
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
            GET DIAGNOSTICS CONDITION 1
                p_message = MESSAGE_TEXT;
            SET p_result = 0;
            SET v_error_occurred = TRUE;
        END;

    -- 开始事务
    START TRANSACTION;

    -- 检查是否存在相同的单号
    SELECT COUNT(*) INTO v_same_document_exists
    FROM class2_seat27_multi_inout_record
    WHERE document_code = p_document_code;

    IF v_same_document_exists > 0 THEN
        -- 检查该单号是否已有出仓记录，确保同一单号不能同时有进仓和出仓
        SELECT operation_type INTO v_operation_type
        FROM class2_seat27_multi_inout_record
        WHERE document_code = p_document_code
        LIMIT 1;

        IF v_operation_type = 'OUTBOUND' THEN
            SET p_result = 0;
            SET p_message = CONCAT('单号 ', p_document_code, ' 已存在出仓记录，不能同时进行进仓操作');
            ROLLBACK;
            SET v_error_occurred = TRUE;
        END IF;
    END IF;

    -- 如果之前有错误，直接返回
    IF v_error_occurred THEN
        SET p_result = 0;
    ELSE
        -- 获取操作员ID
        SELECT id INTO v_operator_id
        FROM class2_seat27_personnel
        WHERE username = p_operator_code OR personnel_code = p_operator_code;

        IF v_operator_id IS NULL THEN
            SET p_result = 0;
            SET p_message = '操作员不存在';
            ROLLBACK;
            SET v_error_occurred = TRUE;
        ELSE
            -- 创建多物料进出仓记录，直接设置为COMPLETED状态
            INSERT INTO class2_seat27_multi_inout_record(
                document_code,
                operation_type,
                operation_date,
                operator_code,
                handler_code,
                remark,
                status
            ) VALUES (
                         p_document_code,
                         'INBOUND',
                         p_operation_date,
                         p_operator_code,
                         p_handler_code,
                         p_remark,
                         'COMPLETED'  -- 直接设置为COMPLETED状态
                     );

            -- 获取记录ID
            SET v_record_id = LAST_INSERT_ID();

            -- 获取物料数量
            SET v_material_count = JSON_LENGTH(p_materials);

            -- 遍历物料
            WHILE v_i < v_material_count AND v_error_occurred = FALSE DO
                -- 获取物料信息
                SET v_material_id = JSON_UNQUOTE(JSON_EXTRACT(p_materials, CONCAT('$[', v_i, '].materialId')));
                SET v_quantity = CAST(JSON_UNQUOTE(JSON_EXTRACT(p_materials, CONCAT('$[', v_i, '].quantity'))) AS UNSIGNED);
                SET v_unit_price = CAST(JSON_UNQUOTE(JSON_EXTRACT(p_materials, CONCAT('$[', v_i, '].unitPrice'))) AS DECIMAL(38,2));
                SET v_total_price = CAST(JSON_UNQUOTE(JSON_EXTRACT(p_materials, CONCAT('$[', v_i, '].totalPrice'))) AS DECIMAL(38,2));
                SET v_material_remark = JSON_UNQUOTE(JSON_EXTRACT(p_materials, CONCAT('$[', v_i, '].remark')));

                -- 检查物料是否存在
                SET v_material_name = NULL;
                SELECT name, material_code, specification, unit INTO v_material_name, v_material_code, v_material_spec, v_material_unit
                FROM class2_seat27_material WHERE id = v_material_id;

                IF v_material_name IS NULL THEN
                    SET p_result = 0;
                    SET p_message = CONCAT('物料ID ', v_material_id, ' 不存在');
                    ROLLBACK;
                    SET v_error_occurred = TRUE;
                ELSE
                    -- 创建多物料进出仓明细
                    INSERT INTO class2_seat27_multi_inout_detail(
                        multi_inout_record_id,
                        material_code,
                        material_name,
                        specification,
                        unit,
                        quantity,
                        unit_price,
                        total_price,
                        remark
                    ) VALUES (
                                 v_record_id,
                                 v_material_code,
                                 v_material_name,
                                 v_material_spec,
                                 v_material_unit,
                                 v_quantity,
                                 v_unit_price,
                                 v_total_price,
                                 v_material_remark
                             );

                    -- 获取当前库存
                    SET v_inventory_id = NULL;
                    SET v_current_quantity = NULL;
                    SELECT id, quantity INTO v_inventory_id, v_current_quantity
                    FROM class2_seat27_inventory
                    WHERE material_id = v_material_id;

                    -- 更新库存
                    SET v_new_quantity = IFNULL(v_current_quantity, 0) + v_quantity;

                    IF v_inventory_id IS NULL THEN
                        -- 插入新库存记录
                        INSERT INTO class2_seat27_inventory(
                            material_id,
                            quantity,
                            last_inbound_time,
                            created_by,
                            updated_by
                        ) VALUES (
                                     v_material_id,
                                     v_new_quantity,
                                     NOW(),
                                     v_operator_id,
                                     v_operator_id
                                 );
                    ELSE
                        -- 更新现有库存记录
                        UPDATE class2_seat27_inventory
                        SET quantity = v_new_quantity,
                            last_inbound_time = NOW(),
                            updated_by = v_operator_id,
                            updated_time = NOW()
                        WHERE id = v_inventory_id;
                    END IF;

                    -- 同时更新物料表中的库存数量
                    UPDATE class2_seat27_material
                    SET quantity = v_new_quantity,
                        updated_time = NOW()
                    WHERE id = v_material_id;

                    -- 记录仓库账本
                    INSERT INTO class2_seat27_warehouse_ledger(
                        ledger_date,
                        document_code,
                        operation_type,
                        material_id,
                        in_quantity,
                        in_amount,
                        out_quantity,
                        out_amount,
                        balance_quantity,
                        balance_amount,
                        remark
                    ) VALUES (
                                 DATE(p_operation_date),
                                 p_document_code,
                                 '进仓',
                                 v_material_id,
                                 v_quantity,
                                 v_total_price,
                                 0,
                                 0,
                                 v_new_quantity,
                                 v_new_quantity * v_unit_price,
                                 v_material_remark
                             );
                END IF;

                SET v_i = v_i + 1;
            END WHILE;

            -- 如果没有错误，提交事务
            IF v_error_occurred = FALSE THEN
                COMMIT;
                SET p_result = 1;
                SET p_message = CONCAT('多物料进仓成功，单号: ', p_document_code);
            ELSE
                ROLLBACK;
                SET p_result = 0;
                SET p_message = '多物料进仓失败';
            END IF;
        END IF;
    END IF;
END //
DELIMITER ;

-- 创建修复后的多物料出仓存储过程
DELIMITER //
CREATE PROCEDURE class2_seat27_多物料出仓(
    IN p_document_code VARCHAR(50),
    IN p_operation_date DATETIME,
    IN p_operator_code VARCHAR(50),
    IN p_handler_code VARCHAR(50),
    IN p_remark VARCHAR(500),
    IN p_materials JSON,
    OUT p_result INT,
    OUT p_message VARCHAR(500)
)
BEGIN
    DECLARE v_operator_id BIGINT;
    DECLARE v_material_count INT;
    DECLARE v_material_id BIGINT;
    DECLARE v_quantity INT;
    DECLARE v_unit_price DECIMAL(38,2);
    DECLARE v_total_price DECIMAL(38,2);
    DECLARE v_material_remark VARCHAR(500);
    DECLARE v_inventory_id BIGINT;
    DECLARE v_current_quantity INT;
    DECLARE v_new_quantity INT;
    DECLARE v_material_name VARCHAR(255);
    DECLARE v_material_code VARCHAR(255);
    DECLARE v_material_spec VARCHAR(200);
    DECLARE v_material_unit VARCHAR(20);
    DECLARE v_i INT DEFAULT 0;
    DECLARE v_same_document_exists INT DEFAULT 0;
    DECLARE v_operation_type VARCHAR(20);
    DECLARE v_error_occurred BOOLEAN DEFAULT FALSE;
    DECLARE v_record_id BIGINT;

    -- 异常处理，确保失败时回滚
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
            GET DIAGNOSTICS CONDITION 1
                p_message = MESSAGE_TEXT;
            SET p_result = 0;
            SET v_error_occurred = TRUE;
        END;

    -- 开始事务
    START TRANSACTION;

    -- 检查是否存在相同的单号
    SELECT COUNT(*) INTO v_same_document_exists
    FROM class2_seat27_multi_inout_record
    WHERE document_code = p_document_code;

    IF v_same_document_exists > 0 THEN
        -- 检查该单号是否已有进仓记录，确保同一单号不能同时有进仓和出仓
        SELECT operation_type INTO v_operation_type
        FROM class2_seat27_multi_inout_record
        WHERE document_code = p_document_code
        LIMIT 1;

        IF v_operation_type = 'INBOUND' THEN
            SET p_result = 0;
            SET p_message = CONCAT('单号 ', p_document_code, ' 已存在进仓记录，不能同时进行出仓操作');
            ROLLBACK;
            SET v_error_occurred = TRUE;
        END IF;
    END IF;

    -- 如果之前有错误，直接返回
    IF v_error_occurred THEN
        SET p_result = 0;
    ELSE
        -- 获取操作员ID
        SELECT id INTO v_operator_id
        FROM class2_seat27_personnel
        WHERE username = p_operator_code OR personnel_code = p_operator_code;

        IF v_operator_id IS NULL THEN
            SET p_result = 0;
            SET p_message = '操作员不存在';
            ROLLBACK;
            SET v_error_occurred = TRUE;
        ELSE
            -- 创建多物料进出仓记录，直接设置为COMPLETED状态
            INSERT INTO class2_seat27_multi_inout_record(
                document_code,
                operation_type,
                operation_date,
                operator_code,
                handler_code,
                remark,
                status
            ) VALUES (
                         p_document_code,
                         'OUTBOUND',
                         p_operation_date,
                         p_operator_code,
                         p_handler_code,
                         p_remark,
                         'COMPLETED'  -- 直接设置为COMPLETED状态
                     );

            -- 获取记录ID
            SET v_record_id = LAST_INSERT_ID();

            -- 获取物料数量
            SET v_material_count = JSON_LENGTH(p_materials);

            -- 遍历物料
            WHILE v_i < v_material_count AND v_error_occurred = FALSE DO
                -- 获取物料信息
                SET v_material_id = JSON_UNQUOTE(JSON_EXTRACT(p_materials, CONCAT('$[', v_i, '].materialId')));
                SET v_quantity = CAST(JSON_UNQUOTE(JSON_EXTRACT(p_materials, CONCAT('$[', v_i, '].quantity'))) AS UNSIGNED);
                SET v_unit_price = CAST(JSON_UNQUOTE(JSON_EXTRACT(p_materials, CONCAT('$[', v_i, '].unitPrice'))) AS DECIMAL(38,2));
                SET v_total_price = CAST(JSON_UNQUOTE(JSON_EXTRACT(p_materials, CONCAT('$[', v_i, '].totalPrice'))) AS DECIMAL(38,2));
                SET v_material_remark = JSON_UNQUOTE(JSON_EXTRACT(p_materials, CONCAT('$[', v_i, '].remark')));

                -- 检查物料是否存在
                SET v_material_name = NULL;
                SELECT name, material_code, specification, unit INTO v_material_name, v_material_code, v_material_spec, v_material_unit
                FROM class2_seat27_material WHERE id = v_material_id;

                IF v_material_name IS NULL THEN
                    SET p_result = 0;
                    SET p_message = CONCAT('物料ID ', v_material_id, ' 不存在');
                    ROLLBACK;
                    SET v_error_occurred = TRUE;
                ELSE
                    -- 获取当前库存
                    SET v_inventory_id = NULL;
                    SET v_current_quantity = NULL;
                    SELECT id, quantity INTO v_inventory_id, v_current_quantity
                    FROM class2_seat27_inventory
                    WHERE material_id = v_material_id;

                    -- 检查库存是否足够
                    IF v_inventory_id IS NULL OR v_current_quantity IS NULL OR v_current_quantity < v_quantity THEN
                        SET p_result = 0;
                        SET p_message = CONCAT('物料 ', v_material_name, '(', v_material_code, ') 库存不足，当前库存: ', IFNULL(v_current_quantity, 0), '，需要: ', v_quantity);
                        ROLLBACK;
                        SET v_error_occurred = TRUE;
                    ELSE
                        -- 创建多物料进出仓明细
                        INSERT INTO class2_seat27_multi_inout_detail(
                            multi_inout_record_id,
                            material_code,
                            material_name,
                            specification,
                            unit,
                            quantity,
                            unit_price,
                            total_price,
                            remark
                        ) VALUES (
                                     v_record_id,
                                     v_material_code,
                                     v_material_name,
                                     v_material_spec,
                                     v_material_unit,
                                     v_quantity,
                                     v_unit_price,
                                     v_total_price,
                                     v_material_remark
                                 );

                        -- 更新库存
                        SET v_new_quantity = v_current_quantity - v_quantity;

                        UPDATE class2_seat27_inventory
                        SET quantity = v_new_quantity,
                            last_outbound_time = NOW(),
                            updated_by = v_operator_id,
                            updated_time = NOW()
                        WHERE id = v_inventory_id;

                        -- 同时更新物料表中的库存数量
                        UPDATE class2_seat27_material
                        SET quantity = v_new_quantity,
                            updated_time = NOW()
                        WHERE id = v_material_id;

                        -- 记录仓库账本
                        INSERT INTO class2_seat27_warehouse_ledger(
                            ledger_date,
                            document_code,
                            operation_type,
                            material_id,
                            in_quantity,
                            in_amount,
                            out_quantity,
                            out_amount,
                            balance_quantity,
                            balance_amount,
                            remark
                        ) VALUES (
                                     DATE(p_operation_date),
                                     p_document_code,
                                     '出仓',
                                     v_material_id,
                                     0,
                                     0,
                                     v_quantity,
                                     v_total_price,
                                     v_new_quantity,
                                     v_new_quantity * v_unit_price,
                                     v_material_remark
                                 );
                    END IF;
                END IF;

                SET v_i = v_i + 1;
            END WHILE;

            -- 如果没有错误，提交事务
            IF v_error_occurred = FALSE THEN
                COMMIT;
                SET p_result = 1;
                SET p_message = CONCAT('多物料出仓成功，单号: ', p_document_code);
            ELSE
                ROLLBACK;
                SET p_result = 0;
                SET p_message = '多物料出仓失败';
            END IF;
        END IF;
    END IF;
END //
DELIMITER ;
