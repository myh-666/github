/*
 Navicat Premium Data Transfer

 Source Server         : MySQL80
 Source Server Type    : MySQL
 Source Server Version : 80043
 Source Host           : localhost:3306
 Source Schema         : class2_seat27_warehouse

 Target Server Type    : MySQL
 Target Server Version : 80043
 File Encoding         : 65001

 Date: 28/10/2025 21:58:51
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for class2_seat27_inbound
-- ----------------------------
DROP TABLE IF EXISTS `class2_seat27_inbound`;
CREATE TABLE `class2_seat27_inbound`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `inbound_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `inbound_date` datetime NOT NULL,
  `remark` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `status` enum('DRAFT','CONFIRMED','COMPLETED','CANCELLED') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'DRAFT',
  `created_by` bigint NOT NULL,
  `created_time` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `inbound_code`(`inbound_code`) USING BTREE,
  INDEX `created_by`(`created_by`) USING BTREE,
  CONSTRAINT `class2_seat27_inbound_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `class2_seat27_personnel` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of class2_seat27_inbound
-- ----------------------------
INSERT INTO `class2_seat27_inbound` VALUES (1, 'INB20231101001', '2023-11-01 10:00:00', '采购螺丝', 'COMPLETED', 1, '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_inbound` VALUES (2, 'INB20231105001', '2023-11-05 14:30:00', '采购螺母和垫片', 'COMPLETED', 1, '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_inbound` VALUES (3, 'INB20231110001', '2023-11-10 09:15:00', '采购轴承和齿轮', 'COMPLETED', 1, '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_inbound` VALUES (4, 'INB20231115001', '2023-11-15 16:45:00', '采购电机和皮带', 'COMPLETED', 1, '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_inbound` VALUES (5, 'INB20231120001', '2023-11-20 11:20:00', '采购螺栓和电线', 'COMPLETED', 1, '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_inbound` VALUES (6, 'INB20231125001', '2023-11-25 15:10:00', '采购开关', 'COMPLETED', 1, '2025-10-13 21:36:03', '2025-10-13 21:36:03');

-- ----------------------------
-- Table structure for class2_seat27_inbound_detail
-- ----------------------------
DROP TABLE IF EXISTS `class2_seat27_inbound_detail`;
CREATE TABLE `class2_seat27_inbound_detail`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `inbound_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `quantity` int NOT NULL,
  `unit_price` decimal(38, 2) NULL DEFAULT NULL,
  `total_price` decimal(38, 2) NULL DEFAULT NULL,
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `created_time` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `inbound_id`(`inbound_id`) USING BTREE,
  INDEX `material_id`(`material_id`) USING BTREE,
  INDEX `idx_inbound_detail_created_by`(`created_by`) USING BTREE,
  CONSTRAINT `class2_seat27_inbound_detail_ibfk_1` FOREIGN KEY (`inbound_id`) REFERENCES `class2_seat27_inbound` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `class2_seat27_inbound_detail_ibfk_2` FOREIGN KEY (`material_id`) REFERENCES `class2_seat27_material` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `class2_seat27_inbound_detail_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `class2_seat27_personnel` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
  CONSTRAINT `FK537g78ylcss014qjbx5bdw7rn` FOREIGN KEY (`created_by`) REFERENCES `class2_seat27_personnel` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of class2_seat27_inbound_detail
-- ----------------------------
INSERT INTO `class2_seat27_inbound_detail` VALUES (11, 1, 1, 5000, 0.10, 500.00, '采购螺丝', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_inbound_detail` VALUES (12, 2, 2, 3000, 0.05, 150.00, '采购螺母', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_inbound_detail` VALUES (13, 2, 3, 2000, 0.02, 40.00, '采购垫片', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_inbound_detail` VALUES (15, 3, 5, 50, 50.00, 2500.00, '采购齿轮', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_inbound_detail` VALUES (16, 4, 6, 20, 30.00, 600.00, '采购皮带', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_inbound_detail` VALUES (17, 4, 7, 5, 500.00, 2500.00, '采购电机', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_inbound_detail` VALUES (18, 5, 8, 2000, 0.20, 400.00, '采购螺栓', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_inbound_detail` VALUES (19, 5, 9, 1000, 2.00, 2000.00, '采购电线', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_inbound_detail` VALUES (20, 6, 10, 100, 10.00, 1000.00, '采购开关', '2025-10-13 21:36:03', NULL);

-- ----------------------------
-- Table structure for class2_seat27_inout_record
-- ----------------------------
DROP TABLE IF EXISTS `class2_seat27_inout_record`;
CREATE TABLE `class2_seat27_inout_record`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NULL DEFAULT NULL,
  `document_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `handler_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `material_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `operation_date` datetime(6) NOT NULL,
  `operation_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `operator_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `quantity` int NOT NULL,
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `status` enum('CANCELLED','COMPLETED','CONFIRMED','DRAFT') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `total_price` decimal(38, 2) NULL DEFAULT NULL,
  `unit_price` decimal(38, 2) NULL DEFAULT NULL,
  `updated_time` datetime(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `UKxo6q8gj4c8i3e0vnq3724ffu`(`document_code`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of class2_seat27_inout_record
-- ----------------------------

-- ----------------------------
-- Table structure for class2_seat27_inventory
-- ----------------------------
DROP TABLE IF EXISTS `class2_seat27_inventory`;
CREATE TABLE `class2_seat27_inventory`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `material_id` bigint NOT NULL,
  `quantity` int NOT NULL,
  `last_inbound_time` datetime NULL DEFAULT NULL,
  `last_outbound_time` datetime NULL DEFAULT NULL,
  `created_by` bigint NULL DEFAULT NULL,
  `created_time` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NULL DEFAULT NULL,
  `updated_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `material_id`(`material_id`) USING BTREE,
  INDEX `created_by`(`created_by`) USING BTREE,
  INDEX `updated_by`(`updated_by`) USING BTREE,
  CONSTRAINT `class2_seat27_inventory_ibfk_1` FOREIGN KEY (`material_id`) REFERENCES `class2_seat27_material` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `class2_seat27_inventory_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `class2_seat27_personnel` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `class2_seat27_inventory_ibfk_3` FOREIGN KEY (`updated_by`) REFERENCES `class2_seat27_personnel` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 70 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of class2_seat27_inventory
-- ----------------------------
INSERT INTO `class2_seat27_inventory` VALUES (41, 1, 2020, '2025-10-28 01:01:45', '2025-10-28 11:00:09', 3, '2025-10-13 21:36:03', 1, '2025-10-28 11:00:09');
INSERT INTO `class2_seat27_inventory` VALUES (42, 2, 1000, '2025-10-24 22:28:55', '2025-10-26 16:09:05', 3, '2025-10-13 21:36:03', 1, '2025-10-26 16:25:08');
INSERT INTO `class2_seat27_inventory` VALUES (43, 3, 800, '2025-10-27 23:47:10', '2025-10-28 01:02:08', 3, '2025-10-13 21:36:03', 1, '2025-10-28 01:02:08');
INSERT INTO `class2_seat27_inventory` VALUES (45, 5, 2000, '2025-10-28 01:01:45', '2025-10-26 16:30:09', 3, '2025-10-13 21:36:03', 1, '2025-10-28 21:43:23');
INSERT INTO `class2_seat27_inventory` VALUES (46, 6, 1100, '2025-10-28 11:53:48', NULL, 3, '2025-10-13 21:36:03', 1, '2025-10-28 11:53:48');
INSERT INTO `class2_seat27_inventory` VALUES (47, 7, 1900, '2025-10-28 11:00:32', '2025-10-26 21:55:58', 3, '2025-10-13 21:36:03', 1, '2025-10-28 11:00:32');
INSERT INTO `class2_seat27_inventory` VALUES (48, 8, 1000, '2025-10-13 21:36:03', '2025-10-23 20:56:05', 3, '2025-10-13 21:36:03', 1, '2025-10-26 16:25:19');
INSERT INTO `class2_seat27_inventory` VALUES (49, 9, 1800, '2025-10-28 00:16:04', '2025-10-28 11:28:32', 3, '2025-10-13 21:36:03', 1, '2025-10-28 11:28:32');
INSERT INTO `class2_seat27_inventory` VALUES (50, 10, 1000, '2025-10-26 21:53:21', '2025-10-28 10:51:52', 3, '2025-10-13 21:36:03', 1, '2025-10-28 10:51:52');
INSERT INTO `class2_seat27_inventory` VALUES (54, 29, 125, '2025-10-26 16:29:56', NULL, 1, '2025-10-26 16:29:56', 1, '2025-10-26 16:29:56');
INSERT INTO `class2_seat27_inventory` VALUES (55, 35, 150, '2025-10-28 11:12:50', '2025-10-27 23:47:24', 1, '2025-10-26 16:40:38', 1, '2025-10-28 11:12:50');
INSERT INTO `class2_seat27_inventory` VALUES (56, 36, 110, '2025-10-26 21:36:47', NULL, 1, '2025-10-26 21:36:06', 1, '2025-10-26 21:36:47');
INSERT INTO `class2_seat27_inventory` VALUES (57, 37, 265, '2025-10-28 11:35:38', NULL, 1, '2025-10-26 21:57:39', 1, '2025-10-28 11:35:38');
INSERT INTO `class2_seat27_inventory` VALUES (60, 38, 200, '2025-10-26 22:38:47', NULL, 1, '2025-10-26 22:34:58', 1, '2025-10-26 22:38:47');
INSERT INTO `class2_seat27_inventory` VALUES (63, 41, 1030, '2025-10-28 11:27:47', '2025-10-27 23:31:14', 1, '2025-10-26 22:50:49', 1, '2025-10-28 11:27:47');
INSERT INTO `class2_seat27_inventory` VALUES (64, 42, 360, '2025-10-28 11:36:27', NULL, NULL, '2025-10-26 23:04:40', 1, '2025-10-28 11:36:27');
INSERT INTO `class2_seat27_inventory` VALUES (65, 43, 1910, '2025-10-28 11:19:15', '2025-10-28 11:36:40', NULL, '2025-10-26 23:06:05', 1, '2025-10-28 11:36:40');
INSERT INTO `class2_seat27_inventory` VALUES (66, 44, 335, '2025-10-27 23:31:01', '2025-10-28 00:40:29', NULL, '2025-10-27 23:30:46', 1, '2025-10-28 00:40:29');
INSERT INTO `class2_seat27_inventory` VALUES (67, 45, 3700, '2025-10-28 11:53:48', NULL, NULL, '2025-10-28 11:17:57', 1, '2025-10-28 11:53:48');
INSERT INTO `class2_seat27_inventory` VALUES (68, 46, 1655, '2025-10-28 11:27:47', NULL, NULL, '2025-10-28 11:26:40', 1, '2025-10-28 11:27:47');
INSERT INTO `class2_seat27_inventory` VALUES (69, 47, 99999, NULL, NULL, NULL, '2025-10-28 21:29:24', NULL, '2025-10-28 13:29:24');

-- ----------------------------
-- Table structure for class2_seat27_material
-- ----------------------------
DROP TABLE IF EXISTS `class2_seat27_material`;
CREATE TABLE `class2_seat27_material`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `material_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `specification` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `unit` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '个',
  `quantity` int NULL DEFAULT NULL,
  `price` decimal(38, 2) NULL DEFAULT NULL,
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `created_time` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `category` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `supplier` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `min_stock` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `material_code`(`material_code`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 48 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of class2_seat27_material
-- ----------------------------
INSERT INTO `class2_seat27_material` VALUES (1, 'M001', '螺丝', 'M5', '个', 2020, 33.00, '常用螺丝', '2025-10-13 15:10:51', '2025-10-28 11:00:09', NULL, NULL, NULL, NULL, 300);
INSERT INTO `class2_seat27_material` VALUES (2, 'M002', '螺母', 'M5', '个', 1000, 22.00, '常用螺母', '2025-10-13 15:02:01', '2025-10-26 16:24:10', NULL, NULL, NULL, NULL, 300);
INSERT INTO `class2_seat27_material` VALUES (3, 'M003', '垫片', 'Φ10mm', '个', 800, 3.00, '金属垫片', '2025-10-13 21:36:03', '2025-10-28 01:02:08', NULL, NULL, NULL, NULL, 300);
INSERT INTO `class2_seat27_material` VALUES (5, 'M005', '齿轮', '模数2', '个', 2000, 44.00, '传动齿轮', '2025-10-13 21:36:03', '2025-10-28 21:43:23', NULL, NULL, NULL, NULL, 100);
INSERT INTO `class2_seat27_material` VALUES (6, 'M006', '皮带', '长度1m', '个', 1100, 30.00, '传动皮带', '2025-10-13 21:36:03', '2025-10-28 11:53:48', NULL, NULL, NULL, NULL, 300);
INSERT INTO `class2_seat27_material` VALUES (7, 'M007', '电机', '功率1kW', '台', 1900, 500.00, '驱动电机', '2025-10-13 21:36:03', '2025-10-28 11:00:32', NULL, NULL, NULL, NULL, 300);
INSERT INTO `class2_seat27_material` VALUES (8, 'M008', '螺栓', 'M8×50mm', '个', 1000, 22.00, '高强度螺栓', '2025-10-13 21:36:03', '2025-10-26 16:24:22', NULL, NULL, NULL, NULL, 300);
INSERT INTO `class2_seat27_material` VALUES (9, 'M009', '电线', '截面积1.5mm²', '米', 1800, 88.00, '电源线', '2025-10-13 15:02:25', '2025-10-28 11:28:32', NULL, NULL, NULL, NULL, 300);
INSERT INTO `class2_seat27_material` VALUES (10, 'M010', '开关', '单相220V', '个', 1000, 10.00, '电源开关', '2025-10-13 21:36:03', '2025-10-28 10:51:52', NULL, NULL, NULL, NULL, 300);
INSERT INTO `class2_seat27_material` VALUES (29, 'M013', '充电宝', 'sss', '个', 125, 44.00, '', '2025-10-19 01:40:59', '2025-10-26 16:29:56', NULL, NULL, NULL, NULL, 300);
INSERT INTO `class2_seat27_material` VALUES (35, 'M004', '哈哈', 'dd', '个', 150, 44.00, '', '2025-10-27 21:56:45', '2025-10-28 11:12:50', NULL, NULL, NULL, NULL, 100);
INSERT INTO `class2_seat27_material` VALUES (36, 'M015', '插排', '15*10', '个', 110, 49.00, '', '2025-10-27 21:56:49', '2025-10-27 21:56:51', NULL, NULL, NULL, NULL, 400);
INSERT INTO `class2_seat27_material` VALUES (37, 'M012', '插头', '10*10', '个', 265, 29.90, '', '2025-10-27 21:56:52', '2025-10-28 11:35:38', NULL, NULL, NULL, NULL, 500);
INSERT INTO `class2_seat27_material` VALUES (38, 'M011', '充电线', '1.5m', '个', 200, 15.00, '', '2025-10-27 21:56:56', '2025-10-27 21:56:59', NULL, NULL, NULL, NULL, 100);
INSERT INTO `class2_seat27_material` VALUES (41, 'M017', '湖南会馆', '发达的', '个', 1030, 20.00, '', '2025-10-27 21:57:02', '2025-10-28 11:27:47', NULL, NULL, NULL, NULL, 20);
INSERT INTO `class2_seat27_material` VALUES (42, 'M016', 'vvv', 'vvv', '个', 360, 44.00, '', '2025-10-27 21:57:05', '2025-10-28 11:36:27', NULL, NULL, NULL, NULL, 50);
INSERT INTO `class2_seat27_material` VALUES (43, 'M020', '电容笔', '15cm', 'ge', 1910, 2399.00, '', '2025-10-27 21:57:08', '2025-10-28 11:36:40', NULL, NULL, NULL, NULL, 100);
INSERT INTO `class2_seat27_material` VALUES (44, 'M021', '镜子', '22', '个', 335, 15.00, '', NULL, '2025-10-28 00:40:29', NULL, NULL, NULL, NULL, 100);
INSERT INTO `class2_seat27_material` VALUES (45, 'MO23', '保温杯', '500ml*红', '个', 3700, 69.00, '', NULL, '2025-10-28 11:53:48', NULL, NULL, NULL, NULL, 690);
INSERT INTO `class2_seat27_material` VALUES (46, 'M0011', '杯垫', '15*15', '个', 1655, 15.00, '', NULL, '2025-10-28 11:27:47', NULL, NULL, NULL, NULL, 1500);
INSERT INTO `class2_seat27_material` VALUES (47, 'M088', '刚刚', '10*10', '公斤', 99999, 44.00, '', NULL, '2025-10-28 13:29:24', NULL, NULL, NULL, NULL, 4444);

-- ----------------------------
-- Table structure for class2_seat27_material_statistics
-- ----------------------------
DROP TABLE IF EXISTS `class2_seat27_material_statistics`;
CREATE TABLE `class2_seat27_material_statistics`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `material_id` bigint NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `inbound_quantity` int NULL DEFAULT NULL,
  `inbound_amount` decimal(38, 2) NULL DEFAULT NULL,
  `outbound_quantity` int NULL DEFAULT NULL,
  `outbound_amount` decimal(38, 2) NULL DEFAULT NULL,
  `net_flow` int NULL DEFAULT NULL,
  `net_amount` decimal(38, 2) NULL DEFAULT NULL,
  `created_time` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `material_id`(`material_id`) USING BTREE,
  CONSTRAINT `class2_seat27_material_statistics_ibfk_1` FOREIGN KEY (`material_id`) REFERENCES `class2_seat27_material` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of class2_seat27_material_statistics
-- ----------------------------
INSERT INTO `class2_seat27_material_statistics` VALUES (11, 1, '2023-11-01', '2023-11-30', 3000, 300.00, 2000, 200.00, 1000, 100.00, '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_material_statistics` VALUES (12, 2, '2023-11-01', '2023-11-30', 2200, 110.00, 1700, 85.00, 500, 25.00, '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_material_statistics` VALUES (13, 3, '2023-11-01', '2023-11-30', 1500, 30.00, 1250, 25.00, 250, 5.00, '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_material_statistics` VALUES (15, 5, '2023-11-01', '2023-11-30', 20, 1000.00, 10, 500.00, 10, 500.00, '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_material_statistics` VALUES (16, 6, '2023-11-01', '2023-11-30', 10, 300.00, 5, 150.00, 5, 150.00, '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_material_statistics` VALUES (17, 7, '2023-11-01', '2023-11-30', 2, 1000.00, 1, 500.00, 1, 500.00, '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_material_statistics` VALUES (18, 8, '2023-11-01', '2023-11-30', 1000, 200.00, 1000, 200.00, 0, 0.00, '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_material_statistics` VALUES (19, 9, '2023-11-01', '2023-11-30', 500, 1000.00, 750, 1500.00, -250, -500.00, '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_material_statistics` VALUES (20, 10, '2023-11-01', '2023-11-30', 100, 1000.00, 50, 500.00, 50, 500.00, '2025-10-13 21:36:03');

-- ----------------------------
-- Table structure for class2_seat27_multi_inout_detail
-- ----------------------------
DROP TABLE IF EXISTS `class2_seat27_multi_inout_detail`;
CREATE TABLE `class2_seat27_multi_inout_detail`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `multi_inout_record_id` bigint NOT NULL,
  `material_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `material_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `specification` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `unit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `quantity` int NOT NULL,
  `unit_price` decimal(38, 2) NULL DEFAULT NULL,
  `total_price` decimal(38, 2) NULL DEFAULT NULL,
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `created_time` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_time` datetime(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_multi_inout_detail_record_id`(`multi_inout_record_id`) USING BTREE,
  INDEX `idx_multi_inout_detail_material_code`(`material_code`) USING BTREE,
  CONSTRAINT `class2_seat27_multi_inout_detail_ibfk_1` FOREIGN KEY (`multi_inout_record_id`) REFERENCES `class2_seat27_multi_inout_record` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_multi_inout_detail_material` FOREIGN KEY (`material_code`) REFERENCES `class2_seat27_material` (`material_code`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 135 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of class2_seat27_multi_inout_detail
-- ----------------------------
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (25, 1, 'M001', '螺丝', 'M5×20mm', '个', 2000, 0.10, 200.00, '采购螺丝', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (26, 1, 'M002', '螺母', 'M5', '个', 1500, 0.05, 75.00, '采购螺母', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (27, 1, 'M003', '垫片', 'Φ10mm', '个', 1000, 0.02, 20.00, '采购垫片', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (28, 2, 'M001', '螺丝', 'M5×20mm', '个', 1000, 0.10, 100.00, '生产领用螺丝', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (29, 2, 'M002', '螺母', 'M5', '个', 800, 0.05, 40.00, '生产领用螺母', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (31, 3, 'M005', '齿轮', '模数2', '个', 20, 50.00, 1000.00, '采购齿轮', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (33, 4, 'M005', '齿轮', '模数2', '个', 10, 50.00, 500.00, '生产领用齿轮', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (34, 5, 'M006', '皮带', '长度1m', '条', 10, 30.00, 300.00, '采购皮带', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (35, 5, 'M007', '电机', '功率1kW', '台', 2, 500.00, 1000.00, '采购电机', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (36, 6, 'M006', '皮带', '长度1m', '条', 5, 30.00, 150.00, '生产领用皮带', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (37, 6, 'M007', '电机', '功率1kW', '台', 1, 500.00, 500.00, '生产领用电机', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (38, 7, 'M008', '螺栓', 'M8×50mm', '个', 1000, 0.20, 200.00, '采购螺栓', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (39, 7, 'M009', '电线', '截面积1.5mm²', '米', 500, 2.00, 1000.00, '采购电线', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (40, 8, 'M008', '螺栓', 'M8×50mm', '个', 500, 0.20, 100.00, '生产领用螺栓', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (41, 8, 'M009', '电线', '截面积1.5mm²', '米', 250, 2.00, 500.00, '生产领用电线', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (42, 9, 'M001', '螺丝', 'M5×20mm', '个', 1000, 0.10, 100.00, '采购螺丝', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (43, 9, 'M002', '螺母', 'M5', '个', 700, 0.05, 35.00, '采购螺母', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (44, 9, 'M003', '垫片', 'Φ10mm', '个', 500, 0.02, 10.00, '采购垫片', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (45, 10, 'M001', '螺丝', 'M5×20mm', '个', 500, 0.10, 50.00, '生产领用螺丝', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (46, 10, 'M002', '螺母', 'M5', '个', 400, 0.05, 20.00, '生产领用螺母', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (47, 11, 'M010', '开关', '单相220V', '个', 100, 10.00, 1000.00, '采购开关', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (48, 12, 'M010', '开关', '单相220V', '个', 50, 10.00, 500.00, '生产领用开关', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (49, 13, 'M001', '螺丝', 'M5', '个', 100, 0.10, 10.00, '测试进仓螺丝', '2025-10-21 21:48:52', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (50, 13, 'M002', '螺母', 'M5', '个', 50, 0.05, 2.50, '测试进仓螺母', '2025-10-21 21:48:52', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (51, 14, 'M001', '螺丝', 'M5', '个', 30, 0.10, 3.00, '测试出仓螺丝', '2025-10-21 21:48:52', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (52, 14, 'M002', '螺母', 'M5', '个', 20, 0.05, 1.00, '测试出仓螺母', '2025-10-21 21:48:52', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (53, 15, 'M001', '螺丝', 'M5', '个', 10000, 0.10, 1000.00, '测试库存不足', '2025-10-21 21:48:52', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (54, 16, 'M001', '螺丝', 'M5', '个', 10, 0.10, 1.00, '测试重复单号', '2025-10-21 21:48:52', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (55, 18, 'M005', '齿轮', '模数2', '个', 100, 44.00, 4400.00, '', '2025-10-23 20:37:10', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (56, 20, 'M002', '螺母', 'M5', '个', 10, 22.00, 220.00, '', '2025-10-23 20:37:58', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (57, 20, 'M002', '螺母', 'M5', '个', 10, 22.00, 220.00, '', '2025-10-23 20:44:14', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (58, 21, 'M003', '垫片', 'Φ10mm', '个', 555, 3.00, 1665.00, '', '2025-10-23 20:55:35', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (59, 23, 'M008', '螺栓', 'M8×50mm', '个', 99, 22.00, 2178.00, '', '2025-10-23 20:56:05', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (61, 24, 'M003', '垫片', 'Φ10mm', '个', 55, 3.00, 165.00, '', '2025-10-24 01:59:34', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (62, 25, 'M002', '螺母', 'M5', '个', 7777, 22.00, 171094.00, '', '2025-10-24 08:23:11', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (63, 31, 'M007', '电机', '功率1kW', '台', 10, 500.00, 5000.00, '', '2025-10-24 12:48:00', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (64, 33, 'M002', '螺母', 'M5', '个', 10, 22.00, 220.00, '', '2025-10-24 22:22:45', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (65, 34, 'M002', '螺母', 'M5', '个', 8000, 22.00, 176000.00, '', '2025-10-24 22:28:21', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (66, 35, 'M002', '螺母', 'M5', '个', 8000, 22.00, 176000.00, '', '2025-10-24 22:28:55', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (67, 40, 'M010', '开关', '单相220V', '个', 300, 10.00, 3000.00, '', '2025-10-26 16:06:56', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (71, 44, 'M002', '螺母', 'M5', '个', 100, 22.00, 2200.00, '', '2025-10-26 16:09:05', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (79, 49, 'M013', '充电宝', 'sss', '个', 125, 44.00, 5500.00, '', '2025-10-26 16:29:56', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (80, 50, 'M005', '齿轮', '模数2', '个', 100, 44.00, 4400.00, '', '2025-10-26 16:30:09', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (81, 51, 'M004', '哈哈哈', 'dd', '个', 20, 44.00, 880.00, '', '2025-10-26 16:40:38', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (83, 53, 'M007', '电机', '功率1kW', '台', 100, 500.00, 50000.00, '', '2025-10-26 16:41:40', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (84, 54, 'M004', '哈哈哈', 'dd', '个', 40, 44.00, 1760.00, '', '2025-10-26 16:49:07', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (85, 55, 'M003', '垫片', 'Φ10mm', '个', 200, 3.00, 600.00, '', '2025-10-26 16:49:21', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (86, 56, 'M003', '垫片', 'Φ10mm', '个', 20, 3.00, 60.00, '', '2025-10-26 19:53:55', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (87, 57, 'M015', '插排', '15*10', '个', 55, 49.00, 2695.00, '', '2025-10-26 21:36:06', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (88, 58, 'M015', '插排', '15*10', '个', 55, 49.00, 2695.00, '', '2025-10-26 21:36:47', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (89, 59, 'M010', '开关', '单相220V', '个', 99, 10.00, 990.00, '', '2025-10-26 21:53:21', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (90, 60, 'M001', '螺丝', 'M5', '个', 12, 33.00, 396.00, '', '2025-10-26 21:55:28', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (91, 61, 'M007', '电机', '功率1kW', '台', 10, 500.00, 5000.00, '', '2025-10-26 21:55:58', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (92, 62, 'M012', '插头', '10*10', '个', 50, 29.90, 1495.00, '', '2025-10-26 21:57:39', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (95, 65, 'M011', '充电线', '1.5m', '个', 50, 15.00, 750.00, '', '2025-10-26 22:34:58', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (96, 66, 'M011', '充电线', '1.5m', '个', 150, 15.00, 2250.00, '', '2025-10-26 22:38:47', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (100, 70, 'M017', '湖南会馆', '发达的', '个', 20, 20.00, 400.00, '', '2025-10-26 22:50:49', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (101, 71, 'M016', 'vvv', 'vvv', '个', 16, 44.00, 704.00, '', '2025-10-26 23:04:55', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (102, 72, 'M020', '电容笔', '15cm', '个', 10, 2399.00, 23990.00, '', '2025-10-26 23:06:35', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (104, 74, 'M001', '螺丝', 'M5', '个', 500, 33.00, 16500.00, '', '2025-10-27 23:28:45', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (105, 75, 'M001', '螺丝', 'M5', '个', 10, 33.00, 330.00, '', '2025-10-27 23:29:10', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (106, 76, 'M021', '镜子', '22', '个', 10, 15.00, 150.00, '', '2025-10-27 23:31:01', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (107, 77, 'M017', '湖南会馆', '发达的', '个', 10, 20.00, 200.00, '', '2025-10-27 23:31:14', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (108, 78, 'M003', '垫片', 'Φ10mm', '个', 80, 3.00, 240.00, '', '2025-10-27 23:47:10', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (109, 79, 'M004', '哈哈', 'dd', '个', 10, 44.00, 440.00, '', '2025-10-27 23:47:24', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (110, 80, 'M001', '螺丝', 'M5', '个', 18, 33.00, 594.00, '', '2025-10-27 23:48:58', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (111, 81, 'M021', '镜子', '22', '个', 15, 15.00, 225.00, '', '2025-10-27 23:49:14', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (112, 82, 'M009', '电线', '截面积1.5mm²', '米', 1000, 88.00, 88000.00, '', '2025-10-28 00:16:04', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (113, 83, 'M001', '螺丝', 'M5', '个', 1000, 33.00, 33000.00, '', '2025-10-28 00:40:13', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (114, 84, 'M021', '镜子', '22', '个', 100, 15.00, 1500.00, '', '2025-10-28 00:40:29', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (115, 85, 'M001', '螺丝', 'M5', '个', 500, 33.00, 16500.00, '', '2025-10-28 01:01:45', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (116, 85, 'M005', '齿轮', '模数2', '个', 100, 44.00, 4400.00, '', '2025-10-28 01:01:45', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (117, 86, 'M003', '垫片', 'Φ10mm', '个', 100, 3.00, 300.00, '', '2025-10-28 01:02:08', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (118, 87, 'M010', '开关', '单相220V', '个', 99, 10.00, 990.00, '', '2025-10-28 10:51:52', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (119, 88, 'M001', '螺丝', 'M5', '个', 1000, 33.00, 33000.00, '', '2025-10-28 11:00:09', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (120, 89, 'M007', '电机', '功率1kW', '台', 1000, 500.00, 500000.00, '', '2025-10-28 11:00:32', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (121, 90, 'M004', '哈哈', 'dd', '个', 100, 44.00, 4400.00, '', '2025-10-28 11:12:50', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (122, 91, 'MO23', '保温杯', '500ml*红', 'ge', 2000, 69.00, 138000.00, '', '2025-10-28 11:18:46', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (123, 92, 'M009', '电线', '截面积1.5mm²', '米', 100, 88.00, 8800.00, '', '2025-10-28 11:19:01', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (124, 93, 'M020', '电容笔', '15cm', 'ge', 1900, 2399.00, 4558100.00, '', '2025-10-28 11:19:15', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (125, 94, 'M0011', '杯垫', '15*15', '个', 150, 15.00, 2250.00, '', '2025-10-28 11:27:47', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (126, 94, 'M017', '湖南会馆', '发达的', '个', 1000, 20.00, 20000.00, '', '2025-10-28 11:27:47', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (127, 95, 'M012', '插头', '10*10', '个', 15, 29.90, 448.50, '', '2025-10-28 11:28:10', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (128, 96, 'M009', '电线', '截面积1.5mm²', '米', 100, 88.00, 8800.00, '', '2025-10-28 11:28:32', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (129, 97, 'M012', '插头', '10*10', '个', 100, 29.90, 2990.00, '', '2025-10-28 11:35:38', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (130, 97, 'M012', '插头', '10*10', '个', 100, 29.90, 2990.00, '', '2025-10-28 11:35:38', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (131, 98, 'M016', 'vvv', 'vvv', '个', 300, 44.00, 13200.00, '', '2025-10-28 11:36:27', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (132, 99, 'M020', '电容笔', '15cm', 'ge', 100, 2399.00, 239900.00, '', '2025-10-28 11:36:40', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (133, 100, 'M006', '皮带', '长度1m', '个', 100, 30.00, 3000.00, '', '2025-10-28 11:53:48', NULL);
INSERT INTO `class2_seat27_multi_inout_detail` VALUES (134, 100, 'MO23', '保温杯', '500ml*红', '个', 200, 69.00, 13800.00, '', '2025-10-28 11:53:48', NULL);

-- ----------------------------
-- Table structure for class2_seat27_multi_inout_record
-- ----------------------------
DROP TABLE IF EXISTS `class2_seat27_multi_inout_record`;
CREATE TABLE `class2_seat27_multi_inout_record`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `document_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `operation_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `operation_date` datetime NOT NULL,
  `operator_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `handler_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `created_by` bigint NULL DEFAULT NULL,
  `updated_by` bigint NULL DEFAULT NULL,
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `status` enum('DRAFT','CONFIRMED','COMPLETED','CANCELLED') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'CONFIRMED',
  `created_time` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `document_code`(`document_code`) USING BTREE,
  INDEX `idx_multi_inout_record_type_date`(`operation_type`, `operation_date`) USING BTREE,
  INDEX `idx_multi_inout_record_status`(`status`) USING BTREE,
  INDEX `created_by`(`created_by`) USING BTREE,
  INDEX `updated_by`(`updated_by`) USING BTREE,
  CONSTRAINT `class2_seat27_multi_inout_record_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `class2_seat27_personnel` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `class2_seat27_multi_inout_record_ibfk_2` FOREIGN KEY (`updated_by`) REFERENCES `class2_seat27_personnel` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 101 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of class2_seat27_multi_inout_record
-- ----------------------------
INSERT INTO `class2_seat27_multi_inout_record` VALUES (1, 'MIIN20231101001', 'INBOUND', '2023-11-01 10:00:00', 'P001', 'P002', NULL, NULL, '采购一批物料', 'CONFIRMED', '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (2, 'MIOUT20231103001', 'OUTBOUND', '2023-11-03 09:30:00', 'P003', 'P004', NULL, NULL, '生产领用一批物料', 'CONFIRMED', '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (3, 'MIIN20231105001', 'INBOUND', '2023-11-05 14:30:00', 'P001', 'P002', NULL, NULL, '采购一批物料', 'CONFIRMED', '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (4, 'MIOUT20231108001', 'OUTBOUND', '2023-11-08 14:15:00', 'P003', 'P004', NULL, NULL, '生产领用一批物料', 'CONFIRMED', '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (5, 'MIIN20231110001', 'INBOUND', '2023-11-10 09:15:00', 'P001', 'P002', NULL, NULL, '采购一批物料', 'CONFIRMED', '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (6, 'MIOUT20231113001', 'OUTBOUND', '2023-11-13 10:45:00', 'P003', 'P004', NULL, NULL, '生产领用一批物料', 'CONFIRMED', '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (7, 'MIIN20231115001', 'INBOUND', '2023-11-15 16:45:00', 'P001', 'P002', NULL, NULL, '采购一批物料', 'CONFIRMED', '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (8, 'MIOUT20231118001', 'OUTBOUND', '2023-11-18 16:20:00', 'P003', 'P004', NULL, NULL, '生产领用一批物料', 'CONFIRMED', '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (9, 'MIIN20231120001', 'INBOUND', '2023-11-20 11:20:00', 'P001', 'P002', NULL, NULL, '采购一批物料', 'CONFIRMED', '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (10, 'MIOUT20231123001', 'OUTBOUND', '2023-11-23 11:05:00', 'P003', 'P004', NULL, NULL, '生产领用一批物料', 'CONFIRMED', '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (11, 'MIIN20231125001', 'INBOUND', '2023-11-25 15:10:00', 'P001', 'P002', NULL, NULL, '采购一批物料', 'CONFIRMED', '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (12, 'MIOUT20231128001', 'OUTBOUND', '2023-11-28 15:30:00', 'P003', 'P004', NULL, NULL, '生产领用一批物料', 'CONFIRMED', '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (13, 'TEST_IN_001', 'INBOUND', '2025-10-21 21:48:52', 'admin', 'P002', NULL, NULL, '测试多物料进仓', 'DRAFT', '2025-10-21 21:48:52', '2025-10-21 21:48:52');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (14, 'TEST_OUT_001', 'OUTBOUND', '2025-10-21 21:48:52', 'admin', 'P002', NULL, NULL, '测试多物料出仓', 'DRAFT', '2025-10-21 21:48:52', '2025-10-21 21:48:52');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (15, 'TEST_OUT_002', 'OUTBOUND', '2025-10-21 21:48:52', 'admin', 'P002', NULL, NULL, '测试多物料出仓', 'DRAFT', '2025-10-21 21:48:52', '2025-10-21 21:48:52');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (16, 'TEST_DUP_001', 'INBOUND', '2025-10-21 21:48:52', 'admin', 'P002', NULL, NULL, '测试多物料进仓', 'DRAFT', '2025-10-21 21:48:52', '2025-10-21 21:48:52');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (18, 'MOUT1761222994409', 'OUTBOUND', '2025-10-23 12:37:10', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-23 20:37:10', '2025-10-23 20:37:10');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (20, 'MOUT1761222994412', 'OUTBOUND', '2025-10-23 12:44:15', 'P001', 'P001', NULL, NULL, '', 'COMPLETED', '2025-10-23 20:37:58', '2025-10-23 20:44:14');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (21, 'MOUT1761224121186', 'OUTBOUND', '2025-10-23 12:55:35', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-23 20:55:35', '2025-10-23 20:55:35');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (23, 'MOUT1761224121188', 'OUTBOUND', '2025-10-23 12:56:05', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-23 20:56:05', '2025-10-23 20:56:05');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (24, 'MOUT1761242363810', 'OUTBOUND', '2025-10-23 17:59:34', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-24 01:59:34', '2025-10-24 01:59:34');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (25, 'MOUT1761265380305', 'OUTBOUND', '2025-10-24 00:23:11', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-24 08:23:11', '2025-10-24 08:23:11');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (31, 'MOUT1761281246829', 'OUTBOUND', '2025-10-24 04:48:01', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-24 12:48:00', '2025-10-24 12:48:00');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (33, 'MOUT1761315730293', 'OUTBOUND', '2025-10-24 14:22:45', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-24 22:22:45', '2025-10-24 22:22:45');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (34, 'MIN1761316089182', 'INBOUND', '2025-10-24 14:28:22', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-24 22:28:21', '2025-10-24 22:28:21');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (35, 'MIN1761316103938', 'INBOUND', '2025-10-24 14:28:55', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-24 22:28:55', '2025-10-24 22:28:55');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (40, 'MIN1761466007378', 'INBOUND', '2025-10-26 08:06:56', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 16:06:56', '2025-10-26 16:06:56');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (41, 'MIN1761466018039', 'INBOUND', '2025-10-26 08:07:59', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 16:07:59', '2025-10-26 16:07:59');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (42, 'MOUT1761466007382', 'OUTBOUND', '2025-10-26 08:08:22', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 16:08:22', '2025-10-26 16:08:22');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (43, 'MIN1761466113807', 'INBOUND', '2025-10-26 08:08:45', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 16:08:45', '2025-10-26 16:08:45');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (44, 'MOUT1761466113808', 'OUTBOUND', '2025-10-26 08:09:06', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 16:09:05', '2025-10-26 16:09:05');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (45, 'MIN1761466550946', 'INBOUND', '2025-10-26 08:16:10', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 16:16:09', '2025-10-26 16:16:09');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (46, 'MOUT1761466550949', 'OUTBOUND', '2025-10-26 08:16:45', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 16:16:44', '2025-10-26 16:16:44');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (47, 'MIN1761466649273', 'INBOUND', '2025-10-26 08:17:55', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 16:17:54', '2025-10-26 16:17:54');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (48, 'MIN1761466811928', 'INBOUND', '2025-10-26 08:20:33', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 16:20:32', '2025-10-26 16:20:32');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (49, 'MIN1761467375233', 'INBOUND', '2025-10-26 08:29:57', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 16:29:56', '2025-10-26 16:29:56');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (50, 'MOUT1761467375234', 'OUTBOUND', '2025-10-26 08:30:10', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 16:30:09', '2025-10-26 16:30:09');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (51, 'MIN1761468027331', 'INBOUND', '2025-10-26 08:40:38', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 16:40:38', '2025-10-26 16:40:38');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (52, 'MOUT1761468027333', 'OUTBOUND', '2025-10-26 08:41:25', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 16:41:24', '2025-10-26 16:41:24');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (53, 'MOUT1761468085713', 'OUTBOUND', '2025-10-26 08:41:41', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 16:41:40', '2025-10-26 16:41:40');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (54, 'MIN1761468538127', 'INBOUND', '2025-10-26 08:49:07', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 16:49:07', '2025-10-26 16:49:07');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (55, 'MOUT1761468538131', 'OUTBOUND', '2025-10-26 08:49:22', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 16:49:21', '2025-10-26 16:49:21');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (56, 'MIN1761479623023', 'INBOUND', '2025-10-26 11:53:55', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 19:53:55', '2025-10-26 19:53:55');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (57, 'MIN1761485748509', 'INBOUND', '2025-10-26 13:36:07', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 21:36:06', '2025-10-26 21:36:06');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (58, 'MIN1761485797274', 'INBOUND', '2025-10-26 13:36:48', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 21:36:47', '2025-10-26 21:36:47');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (59, 'MIN1761486789058', 'INBOUND', '2025-10-26 13:53:22', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 21:53:21', '2025-10-26 21:53:21');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (60, 'MIN1761486912487', 'INBOUND', '2025-10-26 13:55:28', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 21:55:28', '2025-10-26 21:55:28');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (61, 'MOUT1761486946179', 'OUTBOUND', '2025-10-26 13:55:58', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 21:55:58', '2025-10-26 21:55:58');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (62, 'MIN1761487050531', 'INBOUND', '2025-10-26 13:57:39', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 21:57:39', '2025-10-26 21:57:39');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (65, 'MIN1761489288212', 'INBOUND', '2025-10-26 14:34:58', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 22:34:58', '2025-10-26 22:34:58');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (66, 'MIN1761489516914', 'INBOUND', '2025-10-26 14:38:48', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 22:38:47', '2025-10-26 22:38:47');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (67, 'MIN1761489573707', 'INBOUND', '2025-10-26 14:39:42', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 22:39:42', '2025-10-26 22:39:42');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (68, 'MIN1761489876014', 'INBOUND', '2025-10-26 14:44:48', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 22:44:48', '2025-10-26 22:44:48');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (69, 'MIN1761490179973', 'INBOUND', '2025-10-26 14:49:53', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 22:49:53', '2025-10-26 22:49:53');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (70, 'MIN1761490242057', 'INBOUND', '2025-10-26 14:50:50', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 22:50:49', '2025-10-26 22:50:49');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (71, 'MIN1761491086443', 'INBOUND', '2025-10-26 15:04:56', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 23:04:55', '2025-10-26 23:04:55');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (72, 'MIN1761491186557', 'INBOUND', '2025-10-26 15:06:35', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 23:06:35', '2025-10-26 23:06:35');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (73, 'MOUT1761491186558', 'OUTBOUND', '2025-10-26 15:06:51', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-26 23:06:51', '2025-10-26 23:06:51');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (74, 'MIN1761578908914', 'INBOUND', '2025-10-27 15:28:46', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-27 23:28:45', '2025-10-27 23:28:45');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (75, 'MOUT1761578908922', 'OUTBOUND', '2025-10-27 15:29:10', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-27 23:29:10', '2025-10-27 23:29:10');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (76, 'MIN1761579050842', 'INBOUND', '2025-10-27 15:31:01', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-27 23:31:01', '2025-10-27 23:31:01');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (77, 'MOUT1761579050845', 'OUTBOUND', '2025-10-27 15:31:15', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-27 23:31:14', '2025-10-27 23:31:14');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (78, 'MIN1761580017746', 'INBOUND', '2025-10-27 15:47:10', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-27 23:47:10', '2025-10-27 23:47:10');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (79, 'MOUT1761580017750', 'OUTBOUND', '2025-10-27 15:47:24', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-27 23:47:24', '2025-10-27 23:47:24');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (80, 'MIN1761580124928', 'INBOUND', '2025-10-27 15:48:58', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-27 23:48:58', '2025-10-27 23:48:58');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (81, 'MOUT1761580124932', 'OUTBOUND', '2025-10-27 15:49:15', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-27 23:49:14', '2025-10-27 23:49:14');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (82, 'MIN1761581737704', 'INBOUND', '2025-10-27 16:16:05', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-28 00:16:04', '2025-10-28 00:16:04');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (83, 'MIN1761583202080', 'INBOUND', '2025-10-27 16:40:13', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-28 00:40:13', '2025-10-28 00:40:13');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (84, 'MOUT1761583202083', 'OUTBOUND', '2025-10-27 16:40:29', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-28 00:40:29', '2025-10-28 00:40:29');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (85, 'MIN1761584479208', 'INBOUND', '2025-10-27 17:01:46', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-28 01:01:45', '2025-10-28 01:01:45');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (86, 'MOUT1761584479212', 'OUTBOUND', '2025-10-27 17:02:09', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-28 01:02:08', '2025-10-28 01:02:08');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (87, 'MOUT1761619889503', 'OUTBOUND', '2025-10-28 02:51:52', 'P001', 'P001', NULL, NULL, '', 'DRAFT', '2025-10-28 10:51:52', '2025-10-28 10:51:52');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (88, 'MOUT1761620394630', 'OUTBOUND', '2025-10-28 03:00:09', 'P001', 'P001', NULL, NULL, '', 'COMPLETED', '2025-10-28 11:00:09', '2025-10-28 11:00:09');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (89, 'MIN1761620394626', 'INBOUND', '2025-10-28 03:00:33', 'P001', 'P001', NULL, NULL, '', 'COMPLETED', '2025-10-28 11:00:32', '2025-10-28 11:00:32');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (90, 'MIN1761621158123', 'INBOUND', '2025-10-28 03:12:50', 'P001', 'P001', NULL, NULL, '', 'COMPLETED', '2025-10-28 11:12:50', '2025-10-28 11:12:50');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (91, 'MIN1761621513629', 'INBOUND', '2025-10-28 03:18:46', 'P001', 'P001', NULL, NULL, '', 'COMPLETED', '2025-10-28 11:18:46', '2025-10-28 11:18:46');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (92, 'MOUT1761621513633', 'OUTBOUND', '2025-10-28 03:19:01', 'P001', 'P001', NULL, NULL, '', 'COMPLETED', '2025-10-28 11:19:01', '2025-10-28 11:19:01');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (93, 'MIN1761621527335', 'INBOUND', '2025-10-28 03:19:16', 'P001', 'P001', NULL, NULL, '', 'COMPLETED', '2025-10-28 11:19:15', '2025-10-28 11:19:15');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (94, 'MIN1761622037761', 'INBOUND', '2025-10-28 03:27:47', 'P001', 'P001', NULL, NULL, '', 'COMPLETED', '2025-10-28 11:27:47', '2025-10-28 11:27:47');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (95, 'MIN1761622068229', 'INBOUND', '2025-10-28 03:28:10', 'P001', 'P001', NULL, NULL, '', 'COMPLETED', '2025-10-28 11:28:10', '2025-10-28 11:28:10');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (96, 'MOUT1761622037764', 'OUTBOUND', '2025-10-28 03:28:32', 'P001', 'P001', NULL, NULL, '', 'COMPLETED', '2025-10-28 11:28:32', '2025-10-28 11:28:32');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (97, 'MIN1761622520802', 'INBOUND', '2025-10-28 03:35:39', 'P001', 'P001', NULL, NULL, '', 'COMPLETED', '2025-10-28 11:35:38', '2025-10-28 11:35:38');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (98, 'MIN1761622540057', 'INBOUND', '2025-10-28 03:36:28', 'P001', 'P001', NULL, NULL, '', 'COMPLETED', '2025-10-28 11:36:27', '2025-10-28 11:36:27');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (99, 'MOUT1761622520805', 'OUTBOUND', '2025-10-28 03:36:40', 'P001', 'P001', NULL, NULL, '', 'COMPLETED', '2025-10-28 11:36:40', '2025-10-28 11:36:40');
INSERT INTO `class2_seat27_multi_inout_record` VALUES (100, 'MIN1761623608711', 'INBOUND', '2025-10-28 03:53:48', 'P001', 'P001', NULL, NULL, '', 'COMPLETED', '2025-10-28 11:53:48', '2025-10-28 11:53:48');

-- ----------------------------
-- Table structure for class2_seat27_outbound
-- ----------------------------
DROP TABLE IF EXISTS `class2_seat27_outbound`;
CREATE TABLE `class2_seat27_outbound`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `outbound_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `outbound_date` datetime NOT NULL,
  `remark` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `status` enum('DRAFT','CONFIRMED','COMPLETED','CANCELLED') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'DRAFT',
  `created_by` bigint NOT NULL,
  `created_time` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `outbound_code`(`outbound_code`) USING BTREE,
  INDEX `created_by`(`created_by`) USING BTREE,
  CONSTRAINT `class2_seat27_outbound_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `class2_seat27_personnel` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of class2_seat27_outbound
-- ----------------------------
INSERT INTO `class2_seat27_outbound` VALUES (1, 'OUT20231103001', '2023-11-03 09:30:00', '生产领用螺丝', 'COMPLETED', 3, '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_outbound` VALUES (2, 'OUT20231108001', '2023-11-08 14:15:00', '生产领用螺母和垫片', 'COMPLETED', 3, '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_outbound` VALUES (3, 'OUT20231113001', '2023-11-13 10:45:00', '生产领用轴承和齿轮', 'COMPLETED', 3, '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_outbound` VALUES (4, 'OUT20231118001', '2023-11-18 16:20:00', '生产领用电机和皮带', 'COMPLETED', 3, '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_outbound` VALUES (5, 'OUT20231123001', '2023-11-23 11:05:00', '生产领用螺栓和电线', 'COMPLETED', 3, '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_outbound` VALUES (6, 'OUT20231128001', '2023-11-28 15:30:00', '生产领用开关', 'COMPLETED', 3, '2025-10-13 21:36:03', '2025-10-13 21:36:03');

-- ----------------------------
-- Table structure for class2_seat27_outbound_detail
-- ----------------------------
DROP TABLE IF EXISTS `class2_seat27_outbound_detail`;
CREATE TABLE `class2_seat27_outbound_detail`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `outbound_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `quantity` int NOT NULL,
  `unit_price` decimal(38, 2) NULL DEFAULT NULL,
  `total_price` decimal(38, 2) NULL DEFAULT NULL,
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `created_time` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `outbound_id`(`outbound_id`) USING BTREE,
  INDEX `material_id`(`material_id`) USING BTREE,
  INDEX `idx_outbound_detail_created_by`(`created_by`) USING BTREE,
  CONSTRAINT `class2_seat27_outbound_detail_ibfk_1` FOREIGN KEY (`outbound_id`) REFERENCES `class2_seat27_outbound` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `class2_seat27_outbound_detail_ibfk_2` FOREIGN KEY (`material_id`) REFERENCES `class2_seat27_material` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `class2_seat27_outbound_detail_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `class2_seat27_personnel` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
  CONSTRAINT `FKj69hvwc7rtf6lbmauymqnr6xt` FOREIGN KEY (`created_by`) REFERENCES `class2_seat27_personnel` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of class2_seat27_outbound_detail
-- ----------------------------
INSERT INTO `class2_seat27_outbound_detail` VALUES (11, 1, 1, 2000, 0.10, 200.00, '生产领用螺丝', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_outbound_detail` VALUES (12, 2, 2, 1500, 0.05, 75.00, '生产领用螺母', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_outbound_detail` VALUES (13, 2, 3, 1000, 0.02, 20.00, '生产领用垫片', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_outbound_detail` VALUES (15, 3, 5, 30, 50.00, 1500.00, '生产领用齿轮', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_outbound_detail` VALUES (16, 4, 6, 10, 30.00, 300.00, '生产领用皮带', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_outbound_detail` VALUES (17, 4, 7, 2, 500.00, 1000.00, '生产领用电机', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_outbound_detail` VALUES (18, 5, 8, 1000, 0.20, 200.00, '生产领用螺栓', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_outbound_detail` VALUES (19, 5, 9, 500, 2.00, 1000.00, '生产领用电线', '2025-10-13 21:36:03', NULL);
INSERT INTO `class2_seat27_outbound_detail` VALUES (20, 6, 10, 50, 10.00, 500.00, '生产领用开关', '2025-10-13 21:36:03', NULL);

-- ----------------------------
-- Table structure for class2_seat27_personnel
-- ----------------------------
DROP TABLE IF EXISTS `class2_seat27_personnel`;
CREATE TABLE `class2_seat27_personnel`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `personnel_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `gender` enum('男','女') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `birth_date` date NULL DEFAULT NULL,
  `id_card` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `native_place` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `other_info` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `user_role` enum('ADMIN','USER') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'USER',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `personnel_code`(`personnel_code`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of class2_seat27_personnel
-- ----------------------------
INSERT INTO `class2_seat27_personnel` VALUES (1, 'P001', '管理员', '男', '1990-01-01', '110101199001011234', '山东', 'sd', '11111111111', '', 'admin', 'e10adc3949ba59abbe56e057f20f883e', 'ADMIN', '2025-10-09 21:51:14', '2025-10-28 21:56:38');
INSERT INTO `class2_seat27_personnel` VALUES (2, 'P002', '测试用户', '女', '1995-05-15', '110101199505151234', NULL, NULL, NULL, NULL, 'user01', '123456', 'USER', '2025-10-09 21:51:14', '2025-10-09 21:51:14');
INSERT INTO `class2_seat27_personnel` VALUES (3, 'P003', '张三', '男', NULL, '110101199001011234', NULL, '北京市朝阳区', '13800138003', NULL, 'operator3', '123456', 'USER', '2025-10-13 21:24:46', '2025-10-13 21:24:46');
INSERT INTO `class2_seat27_personnel` VALUES (5, 'P005', '钱七', '女', NULL, '110101199310051234', NULL, '财务部办公区', '13800138005', NULL, 'qianqi', '123456', 'USER', '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_personnel` VALUES (6, 'P006', '张三', '男', NULL, '110101199001011234', NULL, '采购部办公区', '13800138001', NULL, 'zhangsan', '123456', 'ADMIN', '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_personnel` VALUES (7, 'P007', '李四', '女', NULL, '110101199505151234', NULL, '采购部办公区', '13800138002', NULL, 'lisi', '123456', 'USER', '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_personnel` VALUES (8, 'P008', '王五', '男', NULL, '110101198803151234', NULL, '仓库管理区', '13800138003', NULL, 'wangwu', '123456', 'USER', '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_personnel` VALUES (9, 'P009', '赵六', '男', NULL, '110101199207201234', NULL, '仓库管理区', '13800138004', NULL, 'zhaoliu', '123456', 'USER', '2025-10-13 21:36:03', '2025-10-13 21:36:03');
INSERT INTO `class2_seat27_personnel` VALUES (10, 'P004', '李四', '女', '1992-05-15', '220102199205155678', '吉林', '吉林省长春市', '13900139000', NULL, 'user02', 'user123', 'USER', '2025-10-13 00:38:05', '2025-10-13 00:38:05');

-- ----------------------------
-- Table structure for class2_seat27_warehouse_ledger
-- ----------------------------
DROP TABLE IF EXISTS `class2_seat27_warehouse_ledger`;
CREATE TABLE `class2_seat27_warehouse_ledger`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `ledger_date` date NOT NULL,
  `document_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `operation_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `material_id` bigint NOT NULL,
  `in_quantity` int NULL DEFAULT NULL,
  `in_amount` decimal(38, 2) NULL DEFAULT NULL,
  `out_quantity` int NULL DEFAULT NULL,
  `out_amount` decimal(38, 2) NULL DEFAULT NULL,
  `balance_quantity` int NOT NULL,
  `balance_amount` decimal(38, 2) NOT NULL,
  `created_time` date NULL DEFAULT NULL,
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_warehouse_ledger_date`(`ledger_date`) USING BTREE,
  INDEX `idx_warehouse_ledger_material_id`(`material_id`) USING BTREE,
  INDEX `idx_warehouse_ledger_document_code`(`document_code`) USING BTREE,
  CONSTRAINT `class2_seat27_warehouse_ledger_ibfk_1` FOREIGN KEY (`material_id`) REFERENCES `class2_seat27_material` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 139 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of class2_seat27_warehouse_ledger
-- ----------------------------
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (27, '2023-11-01', 'MIIN20231101001', '进仓', 1, 2000, 200.00, 0, 0.00, 2000, 200.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (28, '2023-11-03', 'MIOUT20231103001', '出仓', 1, 0, 0.00, 1000, 100.00, 1000, 100.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (29, '2023-11-20', 'MIIN20231120001', '进仓', 1, 1000, 100.00, 0, 0.00, 2000, 200.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (30, '2023-11-23', 'MIOUT20231123001', '出仓', 1, 0, 0.00, 500, 50.00, 1500, 150.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (31, '2023-11-01', 'MIIN20231101001', '进仓', 2, 1500, 75.00, 0, 0.00, 1500, 75.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (32, '2023-11-03', 'MIOUT20231103001', '出仓', 2, 0, 0.00, 800, 40.00, 700, 35.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (33, '2023-11-20', 'MIIN20231120001', '进仓', 2, 700, 35.00, 0, 0.00, 1400, 70.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (34, '2023-11-23', 'MIOUT20231123001', '出仓', 2, 0, 0.00, 400, 20.00, 1000, 50.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (35, '2023-11-01', 'MIIN20231101001', '进仓', 3, 1000, 20.00, 0, 0.00, 1000, 20.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (36, '2023-11-03', 'MIOUT20231103001', '出仓', 3, 0, 0.00, 500, 10.00, 500, 10.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (37, '2023-11-20', 'MIIN20231120001', '进仓', 3, 500, 10.00, 0, 0.00, 1000, 30.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (38, '2023-11-23', 'MIOUT20231123001', '出仓', 3, 0, 0.00, 250, 5.00, 750, 25.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (41, '2023-11-05', 'MIIN20231105001', '进仓', 5, 20, 1000.00, 0, 0.00, 20, 1000.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (42, '2023-11-08', 'MIOUT20231108001', '出仓', 5, 0, 0.00, 10, 500.00, 10, 500.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (43, '2023-11-10', 'MIIN20231110001', '进仓', 6, 10, 300.00, 0, 0.00, 10, 300.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (44, '2023-11-13', 'MIOUT20231113001', '出仓', 6, 0, 0.00, 5, 150.00, 5, 150.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (45, '2023-11-10', 'MIIN20231110001', '进仓', 7, 2, 1000.00, 0, 0.00, 2, 1000.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (46, '2023-11-13', 'MIOUT20231113001', '出仓', 7, 0, 0.00, 1, 500.00, 1, 500.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (47, '2023-11-15', 'MIIN20231115001', '进仓', 8, 1000, 200.00, 0, 0.00, 1000, 200.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (48, '2023-11-18', 'MIOUT20231118001', '出仓', 8, 0, 0.00, 500, 100.00, 500, 100.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (49, '2023-11-15', 'MIIN20231115001', '进仓', 9, 500, 1000.00, 0, 0.00, 500, 1000.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (50, '2023-11-18', 'MIOUT20231118001', '出仓', 9, 0, 0.00, 250, 500.00, 250, 500.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (51, '2023-11-25', 'MIIN20231125001', '进仓', 10, 100, 1000.00, 0, 0.00, 100, 1000.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (52, '2023-11-28', 'MIOUT20231128001', '出仓', 10, 0, 0.00, 50, 500.00, 50, 500.00, '2025-10-13', NULL);
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (53, '2025-10-21', 'TEST_IN_001', '进仓', 1, 100, 10.00, 0, 0.00, 10100, 1010.00, NULL, '测试进仓螺丝');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (54, '2025-10-21', 'TEST_IN_001', '进仓', 2, 50, 2.50, 0, 0.00, 8050, 402.50, NULL, '测试进仓螺母');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (55, '2025-10-21', 'TEST_OUT_001', '出仓', 1, 0, 0.00, 30, 3.00, 10070, 1007.00, NULL, '测试出仓螺丝');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (56, '2025-10-21', 'TEST_OUT_001', '出仓', 2, 0, 0.00, 20, 1.00, 8030, 401.50, NULL, '测试出仓螺母');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (57, '2025-10-21', 'TEST_OUT_002', '出仓', 1, 0, 0.00, 10000, 1000.00, 70, 7.00, NULL, '测试库存不足');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (58, '2025-10-21', 'TEST_DUP_001', '进仓', 1, 10, 1.00, 0, 0.00, 80, 8.00, NULL, '测试重复单号');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (59, '2025-10-23', 'MOUT1761222994409', '出仓', 5, 0, 0.00, 100, 4400.00, 0, 0.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (60, '2025-10-23', 'MOUT1761222994412', '出仓', 2, 0, 0.00, 10, 220.00, 8020, 176440.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (61, '2025-10-23', 'MOUT1761222994412', '出仓', 2, 0, 0.00, 10, 220.00, 8010, 176220.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (62, '2025-10-23', 'MOUT1761224121186', '出仓', 3, 0, 0.00, 555, 1665.00, 4445, 13335.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (63, '2025-10-23', 'MOUT1761224121188', '出仓', 8, 0, 0.00, 99, 2178.00, 4901, 107822.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (65, '2025-10-23', 'MOUT1761242363810', '出仓', 3, 0, 0.00, 55, 165.00, 4390, 13170.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (66, '2025-10-24', 'MOUT1761265380305', '出仓', 2, 0, 0.00, 7777, 171094.00, 233, 5126.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (67, '2025-10-24', 'MOUT1761281246829', '出仓', 7, 0, 0.00, 10, 5000.00, 0, 0.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (68, '2025-10-24', 'MOUT1761315730293', '出仓', 2, 0, 0.00, 10, 220.00, 223, 4906.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (69, '2025-10-24', 'MIN1761316089182', '进仓', 2, 8000, 176000.00, 0, 0.00, 8223, 180906.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (70, '2025-10-24', 'MIN1761316103938', '进仓', 2, 8000, 176000.00, 0, 0.00, 16223, 356906.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (71, '2025-10-26', 'MIN1761466007378', '进仓', 10, 300, 3000.00, 0, 0.00, 600, 6000.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (75, '2025-10-26', 'MOUT1761466113808', '出仓', 2, 0, 0.00, 100, 2200.00, 16123, 354706.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (83, '2025-10-26', 'MIN1761467375233', '进仓', 29, 125, 5500.00, 0, 0.00, 125, 5500.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (84, '2025-10-26', 'MOUT1761467375234', '出仓', 5, 0, 0.00, 100, 4400.00, 900, 39600.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (85, '2025-10-26', 'MIN1761468027331', '进仓', 35, 20, 880.00, 0, 0.00, 20, 880.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (87, '2025-10-26', 'MOUT1761468085713', '出仓', 7, 0, 0.00, 100, 50000.00, 900, 450000.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (88, '2025-10-26', 'MIN1761468538127', '进仓', 35, 40, 1760.00, 0, 0.00, 60, 2640.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (89, '2025-10-26', 'MOUT1761468538131', '出仓', 3, 0, 0.00, 200, 600.00, 800, 2400.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (90, '2025-10-26', 'MIN1761479623023', '进仓', 3, 20, 60.00, 0, 0.00, 820, 2460.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (91, '2025-10-26', 'MIN1761485748509', '进仓', 36, 55, 2695.00, 0, 0.00, 55, 2695.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (92, '2025-10-26', 'MIN1761485797274', '进仓', 36, 55, 2695.00, 0, 0.00, 110, 5390.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (93, '2025-10-26', 'MIN1761486789058', '进仓', 10, 99, 990.00, 0, 0.00, 1099, 10990.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (94, '2025-10-26', 'MIN1761486912487', '进仓', 1, 12, 396.00, 0, 0.00, 1012, 33396.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (95, '2025-10-26', 'MOUT1761486946179', '出仓', 7, 0, 0.00, 10, 5000.00, 890, 445000.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (96, '2025-10-26', 'MIN1761487050531', '进仓', 37, 50, 1495.00, 0, 0.00, 50, 1495.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (97, '2025-10-26', 'MIN1761489288212', '进仓', 38, 50, 750.00, 0, 0.00, 50, 750.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (98, '2025-10-26', 'MIN1761489516914', '进仓', 38, 150, 2250.00, 0, 0.00, 200, 3000.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (102, '2025-10-26', 'MIN1761490242057', '进仓', 41, 20, 400.00, 0, 0.00, 20, 400.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (103, '2025-10-26', 'ADJ-20251026230409', '库存调整', 41, 20, 0.00, 0, 0.00, 40, 0.00, NULL, '物料档案管理中调整库存数量');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (104, '2025-10-26', 'MIN1761491086443', '进仓', 42, 16, 704.00, 0, 0.00, 60, 2640.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (105, '2025-10-26', 'ADJ-20251026230616', '库存调整', 7, 10, 0.00, 0, 0.00, 900, 0.00, NULL, '物料档案管理中调整库存数量');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (106, '2025-10-26', 'MIN1761491186557', '进仓', 43, 10, 23990.00, 0, 0.00, 110, 263890.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (108, '2025-10-27', 'MIN1761578908914', '进仓', 1, 500, 16500.00, 0, 0.00, 1512, 49896.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (109, '2025-10-27', 'MOUT1761578908922', '出仓', 1, 0, 0.00, 10, 330.00, 1502, 49566.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (110, '2025-10-27', 'MIN1761579050842', '进仓', 44, 10, 150.00, 0, 0.00, 450, 6750.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (111, '2025-10-27', 'MOUT1761579050845', '出仓', 41, 0, 0.00, 10, 200.00, 30, 600.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (112, '2025-10-27', 'MIN1761580017746', '进仓', 3, 80, 240.00, 0, 0.00, 900, 2700.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (113, '2025-10-27', 'MOUT1761580017750', '出仓', 35, 0, 0.00, 10, 440.00, 50, 2200.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (114, '2025-10-27', 'MIN1761580124928', '进仓', 1, 18, 594.00, 0, 0.00, 1520, 50160.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (115, '2025-10-27', 'MOUT1761580124932', '出仓', 44, 0, 0.00, 15, 225.00, 435, 6525.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (116, '2025-10-27', 'MIN1761581737704', '进仓', 9, 1000, 88000.00, 0, 0.00, 2000, 176000.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (117, '2025-10-27', 'MIN1761583202080', '进仓', 1, 1000, 33000.00, 0, 0.00, 2520, 83160.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (118, '2025-10-27', 'MOUT1761583202083', '出仓', 44, 0, 0.00, 100, 1500.00, 335, 5025.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (119, '2025-10-27', 'MIN1761584479208', '进仓', 1, 500, 16500.00, 0, 0.00, 3020, 99660.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (120, '2025-10-27', 'MIN1761584479208', '进仓', 5, 100, 4400.00, 0, 0.00, 1000, 44000.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (121, '2025-10-27', 'MOUT1761584479212', '出仓', 3, 0, 0.00, 100, 300.00, 800, 2400.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (122, '2025-10-28', 'MOUT1761619889503', '出仓', 10, 0, 0.00, 99, 990.00, 1000, 10000.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (123, '2025-10-28', 'MOUT1761620394630', '出仓', 1, 0, 0.00, 1000, 33000.00, 2020, 66660.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (124, '2025-10-28', 'MIN1761620394626', '进仓', 7, 1000, 500000.00, 0, 0.00, 1900, 950000.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (125, '2025-10-28', 'MIN1761621158123', '进仓', 35, 100, 4400.00, 0, 0.00, 150, 6600.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (126, '2025-10-28', 'MIN1761621513629', '进仓', 45, 2000, 138000.00, 0, 0.00, 3500, 241500.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (127, '2025-10-28', 'MOUT1761621513633', '出仓', 9, 0, 0.00, 100, 8800.00, 1900, 167200.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (128, '2025-10-28', 'MIN1761621527335', '进仓', 43, 1900, 4558100.00, 0, 0.00, 2010, 4821990.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (129, '2025-10-28', 'MIN1761622037761', '进仓', 46, 150, 2250.00, 0, 0.00, 1655, 24825.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (130, '2025-10-28', 'MIN1761622037761', '进仓', 41, 1000, 20000.00, 0, 0.00, 1030, 20600.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (131, '2025-10-28', 'MIN1761622068229', '进仓', 37, 15, 448.50, 0, 0.00, 65, 1943.50, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (132, '2025-10-28', 'MOUT1761622037764', '出仓', 9, 0, 0.00, 100, 8800.00, 1800, 158400.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (133, '2025-10-28', 'MIN1761622520802', '进仓', 37, 100, 2990.00, 0, 0.00, 165, 4933.50, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (134, '2025-10-28', 'MIN1761622520802', '进仓', 37, 100, 2990.00, 0, 0.00, 265, 7923.50, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (135, '2025-10-28', 'MIN1761622540057', '进仓', 42, 300, 13200.00, 0, 0.00, 360, 15840.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (136, '2025-10-28', 'MOUT1761622520805', '出仓', 43, 0, 0.00, 100, 239900.00, 1910, 4582090.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (137, '2025-10-28', 'MIN1761623608711', '进仓', 6, 100, 3000.00, 0, 0.00, 1100, 33000.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (138, '2025-10-28', 'MIN1761623608711', '进仓', 45, 200, 13800.00, 0, 0.00, 3700, 255300.00, NULL, '');
INSERT INTO `class2_seat27_warehouse_ledger` VALUES (139, '2025-10-28', 'ADJ-20251028214323', '库存调整', 5, 1000, 0.00, 0, 0.00, 2000, 0.00, NULL, '物料档案管理中调整库存数量');

-- ----------------------------
-- View structure for class2_seat27_material_statistics_view
-- ----------------------------
DROP VIEW IF EXISTS `class2_seat27_material_statistics_view`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `class2_seat27_material_statistics_view` AS select `m`.`id` AS `material_id`,`m`.`material_code` AS `material_code`,`m`.`name` AS `material_name`,`m`.`specification` AS `specification`,`m`.`unit` AS `unit`,coalesce(sum((case when (`r`.`operation_type` = 'INBOUND') then `d`.`quantity` else 0 end)),0) AS `inbound_quantity`,coalesce(sum((case when (`r`.`operation_type` = 'INBOUND') then `d`.`total_price` else 0 end)),0) AS `inbound_amount`,coalesce(sum((case when (`r`.`operation_type` = 'OUTBOUND') then `d`.`quantity` else 0 end)),0) AS `outbound_quantity`,coalesce(sum((case when (`r`.`operation_type` = 'OUTBOUND') then `d`.`total_price` else 0 end)),0) AS `outbound_amount`,coalesce(sum((case when (`r`.`operation_type` = 'INBOUND') then `d`.`quantity` else -(`d`.`quantity`) end)),0) AS `net_flow`,coalesce(sum((case when (`r`.`operation_type` = 'INBOUND') then `d`.`total_price` else -(`d`.`total_price`) end)),0) AS `net_amount`,coalesce(`inv`.`quantity`,0) AS `current_quantity` from (((`class2_seat27_material` `m` left join `class2_seat27_multi_inout_detail` `d` on((`m`.`material_code` = `d`.`material_code`))) left join `class2_seat27_multi_inout_record` `r` on(((`d`.`multi_inout_record_id` = `r`.`id`) and (`r`.`status` = 'COMPLETED')))) left join (select `i1`.`material_id` AS `material_id`,`i1`.`quantity` AS `quantity` from (`class2_seat27_inventory` `i1` join (select `class2_seat27_inventory`.`material_id` AS `material_id`,max(`class2_seat27_inventory`.`id`) AS `max_id` from `class2_seat27_inventory` group by `class2_seat27_inventory`.`material_id`) `i2` on(((`i1`.`material_id` = `i2`.`material_id`) and (`i1`.`id` = `i2`.`max_id`))))) `inv` on((`m`.`id` = `inv`.`material_id`))) group by `m`.`id`,`m`.`material_code`,`m`.`name`,`m`.`specification`,`m`.`unit`,`inv`.`quantity`;

-- ----------------------------
-- View structure for view_multi_inout_details
-- ----------------------------
DROP VIEW IF EXISTS `view_multi_inout_details`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `view_multi_inout_details` AS select `r`.`id` AS `record_id`,`r`.`document_code` AS `document_code`,`r`.`operation_type` AS `operation_type`,`r`.`operation_date` AS `operation_date`,`r`.`operator_code` AS `operator_code`,`r`.`handler_code` AS `handler_code`,`r`.`remark` AS `remark`,`r`.`status` AS `status`,`r`.`created_time` AS `created_time`,`r`.`updated_time` AS `updated_time`,`d`.`id` AS `detail_id`,`d`.`material_code` AS `material_code`,`d`.`material_name` AS `material_name`,`d`.`specification` AS `specification`,`d`.`unit` AS `unit`,`d`.`quantity` AS `quantity`,`d`.`unit_price` AS `unit_price`,`d`.`total_price` AS `total_price`,`d`.`remark` AS `detail_remark` from (`class2_seat27_multi_inout_record` `r` join `class2_seat27_multi_inout_detail` `d` on((`r`.`id` = `d`.`multi_inout_record_id`))) order by `r`.`operation_date` desc,`r`.`document_code`,`d`.`id`;

-- ----------------------------
-- Procedure structure for class2_seat27_low_inventory_warning
-- ----------------------------
DROP PROCEDURE IF EXISTS `class2_seat27_low_inventory_warning`;
delimiter ;;
CREATE PROCEDURE `class2_seat27_low_inventory_warning`(IN p_start_date DATE,
    IN p_end_date DATE)
BEGIN
    -- 创建临时表存储低库存预警结果
    DROP TEMPORARY TABLE IF EXISTS temp_low_inventory;
    CREATE TEMPORARY TABLE temp_low_inventory (
        material_id BIGINT,
        material_code VARCHAR(50),
        material_name VARCHAR(100),
        specification VARCHAR(200),
        unit VARCHAR(20),
        current_quantity INT,
        min_stock INT,
        stock_status VARCHAR(20),
        warning_level VARCHAR(20)
    );

    -- 查询低库存物料
    INSERT INTO temp_low_inventory
    SELECT
        m.id,
        m.material_code,
        m.name,
        m.specification,
        m.unit,
        COALESCE(i.quantity, 0) AS current_quantity,
        m.min_stock,
        CASE
            WHEN COALESCE(i.quantity, 0) = 0 THEN '缺货'
            WHEN COALESCE(i.quantity, 0) < m.min_stock THEN '库存不足'
            ELSE '库存正常'
            END AS stock_status,
        CASE
            WHEN COALESCE(i.quantity, 0) = 0 THEN '紧急'
            WHEN COALESCE(i.quantity, 0) < m.min_stock * 0.5 THEN '高'
            WHEN COALESCE(i.quantity, 0) < m.min_stock THEN '中'
            ELSE '低'
            END AS warning_level
    FROM
        class2_seat27_material m
        LEFT JOIN (
            SELECT i1.material_id, i1.quantity
            FROM class2_seat27_inventory i1
            INNER JOIN (
                SELECT material_id, MAX(id) as max_id
                FROM class2_seat27_inventory
                GROUP BY material_id
            ) i2 ON i1.material_id = i2.material_id AND i1.id = i2.max_id
        ) i ON m.id = i.material_id
    WHERE
        COALESCE(i.quantity, 0) <= m.min_stock
        AND m.min_stock > 0
    ORDER BY
        stock_status, warning_level, current_quantity;

    -- 返回低库存预警数据
    SELECT * FROM temp_low_inventory;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for class2_seat27_material_flow_statistics
-- ----------------------------
DROP PROCEDURE IF EXISTS `class2_seat27_material_flow_statistics`;
delimiter ;;
CREATE PROCEDURE `class2_seat27_material_flow_statistics`(IN p_start_date DATE,
    IN p_end_date DATE)
BEGIN
    -- 查询指定时间范围内的进出仓数据
    SELECT
        m.id AS material_id,
        m.material_code,
        m.name AS material_name,
        m.specification,
        m.unit,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'INBOUND' THEN d.quantity
            ELSE 0
        END), 0) AS inbound_quantity,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'INBOUND' THEN d.total_price
            ELSE 0
        END), 0) AS inbound_amount,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'OUTBOUND' THEN d.quantity
            ELSE 0
        END), 0) AS outbound_quantity,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'OUTBOUND' THEN d.total_price
            ELSE 0
        END), 0) AS outbound_amount,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'INBOUND' THEN d.quantity
            ELSE -d.quantity
        END), 0) AS net_flow,
        COALESCE(SUM(CASE
            WHEN r.operation_type = 'INBOUND' THEN d.total_price
            ELSE -d.total_price
        END), 0) AS net_amount,
        COALESCE(inv.quantity, 0) AS current_quantity
    FROM
        class2_seat27_material m
    LEFT JOIN
        class2_seat27_multi_inout_detail d ON m.material_code = d.material_code
    LEFT JOIN
        class2_seat27_multi_inout_record r ON d.multi_inout_record_id = r.id
        AND (r.status = 'COMPLETED' OR r.status IS NULL OR r.status = 'DRAFT')
        AND (p_start_date IS NULL OR DATE(r.operation_date) >= p_start_date)
        AND (p_end_date IS NULL OR DATE(r.operation_date) <= p_end_date)
    LEFT JOIN (
        SELECT i1.material_id, i1.quantity
        FROM class2_seat27_inventory i1
        INNER JOIN (
            SELECT material_id, MAX(id) as max_id
            FROM class2_seat27_inventory
            GROUP BY material_id
        ) i2 ON i1.material_id = i2.material_id AND i1.id = i2.max_id
    ) inv ON m.id = inv.material_id
    GROUP BY
        m.id, m.material_code, m.name, m.specification, m.unit, inv.quantity
    ORDER BY
        m.material_code;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for class2_seat27_monthly_records
-- ----------------------------
DROP PROCEDURE IF EXISTS `class2_seat27_monthly_records`;
delimiter ;;
CREATE PROCEDURE `class2_seat27_monthly_records`(IN p_year INT,
    IN p_month INT)
BEGIN
    -- 查询指定年月的进出仓单数据
    SELECT
        r.id AS record_id,
        r.document_code,
        r.operation_type,
        r.operation_date,
        r.operator_code,
        COALESCE(p1.name, '') AS operator_name,
        r.handler_code,
        COALESCE(p2.name, '') AS handler_name,
        r.status,
        d.material_code,
        d.material_name,
        d.specification,
        d.unit,
        d.quantity,
        d.unit_price,
        d.total_price,
        d.remark AS material_remark
    FROM
        class2_seat27_multi_inout_record r
    JOIN
        class2_seat27_multi_inout_detail d ON r.id = d.multi_inout_record_id
    LEFT JOIN
        class2_seat27_personnel p1 ON r.operator_code = p1.username OR r.operator_code = p1.personnel_code
    LEFT JOIN
        class2_seat27_personnel p2 ON r.handler_code = p2.username OR r.handler_code = p2.personnel_code
    WHERE
        YEAR(r.operation_date) = p_year
        AND MONTH(r.operation_date) = p_month
    ORDER BY
        r.operation_date, r.document_code;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for class2_seat27_print_monthly_records
-- ----------------------------
DROP PROCEDURE IF EXISTS `class2_seat27_print_monthly_records`;
delimiter ;;
CREATE PROCEDURE `class2_seat27_print_monthly_records`(IN p_year INT,
    IN p_month INT,
    OUT p_result INT,
    OUT p_message VARCHAR(500))
BEGIN
    -- 创建临时表存储月度进出仓单
    DROP TEMPORARY TABLE IF EXISTS temp_monthly_records;
    CREATE TEMPORARY TABLE temp_monthly_records (
        record_type VARCHAR(10),  -- '进仓' 或 '出仓'
        record_code VARCHAR(50),  -- 单号
        record_date DATETIME,
        operator_code VARCHAR(50),
        handler_code VARCHAR(50),
        material_code VARCHAR(50),
        material_name VARCHAR(100),
        specification VARCHAR(200),
        unit VARCHAR(20),
        quantity DECIMAL(18,3),
        unit_price DECIMAL(18,2),
        total_price DECIMAL(18,2),
        remark VARCHAR(500),
        sort_order INT  -- 用于排序
    );

    -- 添加进仓记录
    INSERT INTO temp_monthly_records
    SELECT 
        '进仓' AS record_type,
        i.inbound_code AS record_code,
        i.inbound_date AS record_date,
        p.code AS operator_code,
        '' AS handler_code,  -- 进仓单可能没有经手人
        m.material_code,
        m.name AS material_name,
        m.specification,
        m.unit,
        COALESCE(id.quantity, 0) AS quantity,
        COALESCE(id.unit_price, 0) AS unit_price,
        COALESCE(id.total_price, 0) AS total_price,
        i.remark,
        1 AS sort_order
    FROM 
        class2_seat27_inbound i
        LEFT JOIN class2_seat27_inbound_detail id ON i.id = id.inbound_id
        LEFT JOIN class2_seat27_material m ON id.material_id = m.id
        LEFT JOIN class2_seat27_personnel p ON i.created_by = p.id
    WHERE 
        YEAR(i.inbound_date) = p_year AND MONTH(i.inbound_date) = p_month
    ORDER BY 
        i.inbound_date, i.inbound_code;

    -- 添加出仓记录
    INSERT INTO temp_monthly_records
    SELECT 
        '出仓' AS record_type,
        o.outbound_code AS record_code,
        o.outbound_date AS record_date,
        p.code AS operator_code,
        '' AS handler_code,  -- 出仓单可能没有经手人
        m.material_code,
        m.name AS material_name,
        m.specification,
        m.unit,
        COALESCE(od.quantity, 0) AS quantity,
        COALESCE(od.unit_price, 0) AS unit_price,
        COALESCE(od.total_price, 0) AS total_price,
        o.remark,
        2 AS sort_order
    FROM 
        class2_seat27_outbound o
        LEFT JOIN class2_seat27_outbound_detail od ON o.id = od.outbound_id
        LEFT JOIN class2_seat27_material m ON od.material_id = m.id
        LEFT JOIN class2_seat27_personnel p ON o.created_by = p.id
    WHERE 
        YEAR(o.outbound_date) = p_year AND MONTH(o.outbound_date) = p_month
    ORDER BY 
        o.outbound_date, o.outbound_code;

    -- 添加多物料进出仓记录
    INSERT INTO temp_monthly_records
    SELECT 
        CASE WHEN mir.operation_type = 'INBOUND' THEN '进仓' ELSE '出仓' END AS record_type,
        mir.document_code AS record_code,
        mir.operation_date AS record_date,
        mir.operator_code,
        mir.handler_code,
        mid.material_code,
        mid.material_name,
        mid.specification,
        mid.unit,
        mid.quantity,
        mid.unit_price,
        mid.total_price,
        mid.remark,
        CASE WHEN mir.operation_type = 'INBOUND' THEN 1 ELSE 2 END AS sort_order
    FROM 
        class2_seat27_multi_inout_record mir
        LEFT JOIN class2_seat27_multi_inout_detail mid ON mir.id = mid.multi_inout_record_id
    WHERE 
        YEAR(mir.operation_date) = p_year AND MONTH(mir.operation_date) = p_month
    ORDER BY 
        mir.operation_date, mir.document_code;

    -- 按日期和单号排序
    SELECT * FROM temp_monthly_records ORDER BY record_date, record_code, sort_order;

    SET p_result = 1;
    SET p_message = CONCAT('已生成', p_year, '年', p_month, '月的进出仓单');
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for class2_seat27_print_warehouse_ledger
-- ----------------------------
DROP PROCEDURE IF EXISTS `class2_seat27_print_warehouse_ledger`;
delimiter ;;
CREATE PROCEDURE `class2_seat27_print_warehouse_ledger`(IN p_year INT,
    IN p_material_code VARCHAR(50),
    OUT p_result INT,
    OUT p_message VARCHAR(500))
BEGIN
    -- 获取物料基本信息
    SELECT name, specification, unit INTO @material_name, @material_specification, @material_unit 
    FROM class2_seat27_material WHERE material_code = p_material_code;

    -- 直接从仓库账本表查询数据
    SELECT 
        ledger_date,
        document_code,
        operation_type,
        p_material_code AS material_code,
        @material_name AS material_name,
        @material_specification AS specification,
        @material_unit AS unit,
        in_quantity,
        in_amount,
        out_quantity,
        out_amount,
        balance_quantity,
        balance_amount
    FROM 
        class2_seat27_warehouse_ledger
    WHERE 
        material_id = (SELECT id FROM class2_seat27_material WHERE material_code = p_material_code)
        AND YEAR(ledger_date) = p_year
    ORDER BY 
        ledger_date;

    -- 获取当前库存信息
    SELECT 
        quantity,
        last_inbound_time,
        last_outbound_time
    FROM 
        class2_seat27_inventory
    WHERE 
        material_id = (SELECT id FROM class2_seat27_material WHERE material_code = p_material_code);

    SET p_result = 1;
    SET p_message = CONCAT('已生成', p_material_code, '在', p_year, '年的仓库账本');
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for class2_seat27_warehouse_ledger
-- ----------------------------
DROP PROCEDURE IF EXISTS `class2_seat27_warehouse_ledger`;
delimiter ;;
CREATE PROCEDURE `class2_seat27_warehouse_ledger`(IN p_year INT,
    IN p_material_code VARCHAR(255))
BEGIN
    -- 查询仓库账本数据
    SELECT
        wl.ledger_date,
        wl.document_code,
        wl.operation_type,
        wl.material_id,
        COALESCE(m.material_code, '') AS material_code,
        COALESCE(m.name, '') AS material_name,
        COALESCE(m.specification, '') AS specification,
        COALESCE(m.unit, '') AS unit,
        COALESCE(wl.in_quantity, 0) AS inbound_quantity,
        COALESCE(wl.in_amount, 0) AS inbound_amount,
        COALESCE(wl.out_quantity, 0) AS outbound_quantity,
        COALESCE(wl.out_amount, 0) AS outbound_amount,
        COALESCE(wl.balance_quantity, 0) AS balance_quantity,
        COALESCE(wl.balance_amount, 0) AS balance_amount,
        COALESCE(wl.remark, '') AS remark
    FROM
        class2_seat27_warehouse_ledger wl
    LEFT JOIN
        class2_seat27_material m ON wl.material_id = m.id
    WHERE
        YEAR(wl.ledger_date) = p_year
        AND (p_material_code IS NULL OR p_material_code = '' OR m.material_code = p_material_code)
    ORDER BY
        wl.ledger_date, wl.document_code;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for class2_seat27_创建多物料出仓记录
-- ----------------------------
DROP PROCEDURE IF EXISTS `class2_seat27_创建多物料出仓记录`;
delimiter ;;
CREATE PROCEDURE `class2_seat27_创建多物料出仓记录`(IN p_document_code VARCHAR(50),
    IN p_operator_code VARCHAR(50),
    IN p_handler_code VARCHAR(50),
    IN p_remark VARCHAR(500),
    IN p_materials JSON,
    OUT p_result INT,
    OUT p_message VARCHAR(500))
BEGIN
    -- 直接调用现有的多物料出仓存储过程
    CALL class2_seat27_多物料出仓(
        p_document_code,
        NOW(),
        p_operator_code,
        p_handler_code,
        p_remark,
        p_materials,
        p_result,
        p_message
    );

    -- 如果成功，更新记录状态为COMPLETED
    IF p_result = 1 THEN
        UPDATE class2_seat27_multi_inout_record
        SET status = 'COMPLETED'
        WHERE document_code = p_document_code AND operation_type = 'OUTBOUND';
    END IF;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for class2_seat27_创建多物料进仓记录
-- ----------------------------
DROP PROCEDURE IF EXISTS `class2_seat27_创建多物料进仓记录`;
delimiter ;;
CREATE PROCEDURE `class2_seat27_创建多物料进仓记录`(IN p_document_code VARCHAR(50),
    IN p_operator_code VARCHAR(50),
    IN p_handler_code VARCHAR(50),
    IN p_remark VARCHAR(500),
    IN p_materials JSON,
    OUT p_result INT,
    OUT p_message VARCHAR(500))
BEGIN
    -- 直接调用现有的多物料进仓存储过程
    CALL class2_seat27_多物料进仓(
        p_document_code,
        NOW(),
        p_operator_code,
        p_handler_code,
        p_remark,
        p_materials,
        p_result,
        p_message
    );

    -- 如果成功，更新记录状态为COMPLETED
    IF p_result = 1 THEN
        UPDATE class2_seat27_multi_inout_record
        SET status = 'COMPLETED'
        WHERE document_code = p_document_code AND operation_type = 'INBOUND';
    END IF;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for class2_seat27_多物料出仓
-- ----------------------------
DROP PROCEDURE IF EXISTS `class2_seat27_多物料出仓`;
delimiter ;;
CREATE PROCEDURE `class2_seat27_多物料出仓`(IN p_document_code VARCHAR(50),
    IN p_operation_date DATETIME,
    IN p_operator_code VARCHAR(50),
    IN p_handler_code VARCHAR(50),
    IN p_remark VARCHAR(500),
    IN p_materials JSON,
    OUT p_result INT,
    OUT p_message VARCHAR(500))
BEGIN
    DECLARE v_operator_id BIGINT;
    DECLARE v_material_count INT;
    DECLARE v_material_id BIGINT;
    DECLARE v_quantity INT;
    DECLARE v_unit_price DECIMAL(38,2);
    DECLARE v_total_price DECIMAL(38,2);
    DECLARE v_material_remark VARCHAR(500);
    DECLARE v_inventory_id BIGINT;
    DECLARE v_current_quantity INT;
    DECLARE v_new_quantity INT;
    DECLARE v_material_name VARCHAR(255);
    DECLARE v_material_code VARCHAR(255);
    DECLARE v_material_spec VARCHAR(200);
    DECLARE v_material_unit VARCHAR(20);
    DECLARE v_i INT DEFAULT 0;
    DECLARE v_same_document_exists INT DEFAULT 0;
    DECLARE v_operation_type VARCHAR(20);
    DECLARE v_error_occurred BOOLEAN DEFAULT FALSE;
    DECLARE v_record_id BIGINT;

    -- 异常处理，确保失败时回滚
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
            GET DIAGNOSTICS CONDITION 1
                p_message = MESSAGE_TEXT;
            SET p_result = 0;
            SET v_error_occurred = TRUE;
        END;

    -- 开始事务
    START TRANSACTION;

    -- 检查是否存在相同的单号
    SELECT COUNT(*) INTO v_same_document_exists
    FROM class2_seat27_multi_inout_record
    WHERE document_code = p_document_code;

    IF v_same_document_exists > 0 THEN
        -- 检查该单号是否已有进仓记录，确保同一单号不能同时有进仓和出仓
        SELECT operation_type INTO v_operation_type
        FROM class2_seat27_multi_inout_record
        WHERE document_code = p_document_code
        LIMIT 1;

        IF v_operation_type = 'INBOUND' THEN
            SET p_result = 0;
            SET p_message = CONCAT('单号 ', p_document_code, ' 已存在进仓记录，不能同时进行出仓操作');
            ROLLBACK;
            SET v_error_occurred = TRUE;
        END IF;
    END IF;

    -- 如果之前有错误，直接返回
    IF v_error_occurred THEN
        SET p_result = 0;
    ELSE
        -- 获取操作员ID
        SELECT id INTO v_operator_id
        FROM class2_seat27_personnel
        WHERE username = p_operator_code OR personnel_code = p_operator_code;

        IF v_operator_id IS NULL THEN
            SET p_result = 0;
            SET p_message = '操作员不存在';
            ROLLBACK;
            SET v_error_occurred = TRUE;
        ELSE
            -- 创建多物料进出仓记录，直接设置为COMPLETED状态
            INSERT INTO class2_seat27_multi_inout_record(
                document_code,
                operation_type,
                operation_date,
                operator_code,
                handler_code,
                remark,
                status
            ) VALUES (
                         p_document_code,
                         'OUTBOUND',
                         p_operation_date,
                         p_operator_code,
                         p_handler_code,
                         p_remark,
                         'COMPLETED'  -- 直接设置为COMPLETED状态
                     );

            -- 获取记录ID
            SET v_record_id = LAST_INSERT_ID();

            -- 获取物料数量
            SET v_material_count = JSON_LENGTH(p_materials);

            -- 遍历物料
            WHILE v_i < v_material_count AND v_error_occurred = FALSE DO
                -- 获取物料信息
                SET v_material_id = JSON_UNQUOTE(JSON_EXTRACT(p_materials, CONCAT('$[', v_i, '].materialId')));
                SET v_quantity = CAST(JSON_UNQUOTE(JSON_EXTRACT(p_materials, CONCAT('$[', v_i, '].quantity'))) AS UNSIGNED);
                SET v_unit_price = CAST(JSON_UNQUOTE(JSON_EXTRACT(p_materials, CONCAT('$[', v_i, '].unitPrice'))) AS DECIMAL(38,2));
                SET v_total_price = CAST(JSON_UNQUOTE(JSON_EXTRACT(p_materials, CONCAT('$[', v_i, '].totalPrice'))) AS DECIMAL(38,2));
                SET v_material_remark = JSON_UNQUOTE(JSON_EXTRACT(p_materials, CONCAT('$[', v_i, '].remark')));

                -- 检查物料是否存在
                SET v_material_name = NULL;
                SELECT name, material_code, specification, unit INTO v_material_name, v_material_code, v_material_spec, v_material_unit
                FROM class2_seat27_material WHERE id = v_material_id;

                IF v_material_name IS NULL THEN
                    SET p_result = 0;
                    SET p_message = CONCAT('物料ID ', v_material_id, ' 不存在');
                    ROLLBACK;
                    SET v_error_occurred = TRUE;
                ELSE
                    -- 获取当前库存
                    SET v_inventory_id = NULL;
                    SET v_current_quantity = NULL;
                    SELECT id, quantity INTO v_inventory_id, v_current_quantity
                    FROM class2_seat27_inventory
                    WHERE material_id = v_material_id;

                    -- 检查库存是否足够
                    IF v_inventory_id IS NULL OR v_current_quantity IS NULL OR v_current_quantity < v_quantity THEN
                        SET p_result = 0;
                        SET p_message = CONCAT('物料 ', v_material_name, '(', v_material_code, ') 库存不足，当前库存: ', IFNULL(v_current_quantity, 0), '，需要: ', v_quantity);
                        ROLLBACK;
                        SET v_error_occurred = TRUE;
                    ELSE
                        -- 创建多物料进出仓明细
                        INSERT INTO class2_seat27_multi_inout_detail(
                            multi_inout_record_id,
                            material_code,
                            material_name,
                            specification,
                            unit,
                            quantity,
                            unit_price,
                            total_price,
                            remark
                        ) VALUES (
                                     v_record_id,
                                     v_material_code,
                                     v_material_name,
                                     v_material_spec,
                                     v_material_unit,
                                     v_quantity,
                                     v_unit_price,
                                     v_total_price,
                                     v_material_remark
                                 );

                        -- 更新库存
                        SET v_new_quantity = v_current_quantity - v_quantity;

                        UPDATE class2_seat27_inventory
                        SET quantity = v_new_quantity,
                            last_outbound_time = NOW(),
                            updated_by = v_operator_id,
                            updated_time = NOW()
                        WHERE id = v_inventory_id;

                        -- 同时更新物料表中的库存数量
                        UPDATE class2_seat27_material
                        SET quantity = v_new_quantity,
                            updated_time = NOW()
                        WHERE id = v_material_id;

                        -- 记录仓库账本
                        INSERT INTO class2_seat27_warehouse_ledger(
                            ledger_date,
                            document_code,
                            operation_type,
                            material_id,
                            in_quantity,
                            in_amount,
                            out_quantity,
                            out_amount,
                            balance_quantity,
                            balance_amount,
                            remark
                        ) VALUES (
                                     DATE(p_operation_date),
                                     p_document_code,
                                     '出仓',
                                     v_material_id,
                                     0,
                                     0,
                                     v_quantity,
                                     v_total_price,
                                     v_new_quantity,
                                     v_new_quantity * v_unit_price,
                                     v_material_remark
                                 );
                    END IF;
                END IF;

                SET v_i = v_i + 1;
            END WHILE;

            -- 如果没有错误，提交事务
            IF v_error_occurred = FALSE THEN
                COMMIT;
                SET p_result = 1;
                SET p_message = CONCAT('多物料出仓成功，单号: ', p_document_code);
            ELSE
                ROLLBACK;
                SET p_result = 0;
                SET p_message = '多物料出仓失败';
            END IF;
        END IF;
    END IF;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for class2_seat27_多物料进仓
-- ----------------------------
DROP PROCEDURE IF EXISTS `class2_seat27_多物料进仓`;
delimiter ;;
CREATE PROCEDURE `class2_seat27_多物料进仓`(IN p_document_code VARCHAR(50),
    IN p_operation_date DATETIME,
    IN p_operator_code VARCHAR(50),
    IN p_handler_code VARCHAR(50),
    IN p_remark VARCHAR(500),
    IN p_materials JSON,
    OUT p_result INT,
    OUT p_message VARCHAR(500))
BEGIN
    DECLARE v_operator_id BIGINT;
    DECLARE v_material_count INT;
    DECLARE v_material_id BIGINT;
    DECLARE v_quantity INT;
    DECLARE v_unit_price DECIMAL(38,2);
    DECLARE v_total_price DECIMAL(38,2);
    DECLARE v_material_remark VARCHAR(500);
    DECLARE v_inventory_id BIGINT;
    DECLARE v_current_quantity INT;
    DECLARE v_new_quantity INT;
    DECLARE v_material_name VARCHAR(255);
    DECLARE v_material_code VARCHAR(255);
    DECLARE v_material_spec VARCHAR(200);
    DECLARE v_material_unit VARCHAR(20);
    DECLARE v_i INT DEFAULT 0;
    DECLARE v_same_document_exists INT DEFAULT 0;
    DECLARE v_operation_type VARCHAR(20);
    DECLARE v_error_occurred BOOLEAN DEFAULT FALSE;
    DECLARE v_record_id BIGINT;

    -- 异常处理，确保失败时回滚
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
            GET DIAGNOSTICS CONDITION 1
                p_message = MESSAGE_TEXT;
            SET p_result = 0;
            SET v_error_occurred = TRUE;
        END;

    -- 开始事务
    START TRANSACTION;

    -- 检查是否存在相同的单号
    SELECT COUNT(*) INTO v_same_document_exists
    FROM class2_seat27_multi_inout_record
    WHERE document_code = p_document_code;

    IF v_same_document_exists > 0 THEN
        -- 检查该单号是否已有出仓记录，确保同一单号不能同时有进仓和出仓
        SELECT operation_type INTO v_operation_type
        FROM class2_seat27_multi_inout_record
        WHERE document_code = p_document_code
        LIMIT 1;

        IF v_operation_type = 'OUTBOUND' THEN
            SET p_result = 0;
            SET p_message = CONCAT('单号 ', p_document_code, ' 已存在出仓记录，不能同时进行进仓操作');
            ROLLBACK;
            SET v_error_occurred = TRUE;
        END IF;
    END IF;

    -- 如果之前有错误，直接返回
    IF v_error_occurred THEN
        SET p_result = 0;
    ELSE
        -- 获取操作员ID
        SELECT id INTO v_operator_id
        FROM class2_seat27_personnel
        WHERE username = p_operator_code OR personnel_code = p_operator_code;

        IF v_operator_id IS NULL THEN
            SET p_result = 0;
            SET p_message = '操作员不存在';
            ROLLBACK;
            SET v_error_occurred = TRUE;
        ELSE
            -- 创建多物料进出仓记录，直接设置为COMPLETED状态
            INSERT INTO class2_seat27_multi_inout_record(
                document_code,
                operation_type,
                operation_date,
                operator_code,
                handler_code,
                remark,
                status
            ) VALUES (
                         p_document_code,
                         'INBOUND',
                         p_operation_date,
                         p_operator_code,
                         p_handler_code,
                         p_remark,
                         'COMPLETED'  -- 直接设置为COMPLETED状态
                     );

            -- 获取记录ID
            SET v_record_id = LAST_INSERT_ID();

            -- 获取物料数量
            SET v_material_count = JSON_LENGTH(p_materials);

            -- 遍历物料
            WHILE v_i < v_material_count AND v_error_occurred = FALSE DO
                -- 获取物料信息
                SET v_material_id = JSON_UNQUOTE(JSON_EXTRACT(p_materials, CONCAT('$[', v_i, '].materialId')));
                SET v_quantity = CAST(JSON_UNQUOTE(JSON_EXTRACT(p_materials, CONCAT('$[', v_i, '].quantity'))) AS UNSIGNED);
                SET v_unit_price = CAST(JSON_UNQUOTE(JSON_EXTRACT(p_materials, CONCAT('$[', v_i, '].unitPrice'))) AS DECIMAL(38,2));
                SET v_total_price = CAST(JSON_UNQUOTE(JSON_EXTRACT(p_materials, CONCAT('$[', v_i, '].totalPrice'))) AS DECIMAL(38,2));
                SET v_material_remark = JSON_UNQUOTE(JSON_EXTRACT(p_materials, CONCAT('$[', v_i, '].remark')));

                -- 检查物料是否存在
                SET v_material_name = NULL;
                SELECT name, material_code, specification, unit INTO v_material_name, v_material_code, v_material_spec, v_material_unit
                FROM class2_seat27_material WHERE id = v_material_id;

                IF v_material_name IS NULL THEN
                    SET p_result = 0;
                    SET p_message = CONCAT('物料ID ', v_material_id, ' 不存在');
                    ROLLBACK;
                    SET v_error_occurred = TRUE;
                ELSE
                    -- 创建多物料进出仓明细
                    INSERT INTO class2_seat27_multi_inout_detail(
                        multi_inout_record_id,
                        material_code,
                        material_name,
                        specification,
                        unit,
                        quantity,
                        unit_price,
                        total_price,
                        remark
                    ) VALUES (
                                 v_record_id,
                                 v_material_code,
                                 v_material_name,
                                 v_material_spec,
                                 v_material_unit,
                                 v_quantity,
                                 v_unit_price,
                                 v_total_price,
                                 v_material_remark
                             );

                    -- 获取当前库存
                    SET v_inventory_id = NULL;
                    SET v_current_quantity = NULL;
                    SELECT id, quantity INTO v_inventory_id, v_current_quantity
                    FROM class2_seat27_inventory
                    WHERE material_id = v_material_id;

                    -- 更新库存
                    SET v_new_quantity = IFNULL(v_current_quantity, 0) + v_quantity;

                    IF v_inventory_id IS NULL THEN
                        -- 插入新库存记录
                        INSERT INTO class2_seat27_inventory(
                            material_id,
                            quantity,
                            last_inbound_time,
                            created_by,
                            updated_by
                        ) VALUES (
                                     v_material_id,
                                     v_new_quantity,
                                     NOW(),
                                     v_operator_id,
                                     v_operator_id
                                 );
                    ELSE
                        -- 更新现有库存记录
                        UPDATE class2_seat27_inventory
                        SET quantity = v_new_quantity,
                            last_inbound_time = NOW(),
                            updated_by = v_operator_id,
                            updated_time = NOW()
                        WHERE id = v_inventory_id;
                    END IF;

                    -- 同时更新物料表中的库存数量
                    UPDATE class2_seat27_material
                    SET quantity = v_new_quantity,
                        updated_time = NOW()
                    WHERE id = v_material_id;

                    -- 记录仓库账本
                    INSERT INTO class2_seat27_warehouse_ledger(
                        ledger_date,
                        document_code,
                        operation_type,
                        material_id,
                        in_quantity,
                        in_amount,
                        out_quantity,
                        out_amount,
                        balance_quantity,
                        balance_amount,
                        remark
                    ) VALUES (
                                 DATE(p_operation_date),
                                 p_document_code,
                                 '进仓',
                                 v_material_id,
                                 v_quantity,
                                 v_total_price,
                                 0,
                                 0,
                                 v_new_quantity,
                                 v_new_quantity * v_unit_price,
                                 v_material_remark
                             );
                END IF;

                SET v_i = v_i + 1;
            END WHILE;

            -- 如果没有错误，提交事务
            IF v_error_occurred = FALSE THEN
                COMMIT;
                SET p_result = 1;
                SET p_message = CONCAT('多物料进仓成功，单号: ', p_document_code);
            ELSE
                ROLLBACK;
                SET p_result = 0;
                SET p_message = '多物料进仓失败';
            END IF;
        END IF;
    END IF;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for class2_seat27_完成多物料出仓
-- ----------------------------
DROP PROCEDURE IF EXISTS `class2_seat27_完成多物料出仓`;
delimiter ;;
CREATE PROCEDURE `class2_seat27_完成多物料出仓`(IN p_document_code VARCHAR(50),
    IN p_operator_code VARCHAR(50),
    IN p_handler_code VARCHAR(50),
    IN p_remark VARCHAR(500),
    IN p_materials JSON,
    OUT p_result INT,
    OUT p_message VARCHAR(500))
BEGIN
    -- 由于多物料出仓已经完成，这里直接返回成功
    SET p_result = 1;
    SET p_message = CONCAT('多物料出仓已完成，单号: ', p_document_code);
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for class2_seat27_完成多物料进仓
-- ----------------------------
DROP PROCEDURE IF EXISTS `class2_seat27_完成多物料进仓`;
delimiter ;;
CREATE PROCEDURE `class2_seat27_完成多物料进仓`(IN p_document_code VARCHAR(50),
    IN p_operator_code VARCHAR(50),
    IN p_handler_code VARCHAR(50),
    IN p_remark VARCHAR(500),
    IN p_materials JSON,
    OUT p_result INT,
    OUT p_message VARCHAR(500))
BEGIN
    -- 由于多物料进仓已经完成，这里直接返回成功
    SET p_result = 1;
    SET p_message = CONCAT('多物料进仓已完成，单号: ', p_document_code);
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for class2_seat27_进出仓单查询
-- ----------------------------
DROP PROCEDURE IF EXISTS `class2_seat27_进出仓单查询`;
delimiter ;;
CREATE PROCEDURE `class2_seat27_进出仓单查询`(IN p_start_date DATE,
    IN p_end_date DATE,
    IN p_material_code VARCHAR(50),
    IN p_operator_code VARCHAR(50),
    IN p_operation_type VARCHAR(20),
    IN p_remark_keyword VARCHAR(100),
    OUT p_result INT,
    OUT p_message VARCHAR(500))
BEGIN
    -- 创建临时表存储查询结果
    DROP TEMPORARY TABLE IF EXISTS temp_inout_records;
    CREATE TEMPORARY TABLE temp_inout_records (
        id BIGINT,
        document_code VARCHAR(255),
        operation_type VARCHAR(255),
        operation_date DATETIME,
        operator_code VARCHAR(255),
        handler_code VARCHAR(255),
        remark VARCHAR(255),
        status VARCHAR(20),
        created_time DATETIME,
        updated_time DATETIME
    );

    -- 插入查询结果
    INSERT INTO temp_inout_records
    SELECT 
        r.id,
        r.document_code,
        r.operation_type,
        r.operation_date,
        r.operator_code,
        r.handler_code,
        r.remark,
        r.status,
        r.created_time,
        r.updated_time
    FROM 
        class2_seat27_multi_inout_record r
    WHERE 
        (p_start_date IS NULL OR DATE(r.operation_date) >= p_start_date)
        AND (p_end_date IS NULL OR DATE(r.operation_date) <= p_end_date)
        AND (p_material_code IS NULL OR EXISTS (
            SELECT 1 FROM class2_seat27_multi_inout_detail d 
            WHERE d.multi_inout_record_id = r.id AND d.material_code = p_material_code
        ))
        AND (p_operator_code IS NULL OR r.operator_code = p_operator_code)
        AND (p_operation_type IS NULL OR r.operation_type = p_operation_type)
        AND (p_remark_keyword IS NULL OR r.remark LIKE CONCAT('%', p_remark_keyword, '%'))
    ORDER BY 
        r.operation_date DESC, r.document_code;

    -- 设置返回结果
    SET p_result = 1;
    SET p_message = '查询成功';
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for update_material_quantity
-- ----------------------------
DROP PROCEDURE IF EXISTS `update_material_quantity`;
delimiter ;;
CREATE PROCEDURE `update_material_quantity`(IN p_material_id BIGINT,
    IN p_new_quantity INT,
    OUT p_result INT,
    OUT p_message VARCHAR(500))
BEGIN
    DECLARE v_inventory_id BIGINT;
    DECLARE v_current_quantity INT;

    -- 开始事务
    START TRANSACTION;

    -- 检查物料是否存在
    IF NOT EXISTS (SELECT 1 FROM class2_seat27_material WHERE id = p_material_id) THEN
        SET p_result = 0;
        SET p_message = '物料不存在';
        ROLLBACK;
    ELSE
        -- 检查库存记录是否存在
        SELECT id, quantity INTO v_inventory_id, v_current_quantity 
        FROM class2_seat27_inventory 
        WHERE material_id = p_material_id;

        IF v_inventory_id IS NULL THEN
            -- 创建新的库存记录
            INSERT INTO class2_seat27_inventory(
                material_id,
                quantity,
                created_time,
                updated_time
            ) VALUES (
                p_material_id,
                p_new_quantity,
                NOW(),
                NOW()
            );
        ELSE
            -- 更新现有库存记录
            UPDATE class2_seat27_inventory 
            SET quantity = p_new_quantity,
                updated_time = NOW()
            WHERE id = v_inventory_id;
        END IF;

        -- 更新物料表中的数量
        UPDATE class2_seat27_material
        SET quantity = p_new_quantity,
            updated_time = NOW()
        WHERE id = p_material_id;

        -- 记录库存调整日志
        INSERT INTO class2_seat27_warehouse_ledger(
            ledger_date,
            document_code,
            operation_type,
            material_id,
            in_quantity,
            in_amount,
            out_quantity,
            out_amount,
            balance_quantity,
            balance_amount,
            remark
        ) VALUES (
            CURDATE(),
            CONCAT('ADJ-', DATE_FORMAT(NOW(), '%Y%m%d%H%i%s')),
            '库存调整',
            p_material_id,
            CASE WHEN p_new_quantity > IFNULL(v_current_quantity, 0) THEN p_new_quantity - IFNULL(v_current_quantity, 0) ELSE 0 END,
            0,
            CASE WHEN p_new_quantity < IFNULL(v_current_quantity, 0) THEN IFNULL(v_current_quantity, 0) - p_new_quantity ELSE 0 END,
            0,
            p_new_quantity,
            0,
            '物料档案管理中调整库存数量'
        );

        COMMIT;
        SET p_result = 1;
        SET p_message = '物料数量更新成功';
    END IF;
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table class2_seat27_inventory
-- ----------------------------
DROP TRIGGER IF EXISTS `tr_inventory_update_after`;
delimiter ;;
CREATE TRIGGER `tr_inventory_update_after` AFTER UPDATE ON `class2_seat27_inventory` FOR EACH ROW BEGIN
    UPDATE class2_seat27_material
    SET quantity = NEW.quantity,
        updated_time = NOW()
    WHERE id = NEW.material_id;
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table class2_seat27_inventory
-- ----------------------------
DROP TRIGGER IF EXISTS `tr_inventory_insert_after`;
delimiter ;;
CREATE TRIGGER `tr_inventory_insert_after` AFTER INSERT ON `class2_seat27_inventory` FOR EACH ROW BEGIN
    UPDATE class2_seat27_material
    SET quantity = NEW.quantity,
        updated_time = NOW()
    WHERE id = NEW.material_id;
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table class2_seat27_multi_inout_record
-- ----------------------------
DROP TRIGGER IF EXISTS `after_multi_inout_insert`;
delimiter ;;
CREATE TRIGGER `after_multi_inout_insert` AFTER INSERT ON `class2_seat27_multi_inout_record` FOR EACH ROW BEGIN
    -- 获取进出仓明细
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_material_code VARCHAR(255);
    DECLARE v_quantity INT;
    DECLARE v_total_price DECIMAL(38,2);
    DECLARE v_operation_type VARCHAR(20);

    DECLARE cur CURSOR FOR 
        SELECT material_code, quantity, total_price, NEW.operation_type
        FROM class2_seat27_multi_inout_detail
        WHERE multi_inout_record_id = NEW.id;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    IF NEW.status = 'COMPLETED' THEN
        OPEN cur;

        read_loop: LOOP
            FETCH cur INTO v_material_code, v_quantity, v_total_price, v_operation_type;
            IF done THEN
                LEAVE read_loop;
            END IF;

            -- 更新或插入物料统计数据
            INSERT INTO class2_seat27_material_statistics (
                material_id, 
                start_date, 
                end_date, 
                inbound_quantity, 
                inbound_amount, 
                outbound_quantity, 
                outbound_amount, 
                net_flow, 
                net_amount
            ) VALUES (
                (SELECT id FROM class2_seat27_material WHERE material_code = v_material_code),
                DATE(NEW.operation_date),
                DATE(NEW.operation_date),
                IF(v_operation_type = 'INBOUND', v_quantity, 0),
                IF(v_operation_type = 'INBOUND', v_total_price, 0),
                IF(v_operation_type = 'OUTBOUND', v_quantity, 0),
                IF(v_operation_type = 'OUTBOUND', v_total_price, 0),
                IF(v_operation_type = 'INBOUND', v_quantity, -v_quantity),
                IF(v_operation_type = 'INBOUND', v_total_price, -v_total_price)
            )
            ON DUPLICATE KEY UPDATE
                inbound_quantity = inbound_quantity + IF(v_operation_type = 'INBOUND', v_quantity, 0),
                inbound_amount = inbound_amount + IF(v_operation_type = 'INBOUND', v_total_price, 0),
                outbound_quantity = outbound_quantity + IF(v_operation_type = 'OUTBOUND', v_quantity, 0),
                outbound_amount = outbound_amount + IF(v_operation_type = 'OUTBOUND', v_total_price, 0),
                net_flow = net_flow + IF(v_operation_type = 'INBOUND', v_quantity, -v_quantity),
                net_amount = net_amount + IF(v_operation_type = 'INBOUND', v_total_price, -v_total_price);
        END LOOP;

        CLOSE cur;
    END IF;
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table class2_seat27_multi_inout_record
-- ----------------------------
DROP TRIGGER IF EXISTS `after_multi_inout_update`;
delimiter ;;
CREATE TRIGGER `after_multi_inout_update` AFTER UPDATE ON `class2_seat27_multi_inout_record` FOR EACH ROW BEGIN
    -- 获取进出仓明细
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_material_code VARCHAR(255);
    DECLARE v_quantity INT;
    DECLARE v_total_price DECIMAL(38,2);
    DECLARE v_operation_type VARCHAR(20);

    DECLARE cur CURSOR FOR 
        SELECT material_code, quantity, total_price, NEW.operation_type
        FROM class2_seat27_multi_inout_detail
        WHERE multi_inout_record_id = NEW.id;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    IF OLD.status != 'COMPLETED' AND NEW.status = 'COMPLETED' THEN
        OPEN cur;

        read_loop: LOOP
            FETCH cur INTO v_material_code, v_quantity, v_total_price, v_operation_type;
            IF done THEN
                LEAVE read_loop;
            END IF;

            -- 更新或插入物料统计数据
            INSERT INTO class2_seat27_material_statistics (
                material_id, 
                start_date, 
                end_date, 
                inbound_quantity, 
                inbound_amount, 
                outbound_quantity, 
                outbound_amount, 
                net_flow, 
                net_amount
            ) VALUES (
                (SELECT id FROM class2_seat27_material WHERE material_code = v_material_code),
                DATE(NEW.operation_date),
                DATE(NEW.operation_date),
                IF(v_operation_type = 'INBOUND', v_quantity, 0),
                IF(v_operation_type = 'INBOUND', v_total_price, 0),
                IF(v_operation_type = 'OUTBOUND', v_quantity, 0),
                IF(v_operation_type = 'OUTBOUND', v_total_price, 0),
                IF(v_operation_type = 'INBOUND', v_quantity, -v_quantity),
                IF(v_operation_type = 'INBOUND', v_total_price, -v_total_price)
            )
            ON DUPLICATE KEY UPDATE
                inbound_quantity = inbound_quantity + IF(v_operation_type = 'INBOUND', v_quantity, 0),
                inbound_amount = inbound_amount + IF(v_operation_type = 'INBOUND', v_total_price, 0),
                outbound_quantity = outbound_quantity + IF(v_operation_type = 'OUTBOUND', v_quantity, 0),
                outbound_amount = outbound_amount + IF(v_operation_type = 'OUTBOUND', v_total_price, 0),
                net_flow = net_flow + IF(v_operation_type = 'INBOUND', v_quantity, -v_quantity),
                net_amount = net_amount + IF(v_operation_type = 'INBOUND', v_total_price, -v_total_price);
        END LOOP;

        CLOSE cur;
    END IF;
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table class2_seat27_multi_inout_record
-- ----------------------------
DROP TRIGGER IF EXISTS `after_multi_inout_operation`;
delimiter ;;
CREATE TRIGGER `after_multi_inout_operation` AFTER UPDATE ON `class2_seat27_multi_inout_record` FOR EACH ROW BEGIN
    -- 当记录状态更新为COMPLETED时，确保相关统计信息正确
    IF NEW.status = 'COMPLETED' AND OLD.status != 'COMPLETED' THEN
        -- 这里不需要直接更新统计表，因为统计是通过存储过程动态计算的
        -- 但可以确保库存表和物料表的数据一致性
        -- 触发器仅用于确保数据一致性，实际统计由存储过程计算
        SELECT 1 INTO @dummy; -- 添加一个简单的操作，确保触发器语法正确
    END IF;
END
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
