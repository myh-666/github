-- 修复低库存预警存储过程中的子查询问题
DROP PROCEDURE IF EXISTS `class2_seat27_low_inventory_warning`;
delimiter ;;
CREATE PROCEDURE `class2_seat27_low_inventory_warning`(IN p_start_date DATE,
    IN p_end_date DATE,
    OUT p_result INT,
    OUT p_message VARCHAR(500))
BEGIN
    -- 创建临时表存储低库存预警结果
    DROP TEMPORARY TABLE IF EXISTS temp_low_inventory;
    CREATE TEMPORARY TABLE temp_low_inventory (
        material_id BIGINT,
        material_code VARCHAR(50),
        material_name VARCHAR(100),
        specification VARCHAR(200),
        unit VARCHAR(20),
        current_quantity INT,
        min_stock INT,
        stock_status VARCHAR(20),
        warning_level VARCHAR(20)
    );

    -- 查询低库存物料
    INSERT INTO temp_low_inventory
    SELECT
        m.id,
        m.material_code,
        m.name,
        m.specification,
        m.unit,
        COALESCE(i.quantity, 0) AS current_quantity,
        m.min_stock,
        CASE
            WHEN COALESCE(i.quantity, 0) = 0 THEN '缺货'
            WHEN COALESCE(i.quantity, 0) < m.min_stock THEN '库存不足'
            ELSE '库存正常'
            END AS stock_status,
        CASE
            WHEN COALESCE(i.quantity, 0) = 0 THEN '紧急'
            WHEN COALESCE(i.quantity, 0) < m.min_stock * 0.5 THEN '高'
            WHEN COALESCE(i.quantity, 0) < m.min_stock THEN '中'
            ELSE '低'
            END AS warning_level
    FROM
        class2_seat27_material m
        LEFT JOIN (
            SELECT i1.material_id, i1.quantity
            FROM class2_seat27_inventory i1
            INNER JOIN (
                SELECT material_id, MAX(id) as max_id
                FROM class2_seat27_inventory
                GROUP BY material_id
            ) i2 ON i1.material_id = i2.material_id AND i1.id = i2.max_id
        ) i ON m.id = i.material_id
    WHERE
        COALESCE(i.quantity, 0) <= m.min_stock
        AND m.min_stock > 0
    ORDER BY
        stock_status, warning_level, current_quantity;

    -- 返回低库存预警数据
    SELECT * FROM temp_low_inventory;

    SET p_result = 1;
    SET p_message = '低库存预警查询完成';
END
;;
delimiter ;