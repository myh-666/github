package com.class2.seat27.client;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * 物料明细对话框类
 * 用于输入物料的数量、单价等信息
 */
public class MaterialDetailDialog extends JDialog {
    private JTextField quantityField;
    private JTextField unitPriceField;
    private JTextField totalPriceField;
    private JTextArea remarkArea;
    private JButton confirmButton;
    private JButton cancelButton;

    private JFrame parent;
    private Map<String, Object> material;
    private Map<String, Object> detail;
    private boolean confirmed = false;
    private BigDecimal defaultUnitPrice;

    private static final DecimalFormat decimalFormat = new DecimalFormat("#0.00");

    public MaterialDetailDialog(JFrame parent, Map<String, Object> material) {
        super(parent, "物料明细", true);
        this.parent = parent;
        this.material = material;
        this.defaultUnitPrice = null;

        initComponents();
        setupLayout();
        setupListeners();

        // 填充物料信息
        fillMaterialInfo();
    }
    
    public MaterialDetailDialog(JFrame parent, Map<String, Object> material, BigDecimal defaultUnitPrice) {
        super(parent, "物料明细", true);
        this.parent = parent;
        this.material = material;
        this.defaultUnitPrice = defaultUnitPrice;

        initComponents();
        setupLayout();
        setupListeners();

        // 填充物料信息
        fillMaterialInfo();
    }

    private void initComponents() {
        quantityField = new JTextField(15); // 增加字段宽度
        unitPriceField = new JTextField(15); // 增加字段宽度
        totalPriceField = new JTextField(15); // 增加字段宽度
        totalPriceField.setEditable(false);
        remarkArea = new JTextArea(3, 20);
        remarkArea.setLineWrap(true);
        remarkArea.setWrapStyleWord(true);

        confirmButton = new JButton("确认");
        cancelButton = new JButton("取消");
    }

    private void setupLayout() {
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(500, 400)); // 增大对话框尺寸

        // 主面板
        JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        // 物料编码
        gbc.gridx = 0;
        gbc.gridy = 0;
        mainPanel.add(new JLabel("物料编码:"), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        JLabel materialCodeLabel = new JLabel(material.get("materialCode").toString());
        materialCodeLabel.setToolTipText("物料编码不可修改");
        mainPanel.add(materialCodeLabel, gbc);

        // 物料名称
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.NONE;
        mainPanel.add(new JLabel("物料名称:"), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        mainPanel.add(new JLabel(material.get("name").toString()), gbc);

        // 规格
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.fill = GridBagConstraints.NONE;
        mainPanel.add(new JLabel("规格:"), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        mainPanel.add(new JLabel(material.get("specification") != null ? material.get("specification").toString() : ""), gbc);

        // 单位
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.fill = GridBagConstraints.NONE;
        mainPanel.add(new JLabel("单位:"), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        mainPanel.add(new JLabel(material.get("unit").toString()), gbc);

        // 数量
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.fill = GridBagConstraints.NONE;
        mainPanel.add(new JLabel("数量:"), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        mainPanel.add(quantityField, gbc);

        // 单价
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.fill = GridBagConstraints.NONE;
        mainPanel.add(new JLabel("单价:"), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        mainPanel.add(unitPriceField, gbc);

        // 总价
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.fill = GridBagConstraints.NONE;
        mainPanel.add(new JLabel("总价:"), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        mainPanel.add(totalPriceField, gbc);

        // 备注
        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.fill = GridBagConstraints.NONE;
        mainPanel.add(new JLabel("备注:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 7;
        gbc.fill = GridBagConstraints.BOTH;
        JScrollPane remarkScrollPane = new JScrollPane(remarkArea);
        remarkScrollPane.setPreferredSize(new Dimension(200, 60));
        mainPanel.add(remarkScrollPane, gbc);

        // 按钮面板
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(confirmButton);
        buttonPanel.add(cancelButton);
        
        // 提示面板
        JPanel hintPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel hintLabel = new JLabel("提示：填写数量后要回车计算总价，再确认");
        hintLabel.setForeground(Color.BLUE);
        hintPanel.add(hintLabel);

        add(mainPanel, BorderLayout.CENTER);
        add(hintPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(parent);
    }

    private void setupListeners() {
        // 数量字段变化时计算总价
        quantityField.addActionListener(e -> {
            calculateTotalPrice();
            JOptionPane.showMessageDialog(this, "已计算总价，请确认信息", "提示", JOptionPane.INFORMATION_MESSAGE);
        });

        // 单价字段变化时计算总价
        unitPriceField.addActionListener(e -> {
            calculateTotalPrice();
            JOptionPane.showMessageDialog(this, "已计算总价，请确认信息", "提示", JOptionPane.INFORMATION_MESSAGE);
        });

        // 确认按钮
        confirmButton.addActionListener(e -> {
            try {
                // 验证输入
                String quantityText = quantityField.getText().trim();
                String unitPriceText = unitPriceField.getText().trim();

                if (quantityText.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "请输入数量", "错误", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (unitPriceText.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "请输入单价", "错误", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // 创建明细对象
                detail = new HashMap<>();
                // 确保materialId是字符串类型
                Object materialId = material.get("id");
                detail.put("materialId", materialId != null ? materialId.toString() : null);
                detail.put("materialCode", material.get("materialCode"));
                detail.put("materialName", material.get("name"));
                detail.put("specification", material.get("specification"));
                detail.put("unit", material.get("unit"));
                detail.put("quantity", new BigDecimal(quantityText));
                detail.put("unitPrice", new BigDecimal(unitPriceText));
                detail.put("totalPrice", new BigDecimal(totalPriceField.getText().trim()));
                detail.put("remark", remarkArea.getText().trim());

                confirmed = true;
                dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "请输入有效的数字", "错误", JOptionPane.ERROR_MESSAGE);
            }
        });

        // 取消按钮
        cancelButton.addActionListener(e -> {
            confirmed = false;
            dispose();
        });
    }

    private void fillMaterialInfo() {
        // 优先使用传入的单价
        if (defaultUnitPrice != null) {
            unitPriceField.setText(decimalFormat.format(defaultUnitPrice));
            unitPriceField.setEditable(false); // 设置为不可编辑
        }
        // 如果没有传入单价，但物料有价格，使用物料价格作为默认单价
        else if (material.get("price") != null) {
            unitPriceField.setText(decimalFormat.format(material.get("price")));
        }
    }

    private void calculateTotalPrice() {
        try {
            String quantityText = quantityField.getText().trim();
            String unitPriceText = unitPriceField.getText().trim();

            if (!quantityText.isEmpty() && !unitPriceText.isEmpty()) {
                BigDecimal quantity = new BigDecimal(quantityText);
                BigDecimal unitPrice = new BigDecimal(unitPriceText);
                BigDecimal totalPrice = quantity.multiply(unitPrice);

                totalPriceField.setText(decimalFormat.format(totalPrice));
            }
        } catch (NumberFormatException ex) {
            // 忽略无效输入
        }
    }

    public Map<String, Object> getDetail() {
        return confirmed ? detail : null;
    }
}
