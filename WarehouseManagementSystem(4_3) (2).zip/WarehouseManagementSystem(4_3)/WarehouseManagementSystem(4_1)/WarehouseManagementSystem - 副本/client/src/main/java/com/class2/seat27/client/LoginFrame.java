package com.class2.seat27.client;
import com.class2.seat27.client.http.HttpClientUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class LoginFrame extends JFrame{
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton cancelButton;
    // 注册按钮
    private JButton registerButton;

    private static final String SERVER_URL = "http://localhost:8081/api/auth/login";
    private static final ObjectMapper objectMapper = new ObjectMapper();

    public LoginFrame() {
        initComponents();
        setupLayout();
        setupListeners();
    }

    private void initComponents() {
        setTitle("仓库管理系统 - 登录");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null); // 居中显示
        setResizable(false);

        usernameField = new JTextField(15);
        passwordField = new JPasswordField(15);
        // 设置输入框的固定尺寸
        Dimension fieldSize = new Dimension(180, 28); // 宽度180，高度28
        usernameField.setPreferredSize(fieldSize);
        usernameField.setMaximumSize(fieldSize);
        passwordField.setPreferredSize(fieldSize);
        passwordField.setMaximumSize(fieldSize);
        loginButton = new JButton("登录");
        cancelButton = new JButton("取消");
        registerButton = new JButton("注册");

        // 统一设置按钮大小
        Dimension buttonSize = new Dimension(60, 30); // 统一按钮尺寸
        loginButton.setPreferredSize(buttonSize);
        cancelButton.setPreferredSize(buttonSize);
        registerButton.setPreferredSize(buttonSize);
    }

    private void setupLayout() {
        setLayout(new BorderLayout(10, 10));

        // 主面板
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // 标题
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel titleLabel = new JLabel("仓库管理系统", JLabel.CENTER);
        titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 24));
        mainPanel.add(titleLabel, gbc);

        // 用户名
        gbc.gridwidth = 1;
        gbc.gridy = 1;
        gbc.gridx = 0;
        mainPanel.add(new JLabel("用户名:"), gbc);

        gbc.gridx = 1;
        // 创建固定大小的用户名面板
        JPanel usernamePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        mainPanel.add(usernameField, gbc);
        mainPanel.add(usernamePanel, gbc);

        // 密码
        gbc.gridy = 2;
        gbc.gridx = 0;
        mainPanel.add(new JLabel("密码:"), gbc);

        gbc.gridx = 1;
        // 创建固定大小的密码面板
        JPanel passwordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        mainPanel.add(passwordField, gbc);
        mainPanel.add(passwordPanel, gbc);

        // 按钮面板
        gbc.gridy = 3;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0)); // 减少按钮间距
        buttonPanel.add(loginButton);
        buttonPanel.add(cancelButton);
        buttonPanel.add(registerButton);
        mainPanel.add(buttonPanel, gbc);

        add(mainPanel, BorderLayout.CENTER);

        // 底部状态栏
        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statusPanel.add(new JLabel("就绪"));
        add(statusPanel, BorderLayout.SOUTH);
    }

    private void setupListeners() {
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        // 回车登录
        passwordField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });

        // 注册按钮点击事件
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 打开注册窗口
                RegisterFrame registerFrame = new RegisterFrame();
                registerFrame.setVisible(true);
            }
        });
    }

    private void login() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "用户名和密码不能为空", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // 准备登录数据 - 使用 Map<String, Object>
            Map<String, Object> loginData = new HashMap<>();
            loginData.put("username", username);
            loginData.put("password", password);

            // 发送登录请求
            String response = HttpClientUtil.postJson(SERVER_URL, loginData);

            // 解析响应
            Map<String, Object> result = objectMapper.readValue(response, Map.class);

            if (Boolean.TRUE.equals(result.get("success"))) {
                // 获取用户信息
                Map<String, Object> userMap = (Map<String, Object>) result.get("user");
                String userName = (String) userMap.get("name");
                String userRole = (String) userMap.get("userRole");
                String personnelCode = (String) userMap.get("personnelCode");
                long userID = getUserIdFromUserMap(userMap); // 确保正确获取用户ID

                // 打开主界面
                SwingUtilities.invokeLater(() -> {
                    MainFrame mainFrame = new MainFrame(userName, userRole, userID, personnelCode);
                    mainFrame.setVisible(true);
                    dispose();
                });
            }else {
                JOptionPane.showMessageDialog(this, result.get("message"), "登录失败", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "连接服务器失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }
    /**
     * 从用户信息Map中提取用户ID
     */
    private Long getUserIdFromUserMap(Map<String, Object> userMap) {
        try {
            Object idObj = userMap.get("id");
            if (idObj instanceof Integer) {
                return ((Integer) idObj).longValue();
            } else if (idObj instanceof Long) {
                return (Long) idObj;
            } else if (idObj instanceof String) {
                return Long.parseLong((String) idObj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}