package com.class2.seat27.client;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * JSON解析辅助类，用于处理服务器响应
 */
public class JSONParserHelper {
    private static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 安全解析JSON字符串
     * @param json JSON字符串
     * @return 解析结果，如果解析失败返回null
     */
    public static <T> T parseJson(String json, Class<T> clazz) {
        try {
            // 检查响应是否为空或太短
            if (json == null || json.trim().isEmpty()) {
                System.err.println("JSON解析失败: 服务器返回空响应");
                return null;
            }

            // 检查响应长度是否合理
            if (json.length() > 1000000) { // 增加限制到1MB
                System.err.println("JSON解析失败: 响应数据过大 (" + json.length() + " 字符)");
                return null;
            }

            // 检查JSON格式是否基本正确
            String trimmedJson = json.trim();
            if (!trimmedJson.startsWith("{") && !trimmedJson.startsWith("[")) {
                System.err.println("JSON解析失败: 响应不是有效的JSON格式");
                System.err.println("响应内容前100字符: " + trimmedJson.substring(0, Math.min(100, trimmedJson.length())));
                return null;
            }

            // 确保结尾字符正确
            if (!trimmedJson.endsWith("}") && !trimmedJson.endsWith("]")) {
                System.err.println("JSON解析失败: 响应不是有效的JSON格式");
                System.err.println("响应内容后100字符: " + trimmedJson.substring(Math.max(0, trimmedJson.length() - 100)));
                return null;
            }

            return objectMapper.readValue(trimmedJson, clazz);
        } catch (Exception e) {
            System.err.println("JSON解析失败: " + e.getMessage());
            System.err.println("错误类型: " + e.getClass().getSimpleName());
            if (json != null) {
                System.err.println("响应长度: " + json.length());
                System.err.println("响应内容前200字符: " + json.substring(0, Math.min(200, json.length())));
                // 检查JSON格式问题
                if (json.length() > 100) {
                    int lastBraceIndex = json.lastIndexOf('}');
                    if (lastBraceIndex > 0) {
                        System.err.println("最后一个}的位置: " + lastBraceIndex);
                        System.err.println("最后一个}后的内容: " + json.substring(lastBraceIndex, Math.min(lastBraceIndex + 50, json.length())));
                    }
                }
            }
            e.printStackTrace();
            return null;
        }
    }
}
