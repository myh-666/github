package com.class2.seat27.client;

import com.class2.seat27.client.http.HttpClientUtil;
import com.class2.seat27.client.http.PermissionHttpClient;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.SwingUtilities;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

/**
 * 进出仓管理界面类
 * 用于进仓单和出仓单的创建、确认、完成等操作
 */
public class InOutFrame extends JPanel {
    private JTextField searchField;
    private JTextField codeField;
    private JTextField statusField;
    private JComboBox<String> dateRangeCombo;
    private JButton searchButton;
    private JButton resetButton;
    private JButton newButton;
    private JButton confirmButton;
    private JButton backButton;

    private JTable detailTable;
    private DefaultTableModel detailTableModel;

    private List<Map<String, Object>> detailList;
    private Map<String, Object> selectedDetail;

    private static final String SERVER_URL = "http://localhost:8081/api/warehouse";
    private static final DecimalFormat decimalFormat = new DecimalFormat("#,##0.##");

    private String username;
    private String operationType; // INBOUND 或 OUTBOUND
    private Long currentUserId; // 添加当前用户ID字段
    private String userRole; // 添加用户角色字段
    private MainFrame parentFrame; // 添加父窗口引用

    public InOutFrame(MainFrame parentFrame, String username, String operationType) {
        this.parentFrame = parentFrame;
        this.username = username;
        this.operationType = operationType;
        // 从父窗口获取用户ID和角色
        this.currentUserId = parentFrame.getCurrentUserId();
        this.userRole = parentFrame.getUserRole();

        setPreferredSize(new Dimension(900, 600));

        initComponents();
        setupLayout();
        setupListeners();
        loadData();
    }

    public String getTitle() {
        if ("INBOUND".equals(operationType)) {
            return "进仓管理 - 多物料";
        } else {
            return "出仓管理 - 多物料";
        }
    }

    private void initComponents() {
        // 搜索区域
        searchField = new JTextField(15);
        codeField = new JTextField(15);
        statusField = new JTextField(15);
        dateRangeCombo = new JComboBox<>();
        dateRangeCombo.addItem("");
        dateRangeCombo.addItem("今天");
        dateRangeCombo.addItem("最近3天");
        dateRangeCombo.addItem("最近7天");
        dateRangeCombo.addItem("最近30天");
        dateRangeCombo.addItem("本月");
        dateRangeCombo.addItem("上月");

        searchButton = new JButton("搜索");
        resetButton = new JButton("重置");
        searchButton.setPreferredSize(new Dimension(80, 30));
        resetButton.setPreferredSize(new Dimension(80, 30));

        // 按钮区域
        newButton = new JButton("新建" + (operationType.equals("INBOUND") ? "进仓单" : "出仓单"));
        confirmButton = new JButton("确认" + (operationType.equals("INBOUND") ? "进仓单" : "出仓单"));
        backButton = new JButton("返回主界面");

        // 设置按钮大小
        newButton.setPreferredSize(new Dimension(120, 30));
        confirmButton.setPreferredSize(new Dimension(120, 30));
        backButton.setPreferredSize(new Dimension(120, 30));

        // 明细表格
        detailTableModel = new DefaultTableModel(
                new Object[]{"单据编号", "物料编码", "物料名称", "规格", "单位", "数量", "单价", "总价", "状态"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // 所有单元格都不可编辑
            }
        };

        detailTable = new JTable(detailTableModel);
    }

    private void setupLayout() {
        setLayout(new BorderLayout(10, 10));

        // 创建主面板并设置边框
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // 顶部面板 - 搜索和按钮
        JPanel topPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0;
        gbc.gridy = 0;
        topPanel.add(new JLabel("搜索:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        topPanel.add(searchField, gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.NONE;
        topPanel.add(searchButton, gbc);

        gbc.gridx = 3;
        gbc.gridy = 0;
        gbc.insets = new Insets(5, 20, 5, 5);
        topPanel.add(newButton, gbc);

        gbc.gridx = 4;
        gbc.gridy = 0;
        topPanel.add(confirmButton, gbc);

        gbc.gridx = 5;
        gbc.gridy = 0;
        gbc.insets = new Insets(5, 20, 5, 5);
        topPanel.add(backButton, gbc);

        // 中间面板 - 明细表格
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(new JScrollPane(detailTable), BorderLayout.CENTER);

        // 添加到主面板
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        add(mainPanel, BorderLayout.CENTER);
    }

    private void setupListeners() {
        // 搜索按钮
        searchButton.addActionListener(e -> {
            // 检查查询权限
            if (!checkUserPermission("INOUT_QUERY")) {
                JOptionPane.showMessageDialog(this,
                        "您没有查询进出仓单的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String keyword = searchField.getText().trim();
            loadData(keyword, true); // 搜索时显示查询结果数量
        });

        // 新建按钮
        newButton.addActionListener(e -> {
            // 检查多物料进出仓操作权限
            if (!checkUserPermission("MULTI_INOUT")) {
                JOptionPane.showMessageDialog(this,
                        "您没有进行多物料进出仓操作的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                return;
            }
            // 多物料进出仓（支持单物料操作）
            showMultiInOutDialog();
        });

        // 确认按钮
        confirmButton.addActionListener(e -> {
            // 检查多物料进出仓操作权限
            if (!checkUserPermission("MULTI_INOUT")) {
                JOptionPane.showMessageDialog(this,
                        "您没有进行多物料进出仓操作的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int selectedRow = detailTable.getSelectedRow();
            if (selectedRow < 0) {
                JOptionPane.showMessageDialog(this, "请选择要确认的单据", "提示", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String documentId = detailTableModel.getValueAt(selectedRow, 0).toString();
            String documentCode = detailTableModel.getValueAt(selectedRow, 0).toString();
            try {
                // 准备请求数据
                Map<String, Object> request = new HashMap<>();
                request.put("username", username);
                request.put("documentCode", documentCode);

                // 多物料进出仓单确认
                String url = SERVER_URL + "/multi-" + (operationType.equals("INBOUND") ? "inbound" : "outbound") + "/confirm";
                String response = HttpClientUtil.postJson(url, request);

                // 解析响应
                Map<String, Object> result = JSONParserHelper.parseJson(response, Map.class);
                if (result == null) {
                    JOptionPane.showMessageDialog(this, "服务器返回的数据格式不正确", "错误", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (Boolean.TRUE.equals(result.get("success"))) {
                    JOptionPane.showMessageDialog(this, "单据已确认", "成功", JOptionPane.INFORMATION_MESSAGE);
                    loadData();
                } else {
                    JOptionPane.showMessageDialog(this, result.get("message"), "错误", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "操作失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });

        // 返回按钮
        backButton.addActionListener(e -> {
            Window window = SwingUtilities.getWindowAncestor(InOutFrame.this);
            if (window != null) {
                window.dispose(); // 关闭当前窗口
            }
        });

        // 表格行选择监听器
        detailTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = detailTable.rowAtPoint(e.getPoint());
                if (row >= 0) {
                    detailTable.setRowSelectionInterval(row, row);
                }
            }
        });
    }

    private void loadData() {
        loadData("");
    }

    private void loadData(String keyword) {
        loadData(keyword, false); // 默认不显示查询结果数量
    }

    private void loadData(String keyword, boolean showResultCount) {
        // 检查查询权限
        if (!checkUserPermission("INOUT_QUERY")) {
            JOptionPane.showMessageDialog(this,
                    "您没有查询进出仓单的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            // 多物料进出仓单
            String url = "http://localhost:8081/api/multi-inout/records?type=" + operationType;
            if (!keyword.isEmpty()) {
                url += "&keyword=" + java.net.URLEncoder.encode(keyword, "UTF-8");
            }
            String response = HttpClientUtil.getJson(url);
            if (response == null || response.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "服务器未返回数据", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }
            Map<String, Object> result = JSONParserHelper.parseJson(response, Map.class);
            detailTableModel.setRowCount(0);
            if (Boolean.TRUE.equals(result.get("success"))) {
                Object data = result.get("data");
                if (data instanceof List) {
                    List<Map<String, Object>> list = (List<Map<String, Object>>) data;
                    int recordCount = 0; // 记录数量

                    // 处理多物料进出仓单数据
                    for (Map<String, Object> item : list) {
                        // 获取单据基本信息
                        String documentCode = item.getOrDefault("documentCode", item.getOrDefault("document_code", "")).toString();
                        String status = item.getOrDefault("status", "").toString();

                        // 获取明细列表
                        List<Map<String, Object>> details = (List<Map<String, Object>>) item.getOrDefault("details", new ArrayList<>());

                        // 如果没有明细，则添加一个空行显示单据信息
                        if (details.isEmpty()) {
                            detailTableModel.addRow(new Object[]{
                                    documentCode,
                                    "",
                                    "无明细",
                                    "",
                                    "",
                                    0,
                                    0,
                                    0,
                                    status
                            });
                            recordCount++;
                        } else {
                            // 为每个明细添加一行
                            for (Map<String, Object> detail : details) {
                                detailTableModel.addRow(new Object[]{
                                        documentCode,
                                        detail.getOrDefault("materialId", detail.getOrDefault("material_id", "")),
                                        detail.getOrDefault("materialName", detail.getOrDefault("material_name", "未知物料")),
                                        detail.getOrDefault("specification", ""),
                                        detail.getOrDefault("unit", ""),
                                        detail.getOrDefault("quantity", 0),
                                        detail.getOrDefault("unitPrice", detail.getOrDefault("unit_price", 0)),
                                        detail.getOrDefault("totalPrice", detail.getOrDefault("total_price", 0)),
                                        status
                                });
                                recordCount++;
                            }
                        }
                    }

                    // 根据参数决定是否显示查询结果数量
                    if (showResultCount) {
                        JOptionPane.showMessageDialog(this, "查询成功，共找到 " + recordCount + " 条记录", "提示", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(this, String.valueOf(result.get("message")), "错误", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "加载数据失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private void showMultiInOutDialog() {
        try {
            // 创建多物料进出仓对话框
            JFrame parentFrame = (JFrame) SwingUtilities.getWindowAncestor(InOutFrame.this);
            MultiInOutDialog multiDialog = new MultiInOutDialog(parentFrame, username, operationType);
            multiDialog.setVisible(true);

            // 刷新数据
            loadData(); // 不显示查询结果数量
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "操作失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    /**
     * 检查用户权限
     */
    private boolean checkUserPermission(String resourceCode) {
        try {
            // 管理员默认拥有所有权限
            if ("ADMIN".equals(userRole)) {
                return true;
            }

            Map<String, Object> result = PermissionHttpClient.checkPermission(currentUserId, resourceCode);
            return Boolean.TRUE.equals(result.get("hasPermission"));
        } catch (Exception e) {
            System.err.println("权限检查失败: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}