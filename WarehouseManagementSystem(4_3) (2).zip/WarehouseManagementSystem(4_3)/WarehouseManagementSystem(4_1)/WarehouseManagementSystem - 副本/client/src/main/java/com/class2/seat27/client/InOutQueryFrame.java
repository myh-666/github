package com.class2.seat27.client;

import com.class2.seat27.client.http.HttpClientUtilNew;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 进出仓单查询窗口
 * 用于查询进仓单和出仓单信息
 */
public class InOutQueryFrame extends JFrame {
    private JTextField startDateField;
    private JTextField endDateField;
    private JComboBox<String> materialComboBox;
    private JComboBox<String> operatorComboBox;
    private JTextField remarkField;
    private JButton searchButton;
    private JButton resetButton;
    private JButton exportButton;
    private JButton backButton;
    private JTable resultTable;
    private DefaultTableModel tableModel;
    private JButton selectStartDateButton;
    private JButton selectEndDateButton;
    private JComboBox<String> typeComboBox; // 新增类型筛选下拉框

    private List<Map<String, Object>> materialList;
    private List<Map<String, Object>> personnelList;
    
    // 添加一个标志变量，用于控制是否显示查询结果数量
    private boolean showResultCount = false; // 默认不显示查询结果数量，只有在用户主动查询时才显示

    private static final String SERVER_URL = "http://localhost:8081/api/warehouse/multi";
    private static final ObjectMapper objectMapper = new ObjectMapper();

    // 日期选择器组件
    private static class JDatePicker extends JPanel {
        private JSpinner daySpinner;
        private JSpinner monthSpinner;
        private JSpinner yearSpinner;

        public JDatePicker() {
            setLayout(new FlowLayout());

            Date currentDate = new Date();
            SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
            SimpleDateFormat monthFormat = new SimpleDateFormat("MM");
            SimpleDateFormat dayFormat = new SimpleDateFormat("dd");

            SpinnerNumberModel yearModel = new SpinnerNumberModel(
                Integer.parseInt(yearFormat.format(currentDate)), 2020, 2100, 1);
            SpinnerNumberModel monthModel = new SpinnerNumberModel(
                Integer.parseInt(monthFormat.format(currentDate)), 1, 12, 1);
            SpinnerNumberModel dayModel = new SpinnerNumberModel(
                Integer.parseInt(dayFormat.format(currentDate)), 1, 31, 1);

            yearSpinner = new JSpinner(yearModel);
            monthSpinner = new JSpinner(monthModel);
            daySpinner = new JSpinner(dayModel);

            add(new JLabel("年:"));
            add(yearSpinner);
            add(new JLabel("月:"));
            add(monthSpinner);
            add(new JLabel("日:"));
            add(daySpinner);
        }

        public Date getDate() {
            try {
                int year = (Integer) yearSpinner.getValue();
                int month = (Integer) monthSpinner.getValue();
                int day = (Integer) daySpinner.getValue();

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                return sdf.parse(year + "-" + (month < 10 ? "0" + month : month) + "-" + (day < 10 ? "0" + day : day));
            } catch (Exception e) {
                return new Date();
            }
        }

        public void setDate(Date date) {
            SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
            SimpleDateFormat monthFormat = new SimpleDateFormat("MM");
            SimpleDateFormat dayFormat = new SimpleDateFormat("dd");

            yearSpinner.setValue(Integer.parseInt(yearFormat.format(date)));
            monthSpinner.setValue(Integer.parseInt(monthFormat.format(date)));
            daySpinner.setValue(Integer.parseInt(dayFormat.format(date)));
        }
    }

    public InOutQueryFrame() {
        setTitle("进出仓单查询");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        initComponents();
        setupLayout();
        setupListeners();
        loadData();

        setSize(1000, 600);
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        // 日期字段
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String today = sdf.format(new Date());
        String oneMonthAgo = sdf.format(new Date(System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000));

        startDateField = new JTextField(15);
        startDateField.setText(oneMonthAgo);
        startDateField.setEditable(false);

        endDateField = new JTextField(15);
        endDateField.setText(today);
        endDateField.setEditable(false);

        // 下拉框
        materialComboBox = new JComboBox<>();
        operatorComboBox = new JComboBox<>();
        typeComboBox = new JComboBox<>(); // 类型筛选下拉框
        typeComboBox.addItem("全部类型");
        typeComboBox.addItem("进仓");
        typeComboBox.addItem("出仓");

        // 备注字段
        remarkField = new JTextField(20);

        // 按钮
        searchButton = new JButton("查询");
        resetButton = new JButton("重置");
        exportButton = new JButton("导出");
        backButton = new JButton("返回主页");
        selectStartDateButton = new JButton("选择日期");
        selectEndDateButton = new JButton("选择日期");

        // 表格
        tableModel = new DefaultTableModel(
            new Object[]{"单号", "类型", "日期", "物料编码", "物料名称", "规格", "单位", 
                        "数量", "单价", "总价", "操作人", "经手人", "备注", "状态"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // 所有单元格不可编辑
            }
        };
        resultTable = new JTable(tableModel);
        resultTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        resultTable.setRowHeight(25);
        resultTable.getTableHeader().setFont(new Font("宋体", Font.BOLD, 14));
        resultTable.setFont(new Font("宋体", Font.PLAIN, 12));

        // 设置按钮大小
        searchButton.setPreferredSize(new Dimension(80, 30));
        resetButton.setPreferredSize(new Dimension(80, 30));
        exportButton.setPreferredSize(new Dimension(80, 30));
        backButton.setPreferredSize(new Dimension(80, 30));
        selectStartDateButton.setPreferredSize(new Dimension(100, 30));
        selectEndDateButton.setPreferredSize(new Dimension(100, 30));
    }

    private void setupLayout() {
        setLayout(new BorderLayout(10, 10));

        // 创建主面板并设置边框
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // 顶部面板 - 查询条件
        JPanel topPanel = new JPanel(new BorderLayout(10, 10));
        JPanel conditionPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // 日期范围
        gbc.gridx = 0;
        gbc.gridy = 0;
        conditionPanel.add(new JLabel("起始日期:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        conditionPanel.add(startDateField, gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        conditionPanel.add(selectStartDateButton, gbc);

        gbc.gridx = 3;
        gbc.gridy = 0;
        conditionPanel.add(new JLabel("结束日期:"), gbc);

        gbc.gridx = 4;
        gbc.gridy = 0;
        conditionPanel.add(endDateField, gbc);

        gbc.gridx = 5;
        gbc.gridy = 0;
        conditionPanel.add(selectEndDateButton, gbc);

        // 物料和操作人
        gbc.gridx = 0;
        gbc.gridy = 1;
        conditionPanel.add(new JLabel("物料:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        conditionPanel.add(materialComboBox, gbc);

        gbc.gridx = 3;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        conditionPanel.add(new JLabel("操作人:"), gbc);

        gbc.gridx = 4;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        conditionPanel.add(operatorComboBox, gbc);

        // 类型筛选
        gbc.gridx = 0;
        gbc.gridy = 2;
        conditionPanel.add(new JLabel("类型:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        conditionPanel.add(typeComboBox, gbc);

        // 备注
        gbc.gridx = 2;
        gbc.gridy = 2;
        conditionPanel.add(new JLabel("备注:"), gbc);

        gbc.gridx = 3;
        gbc.gridy = 2;
        gbc.gridwidth = 3;
        conditionPanel.add(remarkField, gbc);

        // 按钮
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.add(searchButton);
        buttonPanel.add(resetButton);
        buttonPanel.add(exportButton);
        buttonPanel.add(backButton);
        conditionPanel.add(buttonPanel, gbc);

        topPanel.add(conditionPanel, BorderLayout.CENTER);

        // 中间面板 - 结果表格
        JScrollPane scrollPane = new JScrollPane(resultTable);

        // 添加到主面板
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel, BorderLayout.CENTER);
    }

    private void setupListeners() {
        searchButton.addActionListener(e -> {
            showResultCount = true; // 用户主动查询时显示查询结果数量
            searchRecords();
        });
        resetButton.addActionListener(e -> resetFields());
        exportButton.addActionListener(e -> exportResults());
        backButton.addActionListener(e -> {
            // 获取所有打开的窗口
            for (java.awt.Window window : java.awt.Window.getWindows()) {
                // 查找主窗口
                if (window instanceof MainFrame) {
                    // 显示主窗口
                    window.setVisible(true);
                    // 关闭当前窗口
                    this.dispose();
                    break;
                }
            }
        });

        selectStartDateButton.addActionListener(e -> {
            JDatePicker datePicker = new JDatePicker();
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                datePicker.setDate(sdf.parse(startDateField.getText()));
            } catch (Exception ex) {
                datePicker.setDate(new Date());
            }

            int result = JOptionPane.showConfirmDialog(
                this, datePicker, "选择起始日期", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                startDateField.setText(sdf.format(datePicker.getDate()));
            }
        });

        selectEndDateButton.addActionListener(e -> {
            JDatePicker datePicker = new JDatePicker();
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                datePicker.setDate(sdf.parse(endDateField.getText()));
            } catch (Exception ex) {
                datePicker.setDate(new Date());
            }

            int result = JOptionPane.showConfirmDialog(
                this, datePicker, "选择结束日期", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                endDateField.setText(sdf.format(datePicker.getDate()));
            }
        });
    }

    private void loadData() {
        try {
            // 加载物料列表 - 使用现有的进出仓记录获取物料信息
            String recordsResponse = HttpClientUtilNew.getJson("http://localhost:8081/api/multi-inout/records");
            List<Map<String, Object>> recordsList = objectMapper.readValue(recordsResponse, new TypeReference<List<Map<String, Object>>>() {});

            // 从记录中提取唯一物料信息
            Map<String, Map<String, Object>> uniqueMaterials = new HashMap<>();
            if (recordsList != null) {
                for (Map<String, Object> record : recordsList) {
                    if (record.get("material_code") != null && record.get("material_name") != null) {
                        String materialCode = record.get("material_code").toString();
                        if (!uniqueMaterials.containsKey(materialCode)) {
                            Map<String, Object> material = new HashMap<>();
                            material.put("materialCode", materialCode);
                            material.put("name", record.get("material_name"));
                            material.put("id", record.get("material_code")); // 使用物料代码作为ID
                            uniqueMaterials.put(materialCode, material);
                        }
                    }
                }
            }

            materialList = new ArrayList<>(uniqueMaterials.values());
            materialComboBox.removeAllItems();
            materialComboBox.addItem("全部物料");
            if (materialList != null) {
                for (Map<String, Object> material : materialList) {
                    String displayName = material.get("materialCode") + " - " + material.get("name");
                    materialComboBox.addItem(displayName);
                }
            }

            // 从记录中提取唯一操作人信息
            Map<String, Map<String, Object>> uniqueOperators = new HashMap<>();
            if (recordsList != null) {
                for (Map<String, Object> record : recordsList) {
                    if (record.get("operator_code") != null && record.get("operator_name") != null) {
                        String operatorCode = record.get("operator_code").toString();
                        if (!uniqueOperators.containsKey(operatorCode)) {
                            Map<String, Object> operator = new HashMap<>();
                            operator.put("personnelCode", operatorCode);
                            operator.put("name", record.get("operator_name"));
                            uniqueOperators.put(operatorCode, operator);
                        }
                    }
                }
            }

            personnelList = new ArrayList<>(uniqueOperators.values());
            operatorComboBox.removeAllItems();
            operatorComboBox.addItem("全部操作人");
            if (personnelList != null) {
                for (Map<String, Object> personnel : personnelList) {
                    String displayName = personnel.get("personnelCode") + " - " + personnel.get("name");
                    operatorComboBox.addItem(displayName);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "加载数据失败: " + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void searchRecords() {
        try {
            // 构建查询参数
            Map<String, String> params = new HashMap<>();
            params.put("startDate", startDateField.getText());
            params.put("endDate", endDateField.getText());
            
            // 使用正确的多物料进出仓API端点
            String baseUrl = "http://localhost:8081/api/multi-inout/records"; // 使用多物料进出仓查询端点

            // 添加类型参数
            int typeIndex = typeComboBox.getSelectedIndex();
            if (typeIndex > 0) {
                String typeValue = typeComboBox.getSelectedItem().toString();
                if ("进仓".equals(typeValue)) {
                    params.put("type", "INBOUND");
                } else if ("出仓".equals(typeValue)) {
                    params.put("type", "OUTBOUND");
                }
            }

            // 物料参数 - 使用物料代码而不是ID
            int materialIndex = materialComboBox.getSelectedIndex();
            if (materialIndex > 0 && materialList != null && materialIndex <= materialList.size()) {
                params.put("materialCode", materialList.get(materialIndex - 1).get("materialCode").toString());
            }

            // 操作人参数
            int operatorIndex = operatorComboBox.getSelectedIndex();
            if (operatorIndex > 0 && personnelList != null && operatorIndex <= personnelList.size()) {
                params.put("operatorCode", personnelList.get(operatorIndex - 1).get("personnelCode").toString());
            }

            // 添加日期参数
            params.put("startDate", startDateField.getText());
            params.put("endDate", endDateField.getText());

            // 类型参数已在上面处理，这里不需要重复处理

            // 备注参数
            String remark = remarkField.getText().trim();
            if (!remark.isEmpty()) {
                params.put("remark", remark);
            }

            // 构建URL和查询参数
            StringBuilder urlBuilder = new StringBuilder(baseUrl + "?");
            for (Map.Entry<String, String> entry : params.entrySet()) {
                if (entry.getValue() != null && !entry.getValue().isEmpty()) {
                    try {
                        // 对参数值进行URL编码，防止特殊字符导致的问题
                        String encodedValue = java.net.URLEncoder.encode(entry.getValue(), "UTF-8");
                        urlBuilder.append(entry.getKey()).append("=").append(encodedValue).append("&");
                    } catch (Exception e) {
                        urlBuilder.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
                    }
                }
            }
            String url = urlBuilder.toString();
            if (url.endsWith("&")) {
                url = url.substring(0, url.length() - 1);
            }

            // 发送请求
            String response = HttpClientUtilNew.getJson(url);

            // 先尝试解析为数组，如果失败再尝试解析为Map
            List<Map<String, Object>> records = null;
            boolean success = false;
            Map<String, Object> result = null;

            try {
                // 尝试直接解析为数组
                records = objectMapper.readValue(response, List.class);
                success = true;
            } catch (Exception e) {
                // 如果解析数组失败，尝试解析为Map
                try {
                    result = objectMapper.readValue(response, Map.class);

                    // 处理响应结果，支持多种格式
                    if (result.containsKey("success") && Boolean.TRUE.equals(result.get("success"))) {
                        success = true;
                        records = (List<Map<String, Object>>) result.get("data");
                    } else if (result.containsKey("result") && "1".equals(result.get("result").toString())) {
                        success = true;
                        records = (List<Map<String, Object>>) result.get("data");
                    }
                } catch (Exception ex) {
                    throw new RuntimeException("无法解析服务器响应: " + response);
                }
            }
            
            // 已经在上面处理了JSON解析，这里不需要再处理
            
            if (success && records != null) {
                // 根据类型筛选进仓和出仓记录
                int selectedIndex = typeComboBox.getSelectedIndex();
                if (selectedIndex > 0) {
                    String typeValue = typeComboBox.getSelectedItem().toString();
                    List<Map<String, Object>> filteredRecords = new ArrayList<>();
                    
                    for (Map<String, Object> record : records) {
                        String recordType = record.get("operation_type") != null ? record.get("operation_type").toString() : "";
                        if (("进仓".equals(typeValue) && "INBOUND".equals(recordType)) ||
                            ("出仓".equals(typeValue) && "OUTBOUND".equals(recordType))) {
                            filteredRecords.add(record);
                        }
                    }
                    
                    records = filteredRecords;
                }

                // 清空表格
                tableModel.setRowCount(0);

                // 添加数据
                for (Map<String, Object> record : records) {
                    // 处理类型显示
                    String typeDisplay = "";
                    Object typeObj = record.get("operation_type");
                    if (typeObj != null) {
                        String type = typeObj.toString();
                        if ("INBOUND".equals(type)) {
                            typeDisplay = "进仓";
                        } else if ("OUTBOUND".equals(type)) {
                            typeDisplay = "出仓";
                        } else {
                            typeDisplay = type;
                        }
                    }
                    
                    // 处理状态显示
                    String statusDisplay = "";
                    Object statusObj = record.get("status");
                    if (statusObj != null) {
                        String status = statusObj.toString();
                        if ("CONFIRMED".equals(status)) {
                            statusDisplay = "已确认";
                        } else if ("COMPLETED".equals(status)) {
                            statusDisplay = "已完成";
                        } else {
                            statusDisplay = status;
                        }
                    }
                    
                    Object[] row = {
                        record.get("document_code"),
                        typeDisplay,
                        record.get("operation_date"),
                        record.get("material_code"),
                        record.get("material_name"),
                        record.get("specification"),
                        record.get("unit"),
                        record.get("quantity"),
                        record.get("unit_price"),
                        record.get("total_price"),
                        record.get("operator_name"),
                        record.get("handler_name"), // 经手人
                        record.get("remark"),
                        statusDisplay
                    };
                    tableModel.addRow(row);
                }

                // 根据标志变量决定是否显示记录条数提示
                if (showResultCount) {
                    JOptionPane.showMessageDialog(this, "查询成功，共找到 " + records.size() + " 条记录", "提示", JOptionPane.INFORMATION_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, result.get("message"), "错误", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "查询失败: " + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void resetFields() {
        // 重置日期
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String today = sdf.format(new Date());
        String oneMonthAgo = sdf.format(new Date(System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000));

        startDateField.setText(oneMonthAgo);
        endDateField.setText(today);

        // 重置下拉框
        materialComboBox.setSelectedIndex(0);
        operatorComboBox.setSelectedIndex(0);
        typeComboBox.setSelectedIndex(0); // 重置类型筛选

        // 重置备注
        remarkField.setText("");

        // 清空表格
        tableModel.setRowCount(0);
    }
    
    /**
     * 刷新查询数据
     */
    public void refreshData() {
        searchRecords();
    }
    
    /**
     * 设置是否显示查询结果数量
     * @param show 是否显示查询结果数量
     */
    public void setShowResultCount(boolean show) {
        this.showResultCount = show;
    }

    private void exportResults() {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "没有可导出的数据", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("选择导出位置");
        fileChooser.setSelectedFile(new File("进出仓单查询结果_" + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".csv"));

        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();

            try (PrintWriter writer = new PrintWriter(fileToSave)) {
                // 写入表头
                StringBuilder header = new StringBuilder();
                for (int i = 0; i < tableModel.getColumnCount(); i++) {
                    if (i > 0) header.append(",");
                    header.append(tableModel.getColumnName(i));
                }
                writer.println(header.toString());

                // 写入数据
                for (int i = 0; i < tableModel.getRowCount(); i++) {
                    StringBuilder row = new StringBuilder();
                    for (int j = 0; j < tableModel.getColumnCount(); j++) {
                        if (j > 0) row.append(",");

                        Object value = tableModel.getValueAt(i, j);
                        if (value != null) {
                            String strValue = value.toString();
                            // 如果包含逗号，用双引号括起来
                            if (strValue.contains(",")) {
                                strValue = "\"" + strValue.replace("\"", "\"\"") + "\"";
                            }
                            row.append(strValue);
                        }
                    }
                    writer.println(row.toString());
                }

                JOptionPane.showMessageDialog(this, "导出成功: " + fileToSave.getAbsolutePath(), "提示", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "导出失败: " + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}