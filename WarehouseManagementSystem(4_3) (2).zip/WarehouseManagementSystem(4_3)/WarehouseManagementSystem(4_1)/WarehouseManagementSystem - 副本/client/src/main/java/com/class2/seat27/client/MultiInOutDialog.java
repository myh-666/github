package com.class2.seat27.client;

import com.class2.seat27.client.http.HttpClientUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

/**
 * 多物料进出仓对话框类 - 修复版
 * 用于多物料进出仓操作，修复了与服务端交互的问题
 */
public class MultiInOutDialog extends JFrame {
    private JTextField documentCodeField;
    private JTextArea remarkArea;
    private JButton confirmButton;
    private JButton completeButton; // 添加完成按钮
    private JButton addButton;
    private JButton deleteButton;
    private JTable detailTable;
    private DefaultTableModel detailTableModel;

    private List<Map<String, Object>> detailList;
    private Map<String, Object> selectedDetail;

    // 服务器URL，使用多物料进出仓控制器路径
    private static final String SERVER_URL = "http://localhost:8081/api/multi-inout";
    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static final DecimalFormat decimalFormat = new DecimalFormat("#,##0.##");

    private String username;
    private String operationType; // INBOUND 或 OUTBOUND

    public MultiInOutDialog(JFrame parent, String username, String operationType) {
        super();
        setTitle(operationType.equals("INBOUND") ? "多物料进仓" : "多物料出仓");
        this.username = username;
        this.operationType = operationType;

        initComponents();
        setupLayout();
        setupListeners();

        setSize(900, 600);
        setLocationRelativeTo(parent);
    }

    private void initComponents() {
        // 单据编号
        documentCodeField = new JTextField(20);

        // 备注
        remarkArea = new JTextArea(3, 20);
        remarkArea.setLineWrap(true);

        // 按钮
        confirmButton = new JButton("确认" + (operationType.equals("INBOUND") ? "进仓单" : "出仓单"));
        completeButton = new JButton("完成" + (operationType.equals("INBOUND") ? "进仓单" : "出仓单")); // 添加完成按钮
        addButton = new JButton("添加物料");
        deleteButton = new JButton("删除物料");

        // 设置按钮大小
        confirmButton.setPreferredSize(new Dimension(120, 30));
        completeButton.setPreferredSize(new Dimension(120, 30)); // 设置完成按钮大小
        addButton.setPreferredSize(new Dimension(100, 30));
        deleteButton.setPreferredSize(new Dimension(100, 30));

        // 明细表格
        detailTableModel = new DefaultTableModel(
            new Object[]{"物料ID", "物料名称", "规格", "单位", "数量", "单价", "总价", "备注"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 4 || column == 7; // 只允许编辑数量和备注，单价不可编辑
            }
        };

        detailTable = new JTable(detailTableModel);
    }

    private void setupLayout() {
        setLayout(new BorderLayout(10, 10));

        // 创建主面板并设置边框
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // 顶部面板 - 单据信息
        JPanel topPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0;
        gbc.gridy = 0;
        topPanel.add(new JLabel("单据编号:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        topPanel.add(documentCodeField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        topPanel.add(new JLabel("备注:"), gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        topPanel.add(new JScrollPane(remarkArea), gbc);

        // 中间面板 - 明细表格
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(new JScrollPane(detailTable), BorderLayout.CENTER);

        // 底部面板 - 按钮
        JPanel bottomPanel = new JPanel();
        bottomPanel.add(addButton);
        bottomPanel.add(deleteButton);
        bottomPanel.add(confirmButton);
        bottomPanel.add(completeButton); // 添加完成按钮到面板

        // 添加到主面板
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel, BorderLayout.CENTER);
    }

    private void setupListeners() {
        // 添加物料按钮
        addButton.addActionListener(e -> {
            // 传递操作类型到物料选择对话框
            MaterialSelectDialog dialog = new MaterialSelectDialog((JFrame)this, username, operationType);
            dialog.setVisible(true);
            if (dialog.isConfirmed()) {
                Map<String, Object> material = dialog.getSelectedMaterial();
                try {
                    // 获取物料单价
                    BigDecimal unitPrice = getMaterialPrice(material.get("id"));
                    
                    Object[] row = {
                        material.getOrDefault("id", ""),
                        material.getOrDefault("name", material.getOrDefault("materialName", "未知物料")),
                        material.getOrDefault("specification", ""),
                        material.getOrDefault("unit", ""),
                        0,
                        unitPrice,
                        new BigDecimal("0.00"),
                        ""
                    };
                    detailTableModel.addRow(row);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "获取物料信息失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // 删除物料按钮
        deleteButton.addActionListener(e -> {
            int selectedRow = detailTable.getSelectedRow();
            if (selectedRow >= 0) {
                detailTableModel.removeRow(selectedRow);
            } else {
                JOptionPane.showMessageDialog(this, "请选择要删除的物料", "提示", JOptionPane.WARNING_MESSAGE);
            }
        });

        // 确认按钮 - 修复了URL路径
        confirmButton.addActionListener(e -> {
            if (detailTableModel.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "请至少添加一个物料", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String documentCode = documentCodeField.getText().trim();
            if (documentCode.isEmpty()) {
                JOptionPane.showMessageDialog(this, "请输入单据编号", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // 验证数量
            if (!validateQuantities()) {
                return;
            }
            
            try {
                Map<String, Object> request = new HashMap<>();
                request.put("username", username);
                request.put("personnel_code", username); // 添加personnel_code参数
                Map<String, Object> document = new HashMap<>();
                document.put("documentCode", documentCode);
                document.put("remark", remarkArea.getText().trim());
                request.put("document", document);
                List<Map<String, Object>> details = new ArrayList<>();
                for (int i = 0; i < detailTableModel.getRowCount(); i++) {
                    Map<String, Object> detail = new HashMap<>();
                    detail.put("materialId", detailTableModel.getValueAt(i, 0).toString());
                    detail.put("materialName", detailTableModel.getValueAt(i, 1).toString());
                    detail.put("specification", detailTableModel.getValueAt(i, 2).toString());
                    detail.put("unit", detailTableModel.getValueAt(i, 3).toString());
                    // 修复数量字段为int型，与后端保持一致
                    detail.put("quantity", Integer.parseInt(detailTableModel.getValueAt(i, 4).toString()));
                    detail.put("unitPrice", new BigDecimal(detailTableModel.getValueAt(i, 5).toString()));
                    detail.put("totalPrice", new BigDecimal(detailTableModel.getValueAt(i, 6).toString()));
                    detail.put("remark", detailTableModel.getValueAt(i, 7).toString());
                    details.add(detail);
                }
                request.put("details", details);
                // 使用多物料进出仓控制器路径
                String url = SERVER_URL + "/" + (operationType.equals("INBOUND") ? "inbound" : "outbound") + "/create";
                String response = HttpClientUtil.postJson(url, request);
                Map<String, Object> result = objectMapper.readValue(response, Map.class);
                if (Boolean.TRUE.equals(result.get("success"))) {
                    JOptionPane.showMessageDialog(this, "单据已确认", "成功", JOptionPane.INFORMATION_MESSAGE);
                    // 确认后清空明细表，但保留单据编号以便完成操作
                    detailTableModel.setRowCount(0);
                    
                    // 刷新相关数据，但不显示查询结果数量
                    refreshRelatedData(false);
                } else {
                    JOptionPane.showMessageDialog(this, result.get("message"), "错误", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "操作失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });

        // 完成按钮 - 添加完成单据功能
        completeButton.addActionListener(e -> {
            String documentCode = documentCodeField.getText().trim();
            if (documentCode.isEmpty()) {
                JOptionPane.showMessageDialog(this, "请输入单据编号", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // 验证数量
            if (!validateQuantities()) {
                return;
            }

            try {
                // 准备请求数据
                Map<String, Object> request = new HashMap<>();
                request.put("username", username);
                request.put("documentCode", documentCode);

                // 发送请求 - 使用多物料进出仓控制器路径
                String url = SERVER_URL + "/" + (operationType.equals("INBOUND") ? "inbound" : "outbound") + "/complete";
                String response = HttpClientUtil.postJson(url, request);

                // 解析响应
                Map<String, Object> result = objectMapper.readValue(response, Map.class);

                if (Boolean.TRUE.equals(result.get("success"))) {
                    JOptionPane.showMessageDialog(this, "单" + (operationType.equals("INBOUND") ? "进仓" : "出仓") + "单已完成，库存已更新", "成功", JOptionPane.INFORMATION_MESSAGE);
                    
                    // 刷新相关数据
                    refreshRelatedData(false);
                    
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, result.get("message"), "错误", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "操作失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });

        // 表格单元格编辑监听器，用于计算总价
        detailTable.getModel().addTableModelListener(e -> {
            int row = e.getFirstRow();
            int column = e.getColumn();

            if (row >= 0 && (column == 4)) { // 只需监听数量列变化，单价不可编辑
                try {
                    Object quantityObj = detailTableModel.getValueAt(row, 4);
                    Object priceObj = detailTableModel.getValueAt(row, 5);

                    BigDecimal quantity = quantityObj != null ? new BigDecimal(quantityObj.toString()) : BigDecimal.ZERO;
                    BigDecimal price = priceObj != null ? new BigDecimal(priceObj.toString()) : BigDecimal.ZERO;
                    BigDecimal total = quantity.multiply(price);

                    detailTableModel.setValueAt(total, row, 6);
                } catch (NumberFormatException ex) {
                    // 忽略格式错误
                }
            }
        });

        // 表格行选择监听器
        detailTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = detailTable.rowAtPoint(e.getPoint());
                if (row >= 0) {
                    detailTable.setRowSelectionInterval(row, row);
                }
            }
        });
    }
    
    /**
     * 验证物料数量
     * @return 验证结果
     */
    private boolean validateQuantities() {
        for (int i = 0; i < detailTableModel.getRowCount(); i++) {
            try {
                int quantity = Integer.parseInt(detailTableModel.getValueAt(i, 4).toString());
                if (quantity <= 0) {
                    JOptionPane.showMessageDialog(this, "物料数量必须大于0", "错误", JOptionPane.ERROR_MESSAGE);
                    return false;
                }
                
                // 对于出仓操作，检查库存是否充足
                if ("OUTBOUND".equals(operationType)) {
                    Long materialId = Long.parseLong(detailTableModel.getValueAt(i, 0).toString());
                    if (!checkInventory(materialId, quantity)) {
                        String materialName = detailTableModel.getValueAt(i, 1).toString();
                        JOptionPane.showMessageDialog(this, "物料 " + materialName + " 库存不足", "错误", JOptionPane.ERROR_MESSAGE);
                        return false;
                    }
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "物料数量格式错误", "错误", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
        return true;
    }
    
    /**
     * 检查库存是否充足（客户端预检查）
     * @param materialId 物料ID
     * @param requiredQuantity 需要的数量
     * @return 是否充足
     */
    private boolean checkInventory(Long materialId, int requiredQuantity) {
        try {
            String url = "http://localhost:8081/api/warehouse/inventory/check?materialId=" + materialId + "&quantity=" + requiredQuantity;
            String response = HttpClientUtil.getJson(url);
            Map<String, Object> result = objectMapper.readValue(response, Map.class);
            return Boolean.TRUE.equals(result.get("success"));
        } catch (Exception ex) {
            // 如果无法检查库存，返回true，让服务端处理
            return true;
        }
    }
    
    /**
     * 刷新相关数据
     * 在进出仓操作完成后调用，确保库存和报表数据是最新的
     */
    private void refreshRelatedData() {
        refreshRelatedData(true);
    }
    
    /**
     * 刷新相关数据
     * 在进出仓操作完成后调用，确保库存和报表数据是最新的
     * @param showResultCount 是否显示查询结果数量
     */
    private void refreshRelatedData(boolean showResultCount) {
        // 刷新库存数据
        for (java.awt.Window window : java.awt.Window.getWindows()) {
            if (window instanceof InventoryFrame) {
                ((InventoryFrame) window).loadInventoryData();
            }
            // 如果报表窗口打开，刷新报表数据
            else if (window instanceof ReportFrame) {
                ReportFrame reportFrame = (ReportFrame) window;
                if ("MATERIAL".equals(reportFrame.getReportType())) {
                    reportFrame.loadReportData();
                }
            }
            // 如果是进出仓查询窗口，设置是否显示查询结果数量
            else if (window instanceof InOutQueryFrame) {
                InOutQueryFrame queryFrame = (InOutQueryFrame) window;
                queryFrame.setShowResultCount(showResultCount);
                queryFrame.refreshData();
            }
        }
    }
    
    /**
     * 获取物料单价
     * @param materialId 物料ID
     * @return 物料单价
     */
    private BigDecimal getMaterialPrice(Object materialId) {
        try {
            // 调用服务端API获取物料单价
            Map<String, Object> request = new HashMap<>();
            
            // 确保materialId不为null
            if (materialId == null) {
                throw new RuntimeException("物料ID不能为空");
            }
            
            System.out.println("获取物料单价，物料ID: " + materialId + ", 类型: " + materialId.getClass().getName());
            
            // 确保materialId是字符串类型
            request.put("materialId", materialId.toString());
            
            String url = "http://localhost:8081/api/warehouse/material/price?materialId=" + materialId.toString();
            String response = HttpClientUtil.getJson(url);
            System.out.println("服务端响应: " + response); // 添加调试信息
            
            Map<String, Object> result = objectMapper.readValue(response, Map.class);
            System.out.println("解析后的结果: " + result); // 添加调试信息
            
            if (Boolean.TRUE.equals(result.get("success"))) {
                Object priceObj = result.get("price");
                System.out.println("价格对象: " + priceObj); // 添加调试信息
                if (priceObj == null) {
                    System.out.println("价格对象为null，使用默认值0"); // 添加调试信息
                    return BigDecimal.ZERO;
                }
                return new BigDecimal(priceObj.toString());
            } else {
                Object messageObj = result.get("message");
                String message = messageObj != null ? messageObj.toString() : "未知错误";
                throw new RuntimeException(message);
            }
        } catch (Exception ex) {
            throw new RuntimeException("获取物料单价失败: " + ex.getMessage());
        }
    }
}
