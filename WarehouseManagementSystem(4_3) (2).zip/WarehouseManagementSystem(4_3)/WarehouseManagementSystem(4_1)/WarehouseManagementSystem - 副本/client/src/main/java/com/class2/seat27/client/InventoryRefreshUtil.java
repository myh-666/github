package com.class2.seat27.client;

import javax.swing.*;
import java.awt.*;

/**
 * 库存刷新工具类
 * 用于在进出仓操作后刷新库存数据
 */
public class InventoryRefreshUtil {

    /**
     * 刷新所有打开的库存窗口
     * @param parentFrame 父窗口
     */
    public static void refreshAllInventoryFrames(MainFrame parentFrame) {
        if (parentFrame != null) {
            try {
                // 使用Window.getWindows()获取所有打开的窗口
                Window[] windows = Window.getWindows();
                for (Window window : windows) {
                    if (window instanceof InventoryFrame) {
                        // 刷新库存数据
                        ((InventoryFrame) window).loadInventoryData("", "");
                    }
                }
            } catch (Exception ex) {
                System.err.println("刷新库存数据失败: " + ex.getMessage());
                JOptionPane.showMessageDialog(parentFrame, "刷新库存数据失败: " + ex.getMessage(), "警告", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    /**
     * 刷新所有打开的进出仓查询窗口
     * @param parentFrame 父窗口
     */
    public static void refreshAllInOutQueryFrames(MainFrame parentFrame) {
        if (parentFrame != null) {
            try {
                // 使用Window.getWindows()获取所有打开的窗口
                Window[] windows = Window.getWindows();
                for (Window window : windows) {
                    if (window instanceof InOutQueryFrame) {
                        // 刷新查询数据
                        ((InOutQueryFrame) window).refreshData();
                    }
                }
            } catch (Exception ex) {
                System.err.println("刷新进出仓查询数据失败: " + ex.getMessage());
                JOptionPane.showMessageDialog(parentFrame, "刷新进出仓查询数据失败: " + ex.getMessage(), "警告", JOptionPane.WARNING_MESSAGE);
            }
        }
    }
}