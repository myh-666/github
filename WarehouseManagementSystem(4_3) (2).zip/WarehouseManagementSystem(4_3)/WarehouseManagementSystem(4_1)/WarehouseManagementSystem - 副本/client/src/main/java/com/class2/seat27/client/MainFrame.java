package com.class2.seat27.client;

import com.class2.seat27.client.http.PermissionHttpClient;
import com.class2.seat27.client.personnel.ModifyPersonnelFrame;
import com.class2.seat27.client.personnel.QueryPersonnelFrame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * 仓库管理系统主界面类（新版）
 * 继承自JFrame，作为应用程序的主窗口
 */
public class MainFrame extends JFrame {
    // 当前用户名
    private String currentUser;
    // 用户角色
    private String userRole;
    // 员工编号
    private String personnelCode;
    // 当前用户ID - 新增字段
    private Long currentUserId;
    // 状态栏标签
    private JLabel statusLabel;

    /**
     * 构造方法
     * @param userName 当前登录用户名
     * @param userRole 当前用户角色
     * @param personnelCode 员工编号
     */
    public MainFrame(String userName, String userRole,Long userId, String personnelCode) {
        this.currentUser = userName;
        this.userRole = userRole;
        this.personnelCode = personnelCode;
        this.currentUserId = userId; // 初始化当前用户ID
        initComponents(); // 初始化组件
        setupLayout();   // 设置布局
        setupListeners(); // 设置事件监听器

        // 添加权限控制
        setupMenuPermissions();
    }

    /**
     * 初始化界面组件
     */
    private void initComponents() {
        setTitle("仓库管理系统·主界面 (2_27_01)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        // 状态栏
        statusLabel = new JLabel("就绪");
        statusLabel.setBorder(BorderFactory.createEtchedBorder());
    }

    /**
     * 设置界面布局
     */
    private void setupLayout() {
        setLayout(new BorderLayout());

        // 创建菜单栏
        JMenuBar menuBar = createMenuBar();
        setJMenuBar(menuBar);

        // 状态栏
        add(statusLabel, BorderLayout.SOUTH);

        // 中间显示欢迎信息
        JLabel welcomeLabel = new JLabel("欢迎 " + currentUser + " 使用仓库管理系统", JLabel.CENTER);
        welcomeLabel.setFont(new Font("微软雅黑", Font.BOLD, 24));
        welcomeLabel.setForeground(Color.BLUE);
        add(welcomeLabel, BorderLayout.CENTER);
    }

    /**
     * 创建菜单栏
     * @return 配置好的JMenuBar对象
     */
    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        // 系统菜单 - 所有用户都显示
        JMenu systemMenu = new JMenu("个人管理");
        JMenuItem exitItem = new JMenuItem("退出");
        JMenuItem changepwdItem = new JMenuItem("修改密码");
        JMenuItem modifyProfileItem = new JMenuItem("修改个人信息");
        systemMenu.add(exitItem);
        systemMenu.add(changepwdItem);
        systemMenu.add(modifyProfileItem);

        // 人事档案管理菜单 - 所有用户都显示，通过权限控制访问
        JMenu personnelMenu = new JMenu("人事档案管理");
        JMenuItem managePersonnelItem = new JMenuItem("人员管理");
        personnelMenu.add(managePersonnelItem);

        // 物料档案管理菜单 - 所有用户都显示
        JMenu materialMenu = new JMenu("物料档案管理");
        JMenuItem addMaterialItem = new JMenuItem("增加物料");
        JMenuItem modifyMaterialItem = new JMenuItem("修改物料");
        JMenuItem deleteMaterialItem = new JMenuItem("删除物料");
        JMenuItem queryMaterialItem = new JMenuItem("查询物料");
        materialMenu.add(addMaterialItem);
        materialMenu.add(modifyMaterialItem);
        materialMenu.add(deleteMaterialItem);
        materialMenu.addSeparator();
        materialMenu.add(queryMaterialItem);

        // 进出仓管理菜单 - 所有用户都显示
        JMenu warehouseMenu = new JMenu("进出仓管理");
        JMenuItem queryInOutItem = new JMenuItem("进出仓单查询");
        JMenuItem multiInOutItem = new JMenuItem("多物料进出仓");
        warehouseMenu.add(queryInOutItem);
        warehouseMenu.add(multiInOutItem);

        // 库存管理菜单 - 所有用户都显示
        JMenu inventoryMenu = new JMenu("库存管理");
        JMenuItem queryInventoryItem = new JMenuItem("查询库存");
        JMenuItem lowStockItem = new JMenuItem("低库存预警");
        inventoryMenu.add(queryInventoryItem);
        inventoryMenu.add(lowStockItem);

        // 报表统计菜单 - 所有用户都显示
        JMenu reportMenu = new JMenu("报表统计");
        JMenuItem reportItem = new JMenuItem("报表统计");
        reportMenu.add(reportItem);

        // 用户管理菜单 - 所有用户都显示，通过权限控制访问
        JMenu userMenu = new JMenu("用户管理");
        JMenuItem authItem = new JMenuItem("用户授权");
        userMenu.add(authItem);

        // 添加所有菜单 - 不再基于角色隐藏
        menuBar.add(systemMenu);
        menuBar.add(userMenu); // 所有用户都能看到用户管理菜单
        menuBar.add(personnelMenu);
        menuBar.add(materialMenu);
        menuBar.add(warehouseMenu);
        menuBar.add(inventoryMenu);
        menuBar.add(reportMenu);

        return menuBar;
    }

    /**
     * 设置事件监听器
     */
    private void setupListeners() {
        // 获取菜单栏
        JMenuBar menuBar = getJMenuBar();
        if (menuBar == null) return;

        // 安全地获取菜单项
        setupSystemMenuListeners(menuBar);
        setupUserManagementListeners(menuBar);
        setupMaterialManagementListeners(menuBar);
        setupWarehouseManagementListeners(menuBar);
        setupInventoryManagementListeners(menuBar);
        setupReportManagementListeners(menuBar);
        setupPersonnelManagementListeners(menuBar);
    }

    /**
     * 设置系统菜单监听器
     */
    private void setupSystemMenuListeners(JMenuBar menuBar) {
        JMenu systemMenu = findMenu(menuBar, "个人管理");
        if (systemMenu == null) return;

        // 安全地获取菜单项
        JMenuItem exitItem = findMenuItem(systemMenu, "退出");
        JMenuItem changepwdItem = findMenuItem(systemMenu, "修改密码");
        JMenuItem modifyProfileItem = findMenuItem(systemMenu, "修改个人信息");

        if (exitItem != null) {
            exitItem.addActionListener(e -> {
                int option = JOptionPane.showConfirmDialog(
                        MainFrame.this,
                        "确认退出？",
                        "退出确认",
                        JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.QUESTION_MESSAGE);

                if (option == JOptionPane.OK_OPTION) {
                    LoginFrame loginFrame = new LoginFrame();
                    loginFrame.setVisible(true);
                    dispose();
                }
            });
        }

        if (changepwdItem != null) {
            changepwdItem.addActionListener(e -> {
                ChangePwdFrame changePwdFrame = new ChangePwdFrame(currentUser);
                changePwdFrame.setVisible(true);
            });
        }

        if (modifyProfileItem != null) {
            modifyProfileItem.addActionListener(e -> {
                Long currentUserId = getCurrentUserId();
                if (currentUserId != null) {
                    ModifyPersonnelFrame modifyFrame = new ModifyPersonnelFrame(currentUserId);
                    modifyFrame.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(MainFrame.this,
                            "无法获取当前用户信息", "错误", JOptionPane.ERROR_MESSAGE);
                }
            });
        }
    }

    /**
     * 设置用户管理监听器
     */
    // 在 setupUserManagementListeners 方法中修改：
    private void setupUserManagementListeners(JMenuBar menuBar) {
        // 移除角色检查，改为权限检查
        JMenu userMenu = findMenu(menuBar, "用户管理");
        if (userMenu == null) return;

        JMenuItem authItem = findMenuItem(userMenu, "用户授权");
        if (authItem != null) {
            authItem.addActionListener(e -> {
                // 基于权限检查而不是角色检查
                if (!checkUserPermission("USER_AUTH")) {
                    JOptionPane.showMessageDialog(MainFrame.this,
                            "您没有用户授权的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                UserAuthFrame authFrame = new UserAuthFrame(currentUser, currentUserId);
                authFrame.setVisible(true);
            });
        }
    }

    /**
     * 设置物料管理监听器
     */
    // 在 setupMaterialManagementListeners 方法中，确保正确设置操作类型
    private void setupMaterialManagementListeners(JMenuBar menuBar) {
        JMenu materialMenu = findMenu(menuBar, "物料档案管理");
        if (materialMenu == null) return;

        JMenuItem addMaterialItem = findMenuItem(materialMenu, "增加物料");
        JMenuItem modifyMaterialItem = findMenuItem(materialMenu, "修改物料");
        JMenuItem deleteMaterialItem = findMenuItem(materialMenu, "删除物料");
        JMenuItem queryMaterialItem = findMenuItem(materialMenu, "查询物料");

        if (addMaterialItem != null) {
            addMaterialItem.addActionListener(e -> {
                if (!checkUserPermission("MATERIAL_ADD")) {
                    JOptionPane.showMessageDialog(MainFrame.this,
                            "您没有增加物料的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                MaterialFrame materialFrame = new MaterialFrame(this, currentUser);
                materialFrame.setOperationType("ADD"); // 确保设置操作类型
                materialFrame.setVisible(true);
            });
        }

        if (modifyMaterialItem != null) {
            modifyMaterialItem.addActionListener(e -> {
                if (!checkUserPermission("MATERIAL_MODIFY")) {
                    JOptionPane.showMessageDialog(MainFrame.this,
                            "您没有修改物料的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                MaterialFrame materialFrame = new MaterialFrame(this, currentUser);
                materialFrame.setOperationType("MODIFY"); // 确保设置操作类型
                materialFrame.setVisible(true);
            });
        }

        if (deleteMaterialItem != null) {
            deleteMaterialItem.addActionListener(e -> {
                if (!checkUserPermission("MATERIAL_DELETE")) {
                    JOptionPane.showMessageDialog(MainFrame.this,
                            "您没有删除物料的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                MaterialFrame materialFrame = new MaterialFrame(this, currentUser);
                materialFrame.setOperationType("DELETE"); // 确保设置操作类型
                materialFrame.setVisible(true);
            });
        }

        if (queryMaterialItem != null) {
            queryMaterialItem.addActionListener(e -> {
                if (!checkUserPermission("MATERIAL_QUERY")) {
                    JOptionPane.showMessageDialog(MainFrame.this,
                            "您没有查询物料的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                MaterialFrame materialFrame = new MaterialFrame(this, currentUser);
                materialFrame.setOperationType("QUERY"); // 确保设置操作类型
                materialFrame.setVisible(true);
            });
        }
    }
    /*private void setupMaterialManagementListeners(JMenuBar menuBar) {
        JMenu materialMenu = findMenu(menuBar, "物料档案管理");
        if (materialMenu == null) return;

        JMenuItem addMaterialItem = findMenuItem(materialMenu, "增加物料");
        JMenuItem modifyMaterialItem = findMenuItem(materialMenu, "修改物料");
        JMenuItem deleteMaterialItem = findMenuItem(materialMenu, "删除物料");
        JMenuItem queryMaterialItem = findMenuItem(materialMenu, "查询物料");

        if (addMaterialItem != null) {
            addMaterialItem.addActionListener(e -> {
                if (!checkUserPermission("MATERIAL_ADD")) {
                    JOptionPane.showMessageDialog(MainFrame.this,
                            "您没有增加物料的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                MaterialFrame materialFrame = new MaterialFrame(this, currentUser);
                materialFrame.setOperationType("ADD");
                materialFrame.setVisible(true);
            });
        }

        if (modifyMaterialItem != null) {
            modifyMaterialItem.addActionListener(e -> {
                if (!checkUserPermission("MATERIAL_MODIFY")) {
                    JOptionPane.showMessageDialog(MainFrame.this,
                            "您没有修改物料的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                MaterialFrame materialFrame = new MaterialFrame(this, currentUser);
                materialFrame.setOperationType("MODIFY");
                materialFrame.setVisible(true);
            });
        }

        if (deleteMaterialItem != null) {
            deleteMaterialItem.addActionListener(e -> {
                if (!checkUserPermission("MATERIAL_DELETE")) {
                    JOptionPane.showMessageDialog(MainFrame.this,
                            "您没有删除物料的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                MaterialFrame materialFrame = new MaterialFrame(this, currentUser);
                materialFrame.setOperationType("DELETE");
                materialFrame.setVisible(true);
            });
        }

        if (queryMaterialItem != null) {
            queryMaterialItem.addActionListener(e -> {
                if (!checkUserPermission("MATERIAL_QUERY")) {
                    JOptionPane.showMessageDialog(MainFrame.this,
                            "您没有查询物料的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                MaterialFrame materialFrame = new MaterialFrame(this, currentUser);
                materialFrame.setOperationType("QUERY");
                materialFrame.setVisible(true);
            });
        }
    }*/

    /**
     * 设置进出仓管理监听器
     */
    private void setupWarehouseManagementListeners(JMenuBar menuBar) {
        JMenu warehouseMenu = findMenu(menuBar, "进出仓管理");
        if (warehouseMenu == null) return;

        JMenuItem queryInOutItem = findMenuItem(warehouseMenu, "进出仓单查询");
        JMenuItem multiInOutItem = findMenuItem(warehouseMenu, "多物料进出仓");

        if (queryInOutItem != null) {
            queryInOutItem.addActionListener(e -> {
                if (!checkUserPermission("INOUT_QUERY")) {
                    JOptionPane.showMessageDialog(MainFrame.this,
                            "您没有查询进出仓单的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                InOutQueryFrame queryFrame = new InOutQueryFrame();
                queryFrame.setVisible(true);
            });
        }

        if (multiInOutItem != null) {
            multiInOutItem.addActionListener(e -> {
                if (!checkUserPermission("MULTI_INOUT")) {
                    JOptionPane.showMessageDialog(MainFrame.this,
                            "您没有进行多物料进出仓操作的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                JFrame dialog = new JFrame("多物料进出仓");
                dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                JTabbedPane tabbedPane = new JTabbedPane();

                MultiInOutPanel inboundPanel = new MultiInOutPanel(this, currentUser, personnelCode, "INBOUND");
                tabbedPane.addTab("进仓管理", inboundPanel);

                MultiInOutPanel outboundPanel = new MultiInOutPanel(this, currentUser, personnelCode, "OUTBOUND");
                tabbedPane.addTab("出仓管理", outboundPanel);

                dialog.add(tabbedPane);
                dialog.setSize(1000, 700);
                dialog.setLocationRelativeTo(this);
                dialog.setVisible(true);
            });
        }
    }

    /**
     * 设置库存管理监听器
     */
    private void setupInventoryManagementListeners(JMenuBar menuBar) {
        JMenu inventoryMenu = findMenu(menuBar, "库存管理");
        if (inventoryMenu == null) return;

        JMenuItem queryInventoryItem = findMenuItem(inventoryMenu, "查询库存");
        JMenuItem lowStockItem = findMenuItem(inventoryMenu, "低库存预警");

        if (queryInventoryItem != null) {
            queryInventoryItem.addActionListener(e -> {
                if (!checkUserPermission("INVENTORY_QUERY")) {
                    JOptionPane.showMessageDialog(MainFrame.this,
                            "您没有查询库存的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                InventoryFrame inventoryFrame = new InventoryFrame(this, currentUser);
                inventoryFrame.loadInventoryData();
                inventoryFrame.setVisible(true);
            });
        }

        if (lowStockItem != null) {
            lowStockItem.addActionListener(e -> {
                if (!checkUserPermission("LOW_STOCK_ALERT")) {
                    JOptionPane.showMessageDialog(MainFrame.this,
                            "您没有查看低库存预警的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                InventoryFrame inventoryFrame = new InventoryFrame(this, currentUser);
                inventoryFrame.showLowStockDialogWithThreshold();
            });
        }
    }

    /**
     * 设置报表管理监听器
     */
    private void setupReportManagementListeners(JMenuBar menuBar) {
        JMenu reportMenu = findMenu(menuBar, "报表统计");
        if (reportMenu == null) return;

        JMenuItem reportItem = findMenuItem(reportMenu, "报表统计");
        if (reportItem != null) {
            reportItem.addActionListener(e -> {
                if (!checkUserPermission("REPORT_STAT")) {
                    JOptionPane.showMessageDialog(MainFrame.this,
                            "您没有查看报表统计的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                ReportFrame reportFrame = new ReportFrame(this, currentUser, "MATERIAL");
                reportFrame.setVisible(true);
            });
        }
    }

    /**
     * 设置人事管理监听器
     */
    private void setupPersonnelManagementListeners(JMenuBar menuBar) {
        // 移除角色检查，改为权限检查
        JMenu personnelMenu = findMenu(menuBar, "人事档案管理");
        if (personnelMenu == null) return;

        JMenuItem managePersonnelItem = findMenuItem(personnelMenu, "人员管理");
        if (managePersonnelItem != null) {
            managePersonnelItem.addActionListener(e -> {
                // 基于权限检查而不是角色检查
                if (!checkUserPermission("PERSONNEL_MANAGE")) {
                    JOptionPane.showMessageDialog(MainFrame.this,
                            "您没有管理人事档案的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                QueryPersonnelFrame queryFrame = new QueryPersonnelFrame();
                queryFrame.setVisible(true);
            });
        }
    }

    /**
     * 根据菜单文本查找菜单
     */
    private JMenu findMenu(JMenuBar menuBar, String menuText) {
        for (int i = 0; i < menuBar.getMenuCount(); i++) {
            JMenu menu = menuBar.getMenu(i);
            if (menu != null && menuText.equals(menu.getText())) {
                return menu;
            }
        }
        return null;
    }

    /**
     * 根据菜单项文本查找菜单项
     */
    private JMenuItem findMenuItem(JMenu menu, String menuItemText) {
        for (int i = 0; i < menu.getItemCount(); i++) {
            JMenuItem menuItem = menu.getItem(i);
            if (menuItem != null && menuItemText.equals(menuItem.getText())) {
                return menuItem;
            }
        }
        return null;
    }

    public Long getCurrentUserId() {
        try {
            return currentUserId;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public String getUserRole() {
        return userRole;
    }

    /**
     * 检查当前用户是否有指定权限
     */
    private boolean checkUserPermission(String resourceCode) {
        try {
            // 管理员默认拥有所有权限
            if ("ADMIN".equals(userRole)) {
                return true;
            }

            // 个人管理权限默认允许所有登录用户访问
            if ("PERSONAL_CHANGE_PWD".equals(resourceCode) ||
                    "PERSONAL_MODIFY_PROFILE".equals(resourceCode)) {
                return true;
            }

            Map<String, Object> result = PermissionHttpClient.checkPermission(currentUserId, resourceCode);
            return Boolean.TRUE.equals(result.get("hasPermission"));
        } catch (Exception e) {
            System.err.println("权限检查失败: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 根据权限控制菜单项的可访问性
     */
    private void setupMenuPermissions() {
        JMenuBar menuBar = getJMenuBar();
        if (menuBar == null) return;

        // 遍历所有菜单项，根据权限设置可用性
        for (int i = 0; i < menuBar.getMenuCount(); i++) {
            JMenu menu = menuBar.getMenu(i);
            if (menu != null) {
                setMenuPermissions(menu);
            }
        }
    }

    /**
     * 递归设置菜单项权限
     */
    private void setMenuPermissions(JMenu menu) {
        for (int i = 0; i < menu.getItemCount(); i++) {
            JMenuItem menuItem = menu.getItem(i);
            if (menuItem != null) {
                // 根据菜单文本映射到权限资源代码
                String resourceCode = mapMenuToResourceCode(menu.getText(), menuItem.getText());
                if (resourceCode != null) {
                    boolean hasPermission = checkUserPermission(resourceCode);
                    menuItem.setEnabled(hasPermission);

                    // 如果没有权限，添加提示
                    if (!hasPermission) {
                        menuItem.setToolTipText("无访问权限");
                    } else {
                        menuItem.setToolTipText(null); // 清除提示
                    }
                }

                // 如果是子菜单，递归处理
                if (menuItem instanceof JMenu) {
                    setMenuPermissions((JMenu) menuItem);
                }
            }
        }
    }

    /**
     * 将菜单路径映射到权限资源代码
     */
    private String mapMenuToResourceCode(String menuText, String menuItemText) {
        Map<String, String> permissionMap = new HashMap<>();

        // 个人管理权限（所有用户都有，不需要检查）
        permissionMap.put("个人管理/修改密码", "PERSONAL_CHANGE_PWD");
        permissionMap.put("个人管理/修改个人信息", "PERSONAL_MODIFY_PROFILE");

        // 用户管理权限
        permissionMap.put("用户管理/用户授权", "USER_AUTH");

        // 人事档案管理权限
        permissionMap.put("人事档案管理/人员管理", "PERSONNEL_MANAGE");

        // 物料档案管理权限
        permissionMap.put("物料档案管理/增加物料", "MATERIAL_ADD");
        permissionMap.put("物料档案管理/修改物料", "MATERIAL_MODIFY");
        permissionMap.put("物料档案管理/删除物料", "MATERIAL_DELETE");
        permissionMap.put("物料档案管理/查询物料", "MATERIAL_QUERY");

        // 进出仓管理权限
        permissionMap.put("进出仓管理/进出仓单查询", "INOUT_QUERY");
        permissionMap.put("进出仓管理/多物料进出仓", "MULTI_INOUT");

        // 库存管理权限
        permissionMap.put("库存管理/查询库存", "INVENTORY_QUERY");
        permissionMap.put("库存管理/低库存预警", "LOW_STOCK_ALERT");

        // 报表统计权限
        permissionMap.put("报表统计/报表统计", "REPORT_STAT");

        String menuPath = menuText + "/" + menuItemText;
        return permissionMap.get(menuPath);
    }
}