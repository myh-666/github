package com.class2.seat27.client.http;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.HashMap;
import java.util.Map;

public class PersonnelHttpClient {
    private static final String BASE_URL = "http://localhost:8081/api/personnel";
    private static final ObjectMapper objectMapper = new ObjectMapper();

    // 添加人员 - 使用 Map<String, Object> 参数
    public static Map<String, Object> addPersonnel(Map<String, Object> userData) throws Exception {
        String url = BASE_URL + "/addFromMap";
        String response = HttpClientUtil.postJson(url, userData);
        return objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});
    }

    // 修改人员 - 使用 Map<String, Object> 参数
    public static Map<String, Object> updatePersonnel(Map<String, Object> userData) throws Exception {
        String url = BASE_URL + "/updateFromMap";
        String response = HttpClientUtil.postJson(url, userData);
        return objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});
    }

    // 删除人员 - 修改为使用 Map<String, Object>
    public static Map<String, Object> deletePersonnel(Long id) throws Exception {
        String url = BASE_URL + "/delete/" + id;
        Map<String, Object> emptyData = new HashMap<>();
        String response = HttpClientUtil.postJson(url, emptyData);
        return objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});
    }

    // 获取所有人员
    public static Map<String, Object> getAllPersonnel() throws Exception {
        String url = BASE_URL + "/all";
        String response = HttpClientUtil.get(url);
        return objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});
    }

    // 根据姓名搜索
    public static Map<String, Object> searchPersonnelByName(String name) throws Exception {
        String url = BASE_URL + "/search/" + name;
        String response = HttpClientUtil.get(url);
        return objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});
    }

    // 根据人员代码查询
    public static Map<String, Object> getPersonnelByCode(String personnelCode) throws Exception {
        String url = BASE_URL + "/code/" + personnelCode;
        String response = HttpClientUtil.get(url);
        return objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});
    }

    // 根据ID查询人员
    public static Map<String, Object> getPersonnelById(Long id) throws Exception {
        String url = BASE_URL + "/" + id;
        String response = HttpClientUtil.get(url);
        Map<String, Object> result = objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});

        // 处理 ID 类型转换
        if (Boolean.TRUE.equals(result.get("success"))) {
            Map<String, Object> data = (Map<String, Object>) result.get("data");
            if (data != null && data.get("id") instanceof Integer) {
                Integer intId = (Integer) data.get("id");
                data.put("id", intId.longValue());
            }
        }

        return result;
    }

    // 用户授权
    public static Map<String, Object> authorizeUser(Long personnelId, String role) throws Exception {
        String url = BASE_URL + "/authorize";
        Map<String, Object> authData = new HashMap<>();
        authData.put("personnelId", personnelId);
        authData.put("role", role);
        String response = HttpClientUtil.postJson(url, authData);
        return objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});
    }
}