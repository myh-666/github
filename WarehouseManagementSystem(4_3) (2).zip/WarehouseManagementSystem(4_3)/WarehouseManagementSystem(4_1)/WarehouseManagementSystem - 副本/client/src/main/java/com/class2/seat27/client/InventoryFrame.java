package com.class2.seat27.client;

import com.class2.seat27.client.http.HttpClientUtilNew;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

/**
 * 库存管理界面类
 * 用于查看和管理库存信息
 */
public class InventoryFrame extends JFrame {
    private JTextField materialCodeField;
    private JTextField materialNameField;
    private JButton searchButton;
    private JButton refreshButton;
    private JButton lowStockButton;
    private JButton backButton;

    private JTable inventoryTable;
    private DefaultTableModel tableModel;

    private List<Map<String, Object>> inventoryList;

    private static final String SERVER_URL = "http://localhost:8081/api/warehouse";
    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static final DecimalFormat decimalFormat = new DecimalFormat("#,##0.##");

    private String username;
    private MainFrame parentFrame;

    public InventoryFrame(MainFrame parentFrame, String username) {
        this.parentFrame = parentFrame;
        this.username = username;
        initComponents();
        setupLayout();
        setupListeners();
        loadInventoryData();
    }

    /**
     * 初始化组件
     */
    private void initComponents() {
        setTitle("库存管理");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // 搜索区域
        materialCodeField = new JTextField(15);
        materialNameField = new JTextField(15);
        searchButton = new JButton("搜索");
        searchButton.setPreferredSize(new Dimension(80, 30));

        // 按钮区域
        refreshButton = new JButton("刷新");
        lowStockButton = new JButton("低库存预警");
        backButton = new JButton("返回");

        refreshButton.setPreferredSize(new Dimension(80, 30));
        lowStockButton.setPreferredSize(new Dimension(120, 30));
        backButton.setPreferredSize(new Dimension(80, 30));

        // 表格区域
        String[] columnNames = {"ID", "物料编码", "物料名称", "单位", "库存数量", "最低库存", "最后进仓时间", "最后出仓时间", "更新时间"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // 所有单元格不可编辑
            }
        };

        inventoryTable = new JTable(tableModel);
        inventoryTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        inventoryTable.getTableHeader().setReorderingAllowed(false);

        // 设置表格列宽
        inventoryTable.getColumnModel().getColumn(0).setPreferredWidth(50);    // ID
        inventoryTable.getColumnModel().getColumn(1).setPreferredWidth(100);   // 物料编码
        inventoryTable.getColumnModel().getColumn(2).setPreferredWidth(150);   // 物料名称
        inventoryTable.getColumnModel().getColumn(3).setPreferredWidth(60);    // 单位
        inventoryTable.getColumnModel().getColumn(4).setPreferredWidth(100);   // 库存数量
        inventoryTable.getColumnModel().getColumn(5).setPreferredWidth(100);   // 最低库存
        inventoryTable.getColumnModel().getColumn(6).setPreferredWidth(150);   // 最后进仓时间
        inventoryTable.getColumnModel().getColumn(7).setPreferredWidth(150);   // 最后出仓时间
        inventoryTable.getColumnModel().getColumn(8).setPreferredWidth(150);   // 更新时间
    }

    /**
     * 设置布局
     */
    private void setupLayout() {
        // 主面板
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // 搜索面板
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.add(new JLabel("物料编码:"));
        searchPanel.add(materialCodeField);
        searchPanel.add(Box.createHorizontalStrut(10)); // 添加一些间距
        searchPanel.add(new JLabel("物料名称:"));
        searchPanel.add(materialNameField);
        searchPanel.add(Box.createHorizontalStrut(10)); // 添加一些间距
        searchPanel.add(searchButton);

        // 按钮面板
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(refreshButton);
        buttonPanel.add(lowStockButton);
        buttonPanel.add(backButton);

        // 顶部面板
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(searchPanel, BorderLayout.WEST);
        topPanel.add(buttonPanel, BorderLayout.EAST);

        // 表格面板
        JScrollPane tableScrollPane = new JScrollPane(inventoryTable);

        // 添加到主面板
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(tableScrollPane, BorderLayout.CENTER);

        // 添加状态栏
        JPanel statusPanel = new JPanel(new BorderLayout());
        statusPanel.setBorder(BorderFactory.createEtchedBorder());
        statusPanel.add(new JLabel("就绪"), BorderLayout.WEST);
        mainPanel.add(statusPanel, BorderLayout.SOUTH);

        // 添加到窗口
        add(mainPanel);
    }

    /**
     * 设置事件监听器
     */
    private void setupListeners() {
        // 搜索按钮
        searchButton.addActionListener(e -> {
            performSearch();
        });

        // 回车键搜索 (在任一输入框中按回车都触发搜索)
        materialCodeField.addActionListener(e -> performSearch());
        materialNameField.addActionListener(e -> performSearch());

        // 刷新按钮
        refreshButton.addActionListener(e -> {
            loadInventoryData();
        });

        // 低库存预警按钮
        lowStockButton.addActionListener(e -> {
            showLowStockWarning();
        });

        // 返回按钮
        backButton.addActionListener(e -> {
            this.setVisible(false);
            parentFrame.setVisible(true);
        });
    }

    /**
     * 执行搜索操作
     */
    private void performSearch() {
        String materialCode = materialCodeField.getText().trim();
        String materialName = materialNameField.getText().trim();
        loadInventoryData(materialCode, materialName);
    }

    /**
     * 显示低库存预警对话框
     */
    private void showLowStockWarning() {
        // 直接显示当前库存小于最低库存的记录
        showLowStockDialog(null);
    }

    /**
     * 显示低库存对话框
     * @param threshold 库存阈值，如果为null则显示当前库存小于最低库存的记录
     */
    public void showLowStockDialog(BigDecimal threshold) {
        try {
            // 构建请求URL
            String url;
            if (threshold == null) {
                // 显示当前库存小于最低库存的记录
                url = SERVER_URL + "/inventories/low-stock";
            } else {
                // 根据指定阈值查询低库存记录
                url = SERVER_URL + "/inventories/low-stock?threshold=" + threshold;
            }

            System.out.println("正在请求低库存数据，URL: " + url);

            // 发送请求获取低库存列表
            String response = HttpClientUtilNew.getJson(url);

            // 解析响应
            Map<String, Object> result = objectMapper.readValue(response, Map.class);

            if (Boolean.TRUE.equals(result.get("success"))) {
                List<Map<String, Object>> lowStockList = (List<Map<String, Object>>) result.get("data");

                // 调试：打印第一个数据项的键
                if (lowStockList != null && !lowStockList.isEmpty()) {
                    Map<String, Object> firstItem = lowStockList.get(0);
                    System.out.println("服务器返回的字段: " + firstItem.keySet());
                }

                if (lowStockList == null || lowStockList.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "没有低库存物料", "提示", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }

                // 创建低库存表格
                String[] columnNames = {"物料ID", "物料编码", "物料名称", "规格", "单位", "当前库存", "最低库存"};
                DefaultTableModel lowStockTableModel = new DefaultTableModel(columnNames, 0) {
                    @Override
                    public boolean isCellEditable(int row, int column) {
                        return false; // 所有单元格不可编辑
                    }
                };

                for (Map<String, Object> item : lowStockList) {
                    Object[] row = {
                            item.get("materialId"),
                            item.get("materialCode"),
                            item.get("materialName"),
                            item.get("specification"),
                            item.get("unit"),
                            item.get("quantity"),
                            item.get("min_stock") != null ? item.get("min_stock") : (item.get("minStock") != null ? item.get("minStock") : 0)
                    };
                    lowStockTableModel.addRow(row);
                }

                // 创建对话框
                JDialog dialog = new JDialog(this, "低库存预警", true);
                dialog.setLayout(new BorderLayout());

                // 添加表格
                JTable lowStockTable = new JTable(lowStockTableModel);
                JScrollPane scrollPane = new JScrollPane(lowStockTable);
                dialog.add(scrollPane, BorderLayout.CENTER);

                // 添加关闭按钮
                JPanel buttonPanel = new JPanel();
                JButton closeButton = new JButton("关闭");
                closeButton.addActionListener(e -> dialog.dispose());
                buttonPanel.add(closeButton);
                dialog.add(buttonPanel, BorderLayout.SOUTH);

                // 设置对话框大小和位置
                dialog.setSize(800, 500);
                dialog.setLocationRelativeTo(this);
                dialog.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, result.get("message"), "错误", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "查询低库存失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    /**
     * 加载库存数据
     */
    public void loadInventoryData() {
        loadInventoryData("", "");
    }

    /**
     * 加载库存数据（带搜索关键词）
     * @param materialCode 物料编码
     * @param materialName 物料名称
     */
    public void loadInventoryData(String materialCode, String materialName) {
        try {
            // 构建请求URL
            StringBuilder urlBuilder = new StringBuilder(SERVER_URL + "/inventories");
            boolean hasParam = false;

            if (!materialCode.isEmpty()) {
                urlBuilder.append(hasParam ? "&" : "?").append("materialCode=").append(java.net.URLEncoder.encode(materialCode, "UTF-8"));
                hasParam = true;
            }

            if (!materialName.isEmpty()) {
                urlBuilder.append(hasParam ? "&" : "?").append("materialName=").append(java.net.URLEncoder.encode(materialName, "UTF-8"));
            }

            String url = urlBuilder.toString();
            System.out.println("正在请求库存数据，URL: " + url);

            // 发送请求获取库存列表
            String response = HttpClientUtilNew.getJson(url);
            System.out.println("服务器响应: " + response);

            // 解析响应
            Map<String, Object> result = objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});

            if (Boolean.TRUE.equals(result.get("success"))) {
                inventoryList = (List<Map<String, Object>>) result.get("data");
                System.out.println("成功获取库存数据，条数: " + (inventoryList != null ? inventoryList.size() : 0));
                updateInventoryTable();
            } else {
                JOptionPane.showMessageDialog(this, "获取库存列表失败: " + result.get("message"), "错误", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "获取库存列表失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * 更新库存表格
     */
    private void updateInventoryTable() {
        // 清空表格
        tableModel.setRowCount(0);

        // 添加数据到表格
        if (inventoryList != null) {
            for (Map<String, Object> inventory : inventoryList) {
                Object[] row = {
                        inventory.get("id"),
                        inventory.get("materialCode"),
                        inventory.get("materialName"),
                        inventory.get("unit"),
                        formatNumberValue(inventory.get("quantity")),
                        formatNumberValue(inventory.get("minStock")),
                        formatDateTime(inventory.get("lastInboundTime")),
                        formatDateTime(inventory.get("lastOutboundTime")),
                        formatDateTime(inventory.get("updatedTime"))
                };
                tableModel.addRow(row);

                // 添加调试信息
                System.out.println("添加到表格的行数据: " + java.util.Arrays.toString(row));
            }
        }
    }

    /**
     * 显示带阈值输入的低库存预警对话框
     */
    public void showLowStockThresholdDialog() {
        showLowStockDialogWithThreshold();
    }

    /**
     * 显示带阈值输入的低库存预警对话框
     */
    public void showLowStockDialogWithThreshold() {
        JDialog dialog = new JDialog(this, "低库存预警", true);
        dialog.setSize(800, 500);
        dialog.setLocationRelativeTo(this);

        // 创建表单
        JPanel formPanel = new JPanel(new BorderLayout());
        formPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // 输入阈值
        JPanel inputPanel = new JPanel(new FlowLayout());
        inputPanel.add(new JLabel("库存阈值:"));
        JTextField thresholdField = new JTextField("10", 10);
        inputPanel.add(thresholdField);
        JButton queryButton = new JButton("查询");
        inputPanel.add(queryButton);

        // 表格区域
        String[] columnNames = {"物料ID", "物料编码", "物料名称", "规格", "单位", "当前库存", "最低库存"};
        DefaultTableModel lowStockTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // 所有单元格不可编辑
            }
        };

        JTable lowStockTable = new JTable(lowStockTableModel);
        JScrollPane tableScrollPane = new JScrollPane(lowStockTable);

        // 设置表格列宽
        lowStockTable.getColumnModel().getColumn(0).setPreferredWidth(50);    // ID
        lowStockTable.getColumnModel().getColumn(1).setPreferredWidth(100);   // 物料编码
        lowStockTable.getColumnModel().getColumn(2).setPreferredWidth(150);   // 物料名称
        lowStockTable.getColumnModel().getColumn(3).setPreferredWidth(100);   // 规格
        lowStockTable.getColumnModel().getColumn(4).setPreferredWidth(60);    // 单位
        lowStockTable.getColumnModel().getColumn(5).setPreferredWidth(100);   // 当前库存
        lowStockTable.getColumnModel().getColumn(6).setPreferredWidth(80);    // 最低库存

        // 添加到表单面板
        formPanel.add(inputPanel, BorderLayout.NORTH);
        formPanel.add(tableScrollPane, BorderLayout.CENTER);

        // 查询按钮事件
        queryButton.addActionListener(e -> {
            try {
                String thresholdStr = thresholdField.getText().trim();
                if (thresholdStr.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "请输入库存阈值", "提示", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }

                BigDecimal threshold = new BigDecimal(thresholdStr);

                // 构建请求URL
                String url = SERVER_URL + "/inventories/low-stock?threshold=" + threshold;
                System.out.println("正在请求带阈值的低库存数据，URL: " + url);

                // 发送请求获取低库存列表
                String response = HttpClientUtilNew.getJson(url);

                // 解析响应
                System.out.println("服务器原始响应: " + response);
                Map<String, Object> result = objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});

                if (Boolean.TRUE.equals(result.get("success"))) {
                    List<Map<String, Object>> lowStockList = (List<Map<String, Object>>) result.get("data");

                    // 调试：打印第一个数据项的键
                    if (lowStockList != null && !lowStockList.isEmpty()) {
                        Map<String, Object> firstItem = lowStockList.get(0);
                        System.out.println("服务器返回的字段: " + firstItem.keySet());
                        System.out.println("完整数据项: " + firstItem);
                    }

                    // 清空表格
                    lowStockTableModel.setRowCount(0);

                    // 添加数据到表格
                    if (lowStockList != null) {
                        for (Map<String, Object> inventory : lowStockList) {
                            Object[] row = {
                                    inventory.get("materialId"),
                                    inventory.get("materialCode"),
                                    inventory.get("materialName"),
                                    inventory.get("specification"),
                                    inventory.get("unit"),
                                    inventory.get("quantity"),
                                    inventory.get("min_stock") != null ? inventory.get("min_stock") : (inventory.get("minStock") != null ? inventory.get("minStock") : 0)
                            };

                            // 添加调试信息
                            System.out.println("表格行数据: " + java.util.Arrays.toString(row));

                            lowStockTableModel.addRow(row);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(dialog, "获取低库存列表失败: " + result.get("message"), "错误", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(dialog, "获取低库存列表失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            }
        });

        // 添加关闭按钮
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton closeButton = new JButton("关闭");
        closeButton.addActionListener(e -> dialog.dispose());
        buttonPanel.add(closeButton);

        // 添加到对话框
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);

        // 显示对话框
        dialog.setVisible(true);
    }

    /**
     * 格式化数字值，处理各种可能的数字类型
     * @param value 需要格式化的值
     * @return 格式化后的字符串
     */
    private String formatNumberValue(Object value) {
        if (value == null) {
            return "";
        }

        try {
            if (value instanceof Number) {
                return decimalFormat.format(value);
            } else if (value instanceof String) {
                // 直接返回字符串值，不做数字转换
                String strValue = (String) value;
                if (strValue == null || strValue.trim().isEmpty()) {
                    return "";
                }
                return strValue;
            } else {
                return value.toString(); // 其他类型转换为字符串
            }
        } catch (Exception e) {
            return value.toString(); // 出现异常时返回原始值的字符串表示
        }
    }

    /**
     * 格式化日期时间
     */
    private String formatDateTime(Object dateTimeObj) {
        if (dateTimeObj == null) {
            return "";
        }

        try {
            return dateTimeObj.toString();
        } catch (Exception e) {
            return "";
        }
    }
}