package com.class2.seat27.client.http;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PermissionHttpClient {
    private static final String BASE_URL = "http://localhost:8081/api/permissions";
    private static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 获取所有权限资源
     */
    public static Map<String, Object> getAllPermissions() throws Exception {
        String url = BASE_URL + "/all";
        String response = HttpClientUtil.getJson(url);
        return objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});
    }

    /**
     * 获取用户的完整权限信息
     */
    public static Map<String, Object> getUserPermissions(Long userId) throws Exception {
        String url = BASE_URL + "/user/" + userId;
        String response = HttpClientUtil.getJson(url);
        return objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});
    }

    /**
     * 更新用户权限
     */
    public static Map<String, Object> updateUserPermissions(Long userId, Map<String, Boolean> permissions, String updateUser) throws Exception {
        String url = BASE_URL + "/user/" + userId + "/update";

        Map<String, Object> requestData = new HashMap<>();
        requestData.put("permissions", permissions);
        requestData.put("updateUser", updateUser);

        String response = HttpClientUtil.postJson(url, requestData);
        return objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});
    }

    /**
     * 检查用户权限
     */
    public static Map<String, Object> checkPermission(Long userId, String resourceCode) throws Exception {
        String url = BASE_URL + "/user/" + userId + "/check/" + resourceCode;
        String response = HttpClientUtil.getJson(url);
        return objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});
    }

    /**
     * 重置用户权限
     */
    public static Map<String, Object> resetUserPermissions(Long userId) throws Exception {
        String url = BASE_URL + "/user/" + userId + "/reset";
        Map<String, Object> emptyData = new HashMap<>();
        String response = HttpClientUtil.postJson(url, emptyData);
        return objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});
    }

    /**
     * 获取用户有权限的菜单
     */
    public static Map<String, Object> getUserMenus(Long userId) throws Exception {
        String url = BASE_URL + "/user/" + userId + "/menus";
        String response = HttpClientUtil.getJson(url);
        return objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});
    }
}