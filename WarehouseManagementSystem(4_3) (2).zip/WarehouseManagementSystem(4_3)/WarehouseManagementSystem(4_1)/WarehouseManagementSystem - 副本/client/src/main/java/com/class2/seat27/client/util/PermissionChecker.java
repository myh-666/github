package com.class2.seat27.client.util;

import com.class2.seat27.client.http.PermissionHttpClient;

import java.util.Map;

/**
 * 权限检查工具类
 */
public class PermissionChecker {

    /**
     * 检查用户权限
     * @param userId 用户ID
     * @param userRole 用户角色
     * @param resourceCode 资源代码
     * @return 是否有权限
     */
    public static boolean checkPermission(Long userId, String userRole, String resourceCode) {
        try {
            // 管理员默认拥有所有权限
            if ("ADMIN".equals(userRole)) {
                return true;
            }

            Map<String, Object> result = PermissionHttpClient.checkPermission(userId, resourceCode);
            return Boolean.TRUE.equals(result.get("hasPermission"));
        } catch (Exception e) {
            System.err.println("权限检查失败: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 检查多个权限（只要有一个权限就返回true）
     */
    public static boolean checkAnyPermission(Long userId, String userRole, String... resourceCodes) {
        for (String resourceCode : resourceCodes) {
            if (checkPermission(userId, userRole, resourceCode)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 检查所有权限（必须拥有所有权限）
     */
    public static boolean checkAllPermissions(Long userId, String userRole, String... resourceCodes) {
        for (String resourceCode : resourceCodes) {
            if (!checkPermission(userId, userRole, resourceCode)) {
                return false;
            }
        }
        return true;
    }
}