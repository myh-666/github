package com.class2.seat27.client;

import com.class2.seat27.client.http.HttpClientUtilNew;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

/**
 * 多物料进出仓面板类
 * 用于多物料进出仓操作，可以作为面板嵌入到其他容器中
 */
public class MultiInOutPanel extends JPanel {
    private JTextField documentCodeField;
    private JTextArea remarkArea;
    private JButton confirmButton;
    private JButton addButton;
    private JButton deleteButton;
    private JButton backButton;
    private JTable detailTable;
    private DefaultTableModel detailTableModel;

    private List<Map<String, Object>> detailList;
    private Map<String, Object> selectedDetail;
    private String operationType;
    private MainFrame parentFrame;
    private String currentUser;
    private String personnelCode;
    private boolean isInbound;

    private static final DecimalFormat quantityFormat = new DecimalFormat("#0");
    private static final DecimalFormat priceFormat = new DecimalFormat("#0.00");

    public MultiInOutPanel(MainFrame parentFrame, String currentUser, String personnelCode, String operationType) {
        this.parentFrame = parentFrame;
        this.currentUser = currentUser;
        this.personnelCode = personnelCode;
        this.operationType = operationType;
        this.isInbound = "IN".equals(operationType) || "INBOUND".equals(operationType);
        this.detailList = new ArrayList<>();

        initializeComponents();
        setupLayout();
        setupListeners();
    }

    private void initializeComponents() {
        // 初始化组件
        documentCodeField = new JTextField(20);
        remarkArea = new JTextArea(3, 20);
        remarkArea.setLineWrap(true);
        remarkArea.setWrapStyleWord(true);

        // 根据进出仓类型设置不同的按钮文本和颜色
        String confirmText = isInbound ? "创建进仓单" : "创建出仓单";
        Color confirmColor = isInbound ? new Color(0, 100, 0) : new Color(100, 0, 0); // 进仓绿色，出仓红色

        confirmButton = new JButton(confirmText);
        confirmButton.setForeground(confirmColor);
        addButton = new JButton("添加物料");
        deleteButton = new JButton("删除物料");
        backButton = new JButton("返回主页");

        // 创建表格模型
        String[] columnNames = {"物料编码", "物料名称", "规格", "单位", "数量", "单价", "总价", "备注"};
        detailTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // 所有单元格不可编辑
            }
        };

        // 创建表格
        detailTable = new JTable(detailTableModel);
        detailTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        detailTable.getTableHeader().setReorderingAllowed(false);
        detailTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 1) {
                    int selectedRow = detailTable.getSelectedRow();
                    if (selectedRow >= 0 && selectedRow < detailList.size()) {
                        selectedDetail = detailList.get(selectedRow);
                    }
                }
            }
        });

        // 设置表格滚动面板
        JScrollPane tableScrollPane = new JScrollPane(detailTable);
        tableScrollPane.setPreferredSize(new Dimension(800, 300));
    }

    private void setupLayout() {
        setLayout(new BorderLayout());
        setBorder(new EmptyBorder(10, 10, 10, 10));

        // 顶部面板
        JPanel topPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        // 根据进出仓类型设置不同的标题和颜色
        String title = isInbound ? "多物料进仓单" : "多物料出仓单";
        Color titleColor = isInbound ? new Color(0, 100, 0) : new Color(100, 0, 0); // 进仓绿色，出仓红色

        // 添加标题标签
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("宋体", Font.BOLD, 16));
        titleLabel.setForeground(titleColor);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        topPanel.add(titleLabel, gbc);

        // 单据编号
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        topPanel.add(new JLabel("单据编号:"), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        topPanel.add(documentCodeField, gbc);

        // 自动生成单据编号
        String prefix = isInbound ? "MIN" : "MOUT";
        documentCodeField.setText(prefix + System.currentTimeMillis());
        documentCodeField.setEditable(false);

        // 备注
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.fill = GridBagConstraints.NONE;
        topPanel.add(new JLabel("备注:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.fill = GridBagConstraints.BOTH;
        JScrollPane remarkScrollPane = new JScrollPane(remarkArea);
        remarkScrollPane.setPreferredSize(new Dimension(300, 60));
        topPanel.add(remarkScrollPane, gbc);

        // 按钮面板
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(confirmButton);
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(backButton);

        // 底部面板
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(buttonPanel, BorderLayout.NORTH);

        // 添加到主面板
        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(detailTable), BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void setupListeners() {
        // 添加物料按钮
        addButton.addActionListener(e -> {
            MaterialSelectDialog dialog = new MaterialSelectDialog(parentFrame, currentUser);
            dialog.setVisible(true);

            Map<String, Object> selectedMaterial = dialog.getSelectedMaterial();
            if (selectedMaterial != null) {
                try {
                    // 获取物料单价
                    BigDecimal unitPrice = getMaterialPrice(selectedMaterial.get("id"));

                    // 创建物料明细对话框，传入单价
                    MaterialDetailDialog detailDialog = new MaterialDetailDialog(parentFrame, selectedMaterial, unitPrice);
                    detailDialog.setVisible(true);

                    Map<String, Object> detail = detailDialog.getDetail();
                    if (detail != null) {
                        // 添加到明细列表
                        detailList.add(detail);
                        updateDetailTable();
                        // 刷新库存数据，确保显示最新的库存信息
                        InventoryRefreshUtil.refreshAllInventoryFrames(parentFrame);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "获取物料信息失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // 删除物料按钮
        deleteButton.addActionListener(e -> {
            int selectedRow = detailTable.getSelectedRow();
            if (selectedRow >= 0 && selectedRow < detailList.size()) {
                detailList.remove(selectedRow);
                updateDetailTable();
                // 刷新库存数据，确保显示最新的库存信息
                InventoryRefreshUtil.refreshAllInventoryFrames(parentFrame);
            } else {
                JOptionPane.showMessageDialog(this, "请选择要删除的物料", "提示", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        // 确认单据按钮
        confirmButton.addActionListener(e -> {
            if (detailList.isEmpty()) {
                JOptionPane.showMessageDialog(this, "请添加至少一个物料", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                // 构建请求参数
                Map<String, Object> document = new HashMap<>();
                document.put("documentCode", documentCodeField.getText());
                document.put("remark", remarkArea.getText());

                Map<String, Object> request = new HashMap<>();
                request.put("username", currentUser); // 添加username参数
                System.out.println("传递给服务端的用户名: " + currentUser); // 添加调试信息
                System.out.println("传递给服务端的personnel_code: " + personnelCode); // 添加调试信息

                // 根据进出仓类型使用不同的请求格式
                if (isInbound) {
                    // 进仓请求格式
                    request.put("personnel_code", personnelCode);
                    request.put("document", document);
                    request.put("operationType", "INBOUND");
                } else {
                    // 出仓请求格式
                    request.put("personnel_code", personnelCode);
                    request.put("document", document);
                    request.put("operationType", "OUTBOUND");
                }

                // 根据进出仓类型处理明细数据
                List<Map<String, Object>> processedDetails = new ArrayList<>();
                for (Map<String, Object> detail : detailList) {
                    Map<String, Object> processedDetail = new HashMap<>(detail);

                    // 确保materialId是字符串类型
                    Object materialId = detail.get("materialId");
                    if (materialId != null) {
                        processedDetail.put("materialId", materialId.toString());
                    }

                    // 根据进出仓类型添加特定字段
                    if (isInbound) {
                        // 进仓特有处理 - 进仓不需要检查库存
                        processedDetail.put("type", "INBOUND");
                        // 进仓只需要确保数量为正数
                        Object quantityObj = detail.get("quantity");
                        if (quantityObj != null) {
                            try {
                                BigDecimal quantity = new BigDecimal(quantityObj.toString());
                                if (quantity.compareTo(BigDecimal.ZERO) <= 0) {
                                    JOptionPane.showMessageDialog(this,
                                        "物料 " + detail.get("materialName") + " 数量必须大于0",
                                        "数量错误", JOptionPane.WARNING_MESSAGE);
                                    return;
                                }
                                System.out.println("进仓物料: " + detail.get("materialName") + ", 数量: " + quantity);
                                // 进仓操作不需要检查库存，直接处理
                                System.out.println("进仓操作不检查库存，直接处理");
                            } catch (Exception ex2) {
                                System.err.println("处理数量时出错: " + ex2.getMessage());
                                JOptionPane.showMessageDialog(this,
                                    "处理物料数量时出错: " + ex2.getMessage(),
                                    "错误", JOptionPane.ERROR_MESSAGE);
                                return;
                            }
                        }
                    } else {
                        // 出仓特有处理 - 出仓需要检查库存
                        processedDetail.put("type", "OUTBOUND");
                        // 出仓需要检查库存是否充足
                        Object quantityObj = detail.get("quantity");
                        if (quantityObj != null) {
                            try {
                                BigDecimal quantity = new BigDecimal(quantityObj.toString());
                                Object materialIdObj = detail.get("materialId");
                                if (quantity.compareTo(BigDecimal.ZERO) <= 0) {
                                    JOptionPane.showMessageDialog(this,
                                        "物料 " + detail.get("materialName") + " 数量必须大于0",
                                        "数量错误", JOptionPane.WARNING_MESSAGE);
                                    return;
                                }
                                System.out.println("出仓物料: " + detail.get("materialName") + ", 数量: " + quantity); // 添加调试信息
                                // 只有出仓操作才需要检查库存
                                if (materialIdObj != null) {
                                    Long materialIdLong = Long.parseLong(materialIdObj.toString());
                                    int requiredQuantity = quantity.intValue();

                                    // 添加更详细的调试信息
                                    System.out.println("检查库存 - 物料ID: " + materialIdLong + ", 需要数量: " + requiredQuantity);

                                    // 调用库存检查
                                    boolean inventorySufficient = checkInventory(materialIdLong, requiredQuantity);
                                    System.out.println("库存是否充足: " + inventorySufficient);

                                    if (!inventorySufficient) {
                                        // 获取当前库存数量以提供更详细的错误信息
                                        try {
                                            String currentStockUrl = "http://localhost:8081/api/warehouse/inventory/current?materialId=" + materialIdLong;
                                            String stockResponse = HttpClientUtilNew.getJson(currentStockUrl);
                                            Map<String, Object> stockResult = JSONParserHelper.parseJson(stockResponse, Map.class);

                                            String stockMessage = "库存不足";
                                            if (stockResult != null && Boolean.TRUE.equals(stockResult.get("success"))) {
                                                Object currentStockObj = stockResult.get("quantity");
                                                if (currentStockObj != null) {
                                                    stockMessage = "库存不足，当前库存: " + currentStockObj.toString() + "，需要: " + requiredQuantity;
                                                }
                                            }

                                            JOptionPane.showMessageDialog(this,
                                                "物料 " + detail.get("materialName") + " " + stockMessage,
                                                "库存不足", JOptionPane.WARNING_MESSAGE);
                                        } catch (Exception stockEx) {
                                            System.err.println("获取当前库存失败: " + stockEx.getMessage());
                                            JOptionPane.showMessageDialog(this,
                                                "物料 " + detail.get("materialName") + " 库存不足，无法完成出仓操作",
                                                "库存不足", JOptionPane.WARNING_MESSAGE);
                                        }
                                        return;
                                    }
                                }
                            } catch (NumberFormatException ex) {
                                System.err.println("物料ID格式错误: " + ex.getMessage());
                                JOptionPane.showMessageDialog(this,
                                    "物料ID格式错误，请检查物料信息",
                                    "数据错误", JOptionPane.ERROR_MESSAGE);
                                return;
                            } catch (Exception ex2) {
                                System.err.println("检查库存时出错: " + ex2.getMessage());
                                ex2.printStackTrace();
                                JOptionPane.showMessageDialog(this,
                                    "检查库存时出错: " + ex2.getMessage(),
                                    "错误", JOptionPane.ERROR_MESSAGE);
                                return;
                            }
                        }
                    }

                    processedDetails.add(processedDetail);
                }

                request.put("details", processedDetails);
                System.out.println("请求数据: " + request); // 添加调试信息

                // 发送请求，直接创建并完成进出仓操作
                String url = isInbound ?
                    "http://localhost:8081/api/multi-inout/inbound/create" :
                    "http://localhost:8081/api/multi-inout/outbound/create";

                String responseStr = HttpClientUtilNew.postJson(url, request);
                System.out.println("服务器原始响应: " + responseStr); // 添加调试信息
                Map<String, Object> response = JSONParserHelper.parseJson(responseStr, Map.class);

                if (response != null && (boolean) response.get("success")) {
                    // 根据进出仓类型显示不同的成功消息
                    String successTitle = isInbound ? "进仓完成" : "出仓完成";
                    String successMessage = isInbound ?
                        "进仓操作已完成，库存已更新" :
                        "出仓操作已完成，库存已更新";
                    JOptionPane.showMessageDialog(this, successMessage, successTitle, JOptionPane.INFORMATION_MESSAGE);

                    // 清空表单
                    clearForm();

                    // 刷新库存数据
                    InventoryRefreshUtil.refreshAllInventoryFrames(parentFrame);
                    // 刷新进出仓查询数据
                    InventoryRefreshUtil.refreshAllInOutQueryFrames(parentFrame);
                } else {
                    JOptionPane.showMessageDialog(this, response.get("message").toString(), "失败", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "操作失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            }
        });

        // 返回主页按钮
        backButton.addActionListener(e -> {
            // 获取父窗口
            Container parent = this.getParent();
            while (parent != null && !(parent instanceof JFrame)) {
                parent = parent.getParent();
            }

            if (parent instanceof JFrame) {
                // 关闭当前窗口
                ((JFrame) parent).dispose();
                // 显示主窗口
                parentFrame.setVisible(true);
            }
        });
    }
    private void updateDetailTable() {
        // 清空表格
        detailTableModel.setRowCount(0);

        // 添加明细数据
        for (Map<String, Object> detail : detailList) {
            Object[] row = {
                detail.get("materialCode"),
                detail.get("materialName"),
                detail.get("specification"),
                detail.get("unit"),
                quantityFormat.format(detail.get("quantity")),
                priceFormat.format(detail.get("unitPrice")),
                priceFormat.format(detail.get("totalPrice")),
                detail.get("remark")
            };
            detailTableModel.addRow(row);
        }
    }

    private void clearForm() {
        // 生成新的单据编号
        String prefix = isInbound ? "MIN" : "MOUT";
        documentCodeField.setText(prefix + System.currentTimeMillis());

        // 清空备注
        remarkArea.setText("");

        // 清空明细列表
        detailList.clear();
        updateDetailTable();
    }

    /**
     * 获取物料单价
     * @param materialId 物料ID
     * @return 物料单价
     */
    private BigDecimal getMaterialPrice(Object materialId) {
        try {
            // 调用服务端API获取物料单价
            Map<String, Object> request = new HashMap<>();

            // 确保materialId不为null
            if (materialId == null) {
                throw new RuntimeException("物料ID不能为空");
            }

            System.out.println("获取物料单价，物料ID: " + materialId + ", 类型: " + materialId.getClass().getName());

            // 确保materialId是字符串类型
            String materialIdStr = materialId.toString();
            request.put("materialId", materialIdStr);

            String url = "http://localhost:8081/api/warehouse/material/price?materialId=" + materialIdStr;
            String response = HttpClientUtilNew.getJson(url);
            System.out.println("服务端响应: " + response); // 添加调试信息

            Map<String, Object> result = JSONParserHelper.parseJson(response, Map.class);
            System.out.println("解析后的结果: " + result); // 添加调试信息

            if (Boolean.TRUE.equals(result.get("success"))) {
                Object priceObj = result.get("price");
                System.out.println("价格对象: " + priceObj); // 添加调试信息
                if (priceObj == null) {
                    System.out.println("价格对象为null，使用默认值0"); // 添加调试信息
                    return BigDecimal.ZERO;
                }
                return new BigDecimal(priceObj.toString());
            } else {
                Object messageObj = result.get("message");
                String message = messageObj != null ? messageObj.toString() : "未知错误";
                throw new RuntimeException(message);
            }
        } catch (Exception ex) {
            throw new RuntimeException("获取物料单价失败: " + ex.getMessage());
        }
    }

    /**
     * 检查库存是否足够
     * @param materialId 物料ID
     * @param requiredQuantity 需要的数量
     * @return 库存是否足够
     */
    private boolean checkInventory(Long materialId, int requiredQuantity) {
        try {
            // 调用服务端API检查库存
            String url = "http://localhost:8081/api/warehouse/inventory/check?materialId=" + materialId + "&quantity=" + requiredQuantity;
            String response = HttpClientUtilNew.getJson(url);
            System.out.println("检查库存响应: " + response); // 添加调试信息

            if (response == null || response.trim().isEmpty()) {
                System.err.println("服务端返回空响应，默认为库存不足");
                return false;
            }

            Map<String, Object> result = JSONParserHelper.parseJson(response, Map.class);
            System.out.println("检查库存结果: " + result); // 添加调试信息

            if (result == null) {
                System.err.println("解析响应失败，结果为null，默认为库存不足");
                return false;
            }

            // 检查服务端是否成功处理请求
            boolean success = Boolean.TRUE.equals(result.get("success"));
            System.out.println("服务端处理是否成功: " + success);

            // 获取库存是否充足的标志
            Boolean sufficient = (Boolean) result.get("sufficient");
            if (sufficient == null) {
                System.err.println("服务端未返回sufficient字段，默认为库存不足");
                return false;
            }

            System.out.println("库存是否充足: " + sufficient); // 添加调试信息
            return sufficient;
        } catch (Exception e) {
            System.err.println("检查库存失败: " + e.getMessage());
            e.printStackTrace(); // 添加异常堆栈
            return false;
        }
    }
}