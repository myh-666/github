package com.class2.seat27.client.personnel;

import com.class2.seat27.client.http.PersonnelHttpClient;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import java.util.Map;

public class QueryPersonnelFrame extends JFrame {
    private JTextField searchField;
    private JComboBox<String> searchTypeComboBox;
    private JButton searchButton;
    private JButton refreshButton;
    private JTable personnelTable;
    private DefaultTableModel tableModel;

    // 操作按钮
    private JButton viewButton;
    private JButton modifyButton;
    private JButton deleteButton;

    private Long selectedPersonnelId;
    private String selectedPersonnelName;

    private ObjectMapper objectMapper = new ObjectMapper();

    public QueryPersonnelFrame() {
        initComponents();
        setupLayout();
        setupListeners();
        // 不再自动加载所有人员，只显示表头
        initializeTable();
        updateButtonsState(false); // 初始时禁用操作按钮
    }

    private void initComponents() {
        setTitle("2_17_01人员管理");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1000, 600);
        setLocationRelativeTo(null);

        searchTypeComboBox = new JComboBox<>(new String[]{"人员代码", "姓名"});
        searchField = new JTextField(20);
        searchButton = new JButton("搜索");
        refreshButton = new JButton("刷新");

        // 初始化操作按钮
        viewButton = new JButton("查看详情");
        modifyButton = new JButton("修改");
        deleteButton = new JButton("删除");

        // 创建表格模型
        String[] columnNames = {"ID", "人员代码", "姓名", "性别", "出生日期", "联系电话"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // 所有单元格都不可编辑
            }
        };

        personnelTable = new JTable(tableModel);
        personnelTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        personnelTable.setRowHeight(30);

        // 设置表格列宽
        personnelTable.getColumnModel().getColumn(0).setPreferredWidth(50);   // ID
        personnelTable.getColumnModel().getColumn(1).setPreferredWidth(100);  // 人员代码
        personnelTable.getColumnModel().getColumn(2).setPreferredWidth(80);   // 姓名
        personnelTable.getColumnModel().getColumn(3).setPreferredWidth(50);   // 性别
        personnelTable.getColumnModel().getColumn(4).setPreferredWidth(100);  // 出生日期
        personnelTable.getColumnModel().getColumn(5).setPreferredWidth(100);  // 联系电话
    }

    private void setupLayout() {
        setLayout(new BorderLayout(10, 10));

        // 搜索面板 - 顶部
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.add(new JLabel("搜索类型:"));
        searchPanel.add(searchTypeComboBox);
        searchPanel.add(new JLabel("搜索条件:"));
        searchPanel.add(searchField);
        searchButton.setPreferredSize(new Dimension(80, 25));
        searchPanel.add(searchButton);
        refreshButton.setPreferredSize(new Dimension(80, 25));
        searchPanel.add(refreshButton);

        // 操作按钮面板 - 左下角
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        viewButton.setPreferredSize(new Dimension(100, 30));
        modifyButton.setPreferredSize(new Dimension(80, 30));
        deleteButton.setPreferredSize(new Dimension(80, 30));

        buttonPanel.add(viewButton);
        buttonPanel.add(modifyButton);
        buttonPanel.add(deleteButton);

        // 操作说明
        JPanel instructionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel instructionLabel = new JLabel("操作说明: 请输入搜索条件查询人员，然后在表格中选择人员后使用下方按钮进行操作");
        instructionLabel.setForeground(Color.BLUE);
        instructionLabel.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        instructionPanel.add(instructionLabel);

        // 主面板布局
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(searchPanel, BorderLayout.NORTH);
        mainPanel.add(new JScrollPane(personnelTable), BorderLayout.CENTER);

        // 底部面板包含操作按钮和说明
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(buttonPanel, BorderLayout.WEST);
        bottomPanel.add(instructionPanel, BorderLayout.CENTER);

        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel, BorderLayout.CENTER);
    }

    private void setupListeners() {
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                searchPersonnel();
            }
        });

        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 刷新时清空搜索条件和表格
                searchField.setText("");
                tableModel.setRowCount(0);
                selectedPersonnelId = null;
                selectedPersonnelName = null;
                updateButtonsState(false);
            }
        });

        // 表格选择监听
        personnelTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int selectedRow = personnelTable.getSelectedRow();
                if (selectedRow >= 0) {
                    // 获取选中行的人员信息
                    Object idObj = tableModel.getValueAt(selectedRow, 0);
                    selectedPersonnelId = convertToLong(idObj);
                    selectedPersonnelName = (String) tableModel.getValueAt(selectedRow, 2);
                    updateButtonsState(true);
                }
            }
        });

        // 操作按钮监听
        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (selectedPersonnelId != null) {
                    viewPersonnelDetails(selectedPersonnelId, selectedPersonnelName);
                }
            }
        });

        modifyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (selectedPersonnelId != null) {
                    modifyPersonnel(selectedPersonnelId);
                }
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (selectedPersonnelId != null) {
                    deletePersonnel(selectedPersonnelId, selectedPersonnelName);
                }
            }
        });
    }

    private void updateButtonsState(boolean enabled) {
        viewButton.setEnabled(enabled);
        modifyButton.setEnabled(enabled);
        deleteButton.setEnabled(enabled);
    }

    private void initializeTable() {
        // 只显示表头，不加载数据
        tableModel.setRowCount(0);
    }

    private void searchPersonnel() {
        String searchType = (String) searchTypeComboBox.getSelectedItem();
        String searchValue = searchField.getText().trim();

        try {
            Map<String, Object> result;

            if (searchValue.isEmpty()) {
                // 如果搜索条件为空，获取所有人员
                result = PersonnelHttpClient.getAllPersonnel();
            } else {
                if ("姓名".equals(searchType)) {
                    // 按姓名搜索
                    result = PersonnelHttpClient.searchPersonnelByName(searchValue);
                } else {
                    // 按人员代码搜索
                    result = PersonnelHttpClient.getPersonnelByCode(searchValue);
                    // 注意：这里需要调整API调用，因为原API是按代码精确查询
                }
            }

            if (Boolean.TRUE.equals(result.get("success"))) {
                List<Map<String, Object>> personnelList = (List<Map<String, Object>>) result.get("data");
                updateTable(personnelList);
                // 清除选择状态
                selectedPersonnelId = null;
                selectedPersonnelName = null;
                updateButtonsState(false);

                if (searchValue.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "加载全部 " + personnelList.size() + " 条记录", "查询结果", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "找到 " + personnelList.size() + " 条记录", "搜索结果", JOptionPane.INFORMATION_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "查询失败: " + result.get("message"), "错误", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "查询失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private void updateTable(List<Map<String, Object>> personnelList) {
        tableModel.setRowCount(0);
        for (Map<String, Object> person : personnelList) {
            // 获取人员数据 - 处理 ID 的类型转换
            Object idObj = person.get("id");
            Long id = convertToLong(idObj);

            Object personnelCode = person.get("personnelCode");
            Object name = person.get("name");
            Object gender = person.get("gender");
            Object birthDate = person.get("birthDate");
            Object phone = person.get("phone");

            Object[] rowData = {
                    id,
                    personnelCode,
                    name,
                    gender,
                    birthDate,
                    phone
            };
            tableModel.addRow(rowData);
        }
    }

    private void viewPersonnelDetails(Long personnelId, String personnelName) {
        try {
            Map<String, Object> result = PersonnelHttpClient.getPersonnelById(personnelId);
            if (Boolean.TRUE.equals(result.get("success"))) {
                Map<String, Object> userData = (Map<String, Object>) result.get("data");
                showPersonnelDetailsDialog(userData, personnelName);
            } else {
                JOptionPane.showMessageDialog(this, "获取人员详情失败: " + result.get("message"), "错误", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "获取人员详情失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private void showPersonnelDetailsDialog(Map<String, Object> userData, String personnelName) {
        StringBuilder details = new StringBuilder();
        details.append("=== 人员详细信息 ===\n\n");
        details.append("人员代码: ").append(userData.get("personnelCode")).append("\n");
        details.append("姓名: ").append(userData.get("name")).append("\n");
        details.append("性别: ").append(userData.get("gender")).append("\n");
        details.append("出生日期: ").append(userData.get("birthDate")).append("\n");
        details.append("身份证号: ").append(userData.get("idCard")).append("\n");
        details.append("籍贯: ").append(userData.get("nativePlace")).append("\n");
        details.append("家庭住址: ").append(userData.get("address")).append("\n");
        details.append("联系电话: ").append(userData.get("phone")).append("\n");
        details.append("其他情况: ").append(userData.get("otherInfo")).append("\n");

        JTextArea textArea = new JTextArea(details.toString(), 15, 40);
        textArea.setEditable(false);
        textArea.setFont(new Font("微软雅黑", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(textArea);
        JOptionPane.showMessageDialog(this, scrollPane, "人员详情 - " + personnelName, JOptionPane.INFORMATION_MESSAGE);
    }

    private void modifyPersonnel(Long personnelId) {
        // 打开修改窗口
        ModifyPersonnelFrame modifyFrame = new ModifyPersonnelFrame(personnelId);
        modifyFrame.setVisible(true);

        // 修改完成后刷新列表
        modifyFrame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent e) {
                // 重新执行当前搜索
                searchPersonnel();
            }
        });
    }

    private void deletePersonnel(Long personnelId, String personnelName) {
        int confirm = JOptionPane.showConfirmDialog(this,
                "确认删除人员 '" + personnelName + "'？\n此操作不可恢复！",
                "确认删除", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                Map<String, Object> result = PersonnelHttpClient.deletePersonnel(personnelId);
                if (Boolean.TRUE.equals(result.get("success"))) {
                    JOptionPane.showMessageDialog(this, "人员删除成功", "成功", JOptionPane.INFORMATION_MESSAGE);
                    // 重新执行当前搜索
                    searchPersonnel();
                } else {
                    JOptionPane.showMessageDialog(this, result.get("message"), "错误", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "删除失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        }
    }

    // 类型转换辅助方法
    private Long convertToLong(Object idObj) {
        if (idObj == null) {
            return null;
        }
        if (idObj instanceof Integer) {
            return ((Integer) idObj).longValue();
        } else if (idObj instanceof Long) {
            return (Long) idObj;
        } else if (idObj instanceof String) {
            return Long.parseLong((String) idObj);
        } else {
            throw new IllegalArgumentException("无法转换类型: " + idObj.getClass().getName());
        }
    }
}