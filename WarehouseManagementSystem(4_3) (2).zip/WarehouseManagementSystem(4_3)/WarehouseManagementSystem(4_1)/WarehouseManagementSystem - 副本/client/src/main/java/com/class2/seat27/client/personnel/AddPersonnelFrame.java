package com.class2.seat27.client.personnel;

import com.class2.seat27.client.http.PersonnelHttpClient;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class AddPersonnelFrame extends JFrame {
    private JTextField nameField;
    private JRadioButton maleRadioButton;
    private JRadioButton femaleRadioButton;
    private ButtonGroup genderGroup;
    private JTextField birthDateField;
    private JButton datePickerButton;
    private JTextField idCardField;
    private JTextField nativePlaceField;
    private JTextField addressField;
    private JTextField phoneField;
    private JTextArea otherInfoArea;
    private JButton submitButton;
    private JButton cancelButton;

    private ObjectMapper objectMapper = new ObjectMapper();
    private DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    // 身份证号码正则验证
    private static final Pattern ID_CARD_PATTERN = Pattern.compile("^[1-9]\\d{5}(18|19|20)\\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$");

    public AddPersonnelFrame() {
        initComponents();
        setupLayout();
        setupListeners();
    }

    private void initComponents() {
        setTitle("2_17_01增加人员");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(500, 650);
        setLocationRelativeTo(null);
        setResizable(false);

        nameField = new JTextField(20);

        // 使用单选按钮选择性别
        maleRadioButton = new JRadioButton("男");
        femaleRadioButton = new JRadioButton("女");
        genderGroup = new ButtonGroup();
        genderGroup.add(maleRadioButton);
        genderGroup.add(femaleRadioButton);
        maleRadioButton.setSelected(true); // 默认选择男

        // 使用日期选择器
        birthDateField = new JTextField(15);
        birthDateField.setEditable(false); // 禁止直接编辑
        datePickerButton = new JButton("选择日期");

        idCardField = new JTextField(20);
        nativePlaceField = new JTextField(20);
        addressField = new JTextField(20);
        phoneField = new JTextField(20);
        otherInfoArea = new JTextArea(5, 20);
        submitButton = new JButton("提交");
        cancelButton = new JButton("取消");

        // 设置身份证字段提示
        idCardField.setToolTipText("18位身份证号码，最后一位可以是数字或X");
    }

    private void setupLayout() {
        setLayout(new BorderLayout(10, 10));

        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // 标题
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel titleLabel = new JLabel("增加人员信息", JLabel.CENTER);
        titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 18));
        mainPanel.add(titleLabel, gbc);

        gbc.gridwidth = 1;
        gbc.gridy = 1;
        gbc.gridx = 0;
        mainPanel.add(new JLabel("姓名*:"), gbc);
        gbc.gridx = 1;
        mainPanel.add(nameField, gbc);

        gbc.gridy = 2;
        gbc.gridx = 0;
        mainPanel.add(new JLabel("性别*:"), gbc);
        gbc.gridx = 1;
        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        genderPanel.add(maleRadioButton);
        genderPanel.add(femaleRadioButton);
        mainPanel.add(genderPanel, gbc);

        gbc.gridy = 3;
        gbc.gridx = 0;
        mainPanel.add(new JLabel("出生日期*:"), gbc);
        gbc.gridx = 1;
        JPanel datePanel = new JPanel(new BorderLayout(5, 0));
        datePanel.add(birthDateField, BorderLayout.CENTER);
        datePanel.add(datePickerButton, BorderLayout.EAST);
        mainPanel.add(datePanel, gbc);

        gbc.gridy = 4;
        gbc.gridx = 0;
        mainPanel.add(new JLabel("身份证号*:"), gbc);
        gbc.gridx = 1;
        mainPanel.add(idCardField, gbc);

        gbc.gridy = 5;
        gbc.gridx = 0;
        mainPanel.add(new JLabel("籍贯:"), gbc);
        gbc.gridx = 1;
        mainPanel.add(nativePlaceField, gbc);

        gbc.gridy = 6;
        gbc.gridx = 0;
        mainPanel.add(new JLabel("家庭住址:"), gbc);
        gbc.gridx = 1;
        // 家庭住址使用更大的文本框
        addressField.setPreferredSize(new Dimension(200, 60));
        mainPanel.add(addressField, gbc);

        gbc.gridy = 7;
        gbc.gridx = 0;
        mainPanel.add(new JLabel("联系电话:"), gbc);
        gbc.gridx = 1;
        mainPanel.add(phoneField, gbc);

        gbc.gridy = 8;
        gbc.gridx = 0;
        mainPanel.add(new JLabel("其它情况:"), gbc);
        gbc.gridx = 1;
        mainPanel.add(new JScrollPane(otherInfoArea), gbc);

        // 按钮面板
        gbc.gridy = 9;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.add(submitButton);
        buttonPanel.add(cancelButton);
        mainPanel.add(buttonPanel, gbc);

        add(mainPanel, BorderLayout.CENTER);
    }

    private void setupListeners() {
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addPersonnel();
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        // 日期选择按钮监听
        datePickerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showDatePickerDialog();
            }
        });

        // 身份证号输入完成时自动验证与出生日期的一致性
        idCardField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                validateIdCardAndBirthDate();
            }
        });
    }

    /**
     * 显示日期选择对话框
     */
    private void showDatePickerDialog() {
        // 创建日期选择对话框
        JDialog dateDialog = new JDialog(this, "选择出生日期", true);
        dateDialog.setSize(300, 300);
        dateDialog.setLocationRelativeTo(this);
        dateDialog.setLayout(new BorderLayout());

        // 创建日历面板
        JPanel calendarPanel = createCalendarPanel();
        dateDialog.add(calendarPanel, BorderLayout.CENTER);

        dateDialog.setVisible(true);
    }

    /**
     * 创建日历面板
     */
    private JPanel createCalendarPanel() {
        JPanel mainPanel = new JPanel(new BorderLayout());

        // 获取当前日期
        LocalDate currentDate = LocalDate.now();
        LocalDate displayDate = currentDate.minusYears(20); // 默认显示20年前的日期

        // 创建日期选择器
        JSpinner yearSpinner = new JSpinner(new SpinnerNumberModel(displayDate.getYear(), 1900, currentDate.getYear(), 1));
        JSpinner monthSpinner = new JSpinner(new SpinnerNumberModel(displayDate.getMonthValue(), 1, 12, 1));

        JPanel controlPanel = new JPanel(new FlowLayout());
        controlPanel.add(new JLabel("年:"));
        controlPanel.add(yearSpinner);
        controlPanel.add(new JLabel("月:"));
        controlPanel.add(monthSpinner);

        // 创建日历网格
        JPanel calendarGrid = new JPanel(new GridLayout(0, 7));
        calendarGrid.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // 星期标题
        String[] weekDays = {"日", "一", "二", "三", "四", "五", "六"};
        for (String day : weekDays) {
            JLabel dayLabel = new JLabel(day, JLabel.CENTER);
            dayLabel.setFont(new Font("微软雅黑", Font.BOLD, 12));
            calendarGrid.add(dayLabel);
        }

        // 更新日历显示的方法
        Runnable updateCalendar = () -> {
            calendarGrid.removeAll();

            // 重新添加星期标题
            for (String day : weekDays) {
                JLabel dayLabel = new JLabel(day, JLabel.CENTER);
                dayLabel.setFont(new Font("微软雅黑", Font.BOLD, 12));
                calendarGrid.add(dayLabel);
            }

            int year = (Integer) yearSpinner.getValue();
            int month = (Integer) monthSpinner.getValue();

            LocalDate firstDayOfMonth = LocalDate.of(year, month, 1);
            int daysInMonth = firstDayOfMonth.lengthOfMonth();
            int startDayOfWeek = firstDayOfMonth.getDayOfWeek().getValue() % 7; // 0=周日, 1=周一, ..., 6=周六

            // 添加空白单元格
            for (int i = 0; i < startDayOfWeek; i++) {
                calendarGrid.add(new JLabel(""));
            }

            // 添加日期按钮
            for (int day = 1; day <= daysInMonth; day++) {
                final int selectedDay = day;
                JButton dayButton = new JButton(String.valueOf(day));
                dayButton.setFont(new Font("微软雅黑", Font.PLAIN, 12));
                dayButton.setMargin(new Insets(2, 2, 2, 2));

                dayButton.addActionListener(e -> {
                    String selectedDate = String.format("%d-%02d-%02d", year, month, selectedDay);
                    birthDateField.setText(selectedDate);
                    ((Window) SwingUtilities.getRoot(dayButton)).dispose();
                });

                calendarGrid.add(dayButton);
            }

            calendarGrid.revalidate();
            calendarGrid.repaint();
        };

        // 添加年份和月份变化的监听器
        yearSpinner.addChangeListener(e -> updateCalendar.run());
        monthSpinner.addChangeListener(e -> updateCalendar.run());

        // 初始更新日历
        updateCalendar.run();

        mainPanel.add(controlPanel, BorderLayout.NORTH);
        mainPanel.add(calendarGrid, BorderLayout.CENTER);

        return mainPanel;
    }

    /**
     * 验证身份证号和出生日期的一致性
     */
    private void validateIdCardAndBirthDate() {
        String idCard = idCardField.getText().trim();
        String birthDateStr = birthDateField.getText().trim();

        // 如果身份证号填写了，进行验证
        if (!idCard.isEmpty() && !birthDateStr.isEmpty()) {
            try {
                // 验证身份证格式
                if (!ID_CARD_PATTERN.matcher(idCard).matches()) {
                    return; // 身份证格式不正确，不进行日期一致性验证
                }

                // 从身份证中提取出生日期
                String idCardBirthDate = extractBirthDateFromIdCard(idCard);
                if (idCardBirthDate != null && !idCardBirthDate.equals(birthDateStr)) {
                    int option = JOptionPane.showConfirmDialog(
                            this,
                            "身份证中的出生日期 (" + idCardBirthDate + ") 与选择的出生日期 (" + birthDateStr + ") 不一致！\n是否使用身份证中的出生日期？",
                            "日期不一致",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.WARNING_MESSAGE
                    );

                    if (option == JOptionPane.YES_OPTION) {
                        birthDateField.setText(idCardBirthDate);
                    }
                }
            } catch (Exception ex) {
                // 验证过程中出现异常，忽略
            }
        }
    }

    /**
     * 从身份证号码中提取出生日期
     */
    private String extractBirthDateFromIdCard(String idCard) {
        if (idCard == null || idCard.length() != 18) {
            return null;
        }

        try {
            String year = idCard.substring(6, 10);  // 年份
            String month = idCard.substring(10, 12); // 月份
            String day = idCard.substring(12, 14);   // 日期

            return year + "-" + month + "-" + day;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 验证身份证号码格式
     */
    private boolean validateIdCardFormat(String idCard) {
        if (idCard == null || idCard.trim().isEmpty()) {
            return false; // 身份证号不能为空
        }

        return ID_CARD_PATTERN.matcher(idCard).matches();
    }

    private void addPersonnel() {
        String name = nameField.getText().trim();
        String birthDateStr = birthDateField.getText().trim();
        String idCard = idCardField.getText().trim();

        // 验证必填字段
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "姓名不能为空", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 验证出生日期
        if (birthDateStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "出生日期不能为空", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 验证身份证号码格式和必填
        if (idCard.isEmpty()) {
            JOptionPane.showMessageDialog(this, "身份证号不能为空", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!validateIdCardFormat(idCard)) {
            JOptionPane.showMessageDialog(this, "身份证号码格式不正确\n请检查是否为18位，最后一位可以是数字或X", "错误", JOptionPane.ERROR_MESSAGE);
            idCardField.requestFocus();
            return;
        }

        // 验证身份证号和出生日期的一致性
        if (!idCard.isEmpty() && !birthDateStr.isEmpty()) {
            String idCardBirthDate = extractBirthDateFromIdCard(idCard);
            if (idCardBirthDate != null && !idCardBirthDate.equals(birthDateStr)) {
                int option = JOptionPane.showConfirmDialog(
                        this,
                        "身份证中的出生日期 (" + idCardBirthDate + ") 与选择的出生日期 (" + birthDateStr + ") 不一致！\n是否继续提交？",
                        "日期不一致确认",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (option != JOptionPane.YES_OPTION) {
                    birthDateField.requestFocus();
                    return;
                }
            }
        }

        try {
            // 创建用户数据Map
            Map<String, Object> userData = new HashMap<>();
            // 人员代码由服务器自动生成，这里不传递
            userData.put("name", name);

            // 获取性别
            String gender = maleRadioButton.isSelected() ? "男" : "女";
            userData.put("gender", gender);

            // 处理出生日期
            userData.put("birthDate", birthDateStr);

            userData.put("idCard", idCard);
            userData.put("nativePlace", nativePlaceField.getText().trim());
            userData.put("address", addressField.getText().trim());
            userData.put("phone", phoneField.getText().trim());
            userData.put("otherInfo", otherInfoArea.getText().trim());

            // 发送请求
            Map<String, Object> result = PersonnelHttpClient.addPersonnel(userData);

            if (Boolean.TRUE.equals(result.get("success"))) {
                JOptionPane.showMessageDialog(this, "人员添加成功", "成功", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, result.get("message"), "错误", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "添加人员失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }
}