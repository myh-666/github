package com.class2.seat27.client.http;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.http.client.config.RequestConfig;
import java.net.SocketTimeoutException;

import java.util.Map;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class HttpClientUtil {
    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static String postJson(String url, Map<String, Object> data) throws Exception {
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            // 检查是否为 GET 请求（没有请求体数据的情况）
            if (data == null || data.isEmpty()) {
                // 对于没有请求体的请求，使用 GET 方法
                HttpGet httpGet = new HttpGet(url);
                httpGet.setHeader("Content-Type", "application/json;charset=UTF-8");
                httpGet.setHeader("User-Agent", "Warehouse-Client/1.0");

                try (CloseableHttpResponse response = httpClient.execute(httpGet)) {
                    HttpEntity responseEntity = response.getEntity();
                    return EntityUtils.toString(responseEntity, "UTF-8");
                }
            } else {
                // 对于 POST 请求，使用 POST 方法
                HttpPost httpPost = new HttpPost(url);

                // 设置请求头
                httpPost.setHeader("Content-Type", "application/json;charset=UTF-8");
                httpPost.setHeader("User-Agent", "Warehouse-Client/1.0");

                // 设置请求体
                String json = objectMapper.writeValueAsString(data);
                StringEntity entity = new StringEntity(json, "UTF-8");
                httpPost.setEntity(entity);

                // 执行请求
                try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
                    HttpEntity responseEntity = response.getEntity();
                    return EntityUtils.toString(responseEntity, "UTF-8");
                }
            }
        }
    }

    /**
     * 发送POST请求（支持任意对象）
     */
    public static String postJson(String url, Object data) throws Exception {
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpPost httpPost = new HttpPost(url);

            // 设置请求头
            httpPost.setHeader("Content-Type", "application/json;charset=UTF-8");
            httpPost.setHeader("User-Agent", "Warehouse-Client/1.0");

            // 设置请求体
            String json = objectMapper.writeValueAsString(data);
            StringEntity entity = new StringEntity(json, "UTF-8");
            httpPost.setEntity(entity);

            // 执行请求
            try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
                HttpEntity responseEntity = response.getEntity();
                String result = EntityUtils.toString(responseEntity, "UTF-8");

                // 检查HTTP状态码
                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode >= 200 && statusCode < 300) {
                    return result;
                } else {
                    throw new RuntimeException("HTTP请求失败，状态码: " + statusCode + ", 响应: " + result);
                }
            }
        }
    }

    public static String getJson(String url) throws Exception {
        System.out.println("正在发送GET请求到: " + url);

        // 设置请求配置，包括连接超时和读取超时
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(5000)  // 连接超时5秒
                .setSocketTimeout(10000)   // 读取超时10秒
                .build();

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            // 对于GET请求
            HttpGet httpGet = new HttpGet(url);
            httpGet.setConfig(requestConfig);
            httpGet.setHeader("Content-Type", "application/json;charset=UTF-8");
            httpGet.setHeader("User-Agent", "Warehouse-Client/1.0");

            try (CloseableHttpResponse response = httpClient.execute(httpGet)) {
                HttpEntity responseEntity = response.getEntity();
                String result = EntityUtils.toString(responseEntity, "UTF-8");
                System.out.println("服务器响应: " + result);

                // 检查HTTP状态码
                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode >= 200 && statusCode < 300) {
                    return result;
                } else {
                    throw new RuntimeException("HTTP请求失败，状态码: " + statusCode + ", 响应: " + result);
                }
            } catch (SocketTimeoutException e) {
                System.err.println("请求超时: " + e.getMessage());
                throw new Exception("连接服务器超时，请检查服务器是否运行或网络连接是否正常");
            } catch (Exception e) {
                System.err.println("请求失败: " + e.getMessage());
                e.printStackTrace();
                throw new Exception("连接服务器失败: " + e.getMessage());
            }
        }
    }

    public static String deleteJson(String url, Map<String, Object> data) throws Exception {
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            // 对于DELETE请求，如果不需要请求体，直接使用HttpDelete
            if (data == null || data.isEmpty()) {
                HttpDelete httpDelete = new HttpDelete(url);
                httpDelete.setHeader("Content-Type", "application/json;charset=UTF-8");
                httpDelete.setHeader("User-Agent", "Warehouse-Client/1.0");

                try (CloseableHttpResponse response = httpClient.execute(httpDelete)) {
                    HttpEntity responseEntity = response.getEntity();
                    String result = EntityUtils.toString(responseEntity, "UTF-8");

                    // 检查HTTP状态码
                    int statusCode = response.getStatusLine().getStatusCode();
                    if (statusCode >= 200 && statusCode < 300) {
                        return result;
                    } else {
                        throw new RuntimeException("HTTP请求失败，状态码: " + statusCode + ", 响应: " + result);
                    }
                }
            } else {
                // 如果需要请求体，使用POST方法但指定为DELETE
                HttpPost httpPost = new HttpPost(url);
                httpPost.setHeader("Content-Type", "application/json;charset=UTF-8");
                httpPost.setHeader("User-Agent", "Warehouse-Client/1.0");
                httpPost.setHeader("X-HTTP-Method-Override", "DELETE");

                String json = objectMapper.writeValueAsString(data);
                StringEntity entity = new StringEntity(json, "UTF-8");
                httpPost.setEntity(entity);

                try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
                    HttpEntity responseEntity = response.getEntity();
                    String result = EntityUtils.toString(responseEntity, "UTF-8");

                    // 检查HTTP状态码
                    int statusCode = response.getStatusLine().getStatusCode();
                    if (statusCode >= 200 && statusCode < 300) {
                        return result;
                    } else {
                        throw new RuntimeException("HTTP请求失败，状态码: " + statusCode + ", 响应: " + result);
                    }
                }
            }
        }
    }

    /**
     * 发送DELETE请求（无请求体）
     */
    public static String deleteJson(String url) throws Exception {
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpDelete httpDelete = new HttpDelete(url);
            httpDelete.setHeader("Content-Type", "application/json;charset=UTF-8");
            httpDelete.setHeader("User-Agent", "Warehouse-Client/1.0");

            try (CloseableHttpResponse response = httpClient.execute(httpDelete)) {
                HttpEntity responseEntity = response.getEntity();
                String result = EntityUtils.toString(responseEntity, "UTF-8");

                // 检查HTTP状态码
                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode >= 200 && statusCode < 300) {
                    return result;
                } else {
                    throw new RuntimeException("HTTP请求失败，状态码: " + statusCode + ", 响应: " + result);
                }
            }
        }
    }

    public static String putJson(String url, Map<String, Object> data) throws Exception {
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpPut httpPut = new HttpPut(url);

            // 设置请求头
            httpPut.setHeader("Content-Type", "application/json;charset=UTF-8");
            httpPut.setHeader("User-Agent", "Warehouse-Client/1.0");

            // 设置请求体
            String json = objectMapper.writeValueAsString(data);
            StringEntity entity = new StringEntity(json, "UTF-8");
            httpPut.setEntity(entity);

            // 执行请求
            try (CloseableHttpResponse response = httpClient.execute(httpPut)) {
                HttpEntity responseEntity = response.getEntity();
                String result = EntityUtils.toString(responseEntity, "UTF-8");

                // 检查HTTP状态码
                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode >= 200 && statusCode < 300) {
                    return result;
                } else {
                    throw new RuntimeException("HTTP请求失败，状态码: " + statusCode + ", 响应: " + result);
                }
            }
        }
    }

    /**
     * 发送PUT请求（支持任意对象）
     */
    public static String putJson(String url, Object data) throws Exception {
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpPut httpPut = new HttpPut(url);

            // 设置请求头
            httpPut.setHeader("Content-Type", "application/json;charset=UTF-8");
            httpPut.setHeader("User-Agent", "Warehouse-Client/1.0");

            // 设置请求体
            String json = objectMapper.writeValueAsString(data);
            StringEntity entity = new StringEntity(json, "UTF-8");
            httpPut.setEntity(entity);

            // 执行请求
            try (CloseableHttpResponse response = httpClient.execute(httpPut)) {
                HttpEntity responseEntity = response.getEntity();
                String result = EntityUtils.toString(responseEntity, "UTF-8");

                // 检查HTTP状态码
                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode >= 200 && statusCode < 300) {
                    return result;
                } else {
                    throw new RuntimeException("HTTP请求失败，状态码: " + statusCode + ", 响应: " + result);
                }
            }
        }
    }

    /**
     * 下载文件
     * @param url 文件URL
     * @param filename 文件名
     * @throws Exception
     */
    public static void downloadFile(String url, String filename) throws Exception {
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpGet httpGet = new HttpGet(url);
            httpGet.setHeader("User-Agent", "Warehouse-Client/1.0");

            try (CloseableHttpResponse response = httpClient.execute(httpGet)) {
                HttpEntity entity = response.getEntity();
                if (entity != null) {
                    // 确保下载目录存在
                    File downloadDir = new File("downloads");
                    if (!downloadDir.exists()) {
                        downloadDir.mkdir();
                    }

                    // 创建目标文件
                    File file = new File(downloadDir, filename);

                    // 写入文件
                    try (InputStream in = entity.getContent();
                         FileOutputStream out = new FileOutputStream(file)) {
                        byte[] buffer = new byte[4096];
                        int bytesRead;
                        while ((bytesRead = in.read(buffer)) != -1) {
                            out.write(buffer, 0, bytesRead);
                        }
                    }
                }
            }
        }
    }

    /**
     * 下载文件并返回字节数组
     * @param url 文件URL
     * @return 文件内容的字节数组
     * @throws Exception
     */
    public static byte[] downloadFile(String url) throws Exception {
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpGet httpGet = new HttpGet(url);
            httpGet.setHeader("User-Agent", "Warehouse-Client/1.0");

            try (CloseableHttpResponse response = httpClient.execute(httpGet)) {
                HttpEntity entity = response.getEntity();
                if (entity != null) {
                    // 读取所有字节
                    return EntityUtils.toByteArray(entity);
                }
                return null;
            }
        }
    }

    public static String get(String url) throws Exception {
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpGet httpGet = new HttpGet(url);
            httpGet.setHeader("Content-Type", "application/json;charset=UTF-8");
            httpGet.setHeader("User-Agent", "Warehouse-Client/1.0");

            try (CloseableHttpResponse response = httpClient.execute(httpGet)) {
                HttpEntity responseEntity = response.getEntity();
                String result = EntityUtils.toString(responseEntity, "UTF-8");

                // 检查HTTP状态码
                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode >= 200 && statusCode < 300) {
                    return result;
                } else {
                    throw new RuntimeException("HTTP请求失败，状态码: " + statusCode + ", 响应: " + result);
                }
            }
        }
    }

    /**
     * 通用的JSON请求方法
     */
    private static String sendJsonRequest(String url, String method, Object data) throws Exception {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        try {
            if ("GET".equalsIgnoreCase(method)) {
                return getJson(url);
            } else if ("POST".equalsIgnoreCase(method)) {
                return postJson(url, data);
            } else if ("PUT".equalsIgnoreCase(method)) {
                return putJson(url, data);
            } else if ("DELETE".equalsIgnoreCase(method)) {
                return deleteJson(url);
            } else {
                throw new IllegalArgumentException("不支持的HTTP方法: " + method);
            }
        } finally {
            httpClient.close();
        }
    }
}