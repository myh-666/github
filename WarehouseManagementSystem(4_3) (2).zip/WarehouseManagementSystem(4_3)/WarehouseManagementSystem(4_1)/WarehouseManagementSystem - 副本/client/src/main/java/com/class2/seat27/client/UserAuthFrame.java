package com.class2.seat27.client;

import com.class2.seat27.client.http.PermissionHttpClient;
import com.class2.seat27.client.http.PersonnelHttpClient;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 用户授权界面
 */
public class UserAuthFrame extends JFrame {
    private JComboBox<String> userComboBox;
    private JTable permissionTable;
    private JButton saveButton;
    private JButton resetButton;
    private JButton refreshButton;
    private JButton backButton;
    private JLabel userInfoLabel;
    private JLabel statusLabel;

    private DefaultTableModel tableModel;
    private Map<String, Long> userMap; // 用户名到用户ID的映射
    private Long currentUserId;
    private String currentAuthUser; // 当前执行授权的用户
    private Long currentAdminUserId; // 当前管理员用户的ID

    private static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 原有构造方法 - 向后兼容
     */
    public UserAuthFrame(String authUser) {
        this.currentAuthUser = authUser;
        this.currentAdminUserId = getCurrentAuthUserId(); // 通过用户名查询ID
        initComponents();
        setupLayout();
        setupListeners();
        loadUserData();
        setTitle("用户授权管理 - 当前授权用户: " + authUser);
    }

    /**
     * 新构造方法 - 接收管理员用户ID
     */
    public UserAuthFrame(String authUser, Long currentAdminUserId) {
        this.currentAuthUser = authUser;
        this.currentAdminUserId = currentAdminUserId;
        initComponents();
        setupLayout();
        setupListeners();
        loadUserData();
        setTitle("用户授权管理 - 当前授权用户: " + authUser);
    }

    private void initComponents() {
        setTitle("用户授权管理");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(900, 700);
        setLocationRelativeTo(null);

        // 用户选择框
        userComboBox = new JComboBox<>();
        userComboBox.setPreferredSize(new Dimension(200, 30));
        userMap = new HashMap<>();

        // 用户信息标签
        userInfoLabel = new JLabel("请选择用户");
        userInfoLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        // 状态标签
        statusLabel = new JLabel("就绪");
        statusLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        // 权限表格
        String[] columnNames = {"权限名称", "菜单路径", "描述", "授权状态"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 3) {
                    return Boolean.class;
                }
                return String.class;
            }

            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 3 && currentUserId != null;
            }
        };
        permissionTable = new JTable(tableModel);
        permissionTable.setRowHeight(30);
        permissionTable.getColumnModel().getColumn(0).setPreferredWidth(200);
        permissionTable.getColumnModel().getColumn(1).setPreferredWidth(250);
        permissionTable.getColumnModel().getColumn(2).setPreferredWidth(300);
        permissionTable.getColumnModel().getColumn(3).setPreferredWidth(100);
        permissionTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // 按钮
        saveButton = new JButton("保存权限");
        resetButton = new JButton("重置权限");
        refreshButton = new JButton("刷新用户");
        backButton = new JButton("返回主菜单");

        // 设置按钮大小
        saveButton.setPreferredSize(new Dimension(100, 30));
        resetButton.setPreferredSize(new Dimension(100, 30));
        refreshButton.setPreferredSize(new Dimension(100, 30));
        backButton.setPreferredSize(new Dimension(120, 30));
    }

    private void setupLayout() {
        setLayout(new BorderLayout(10, 10));

        // 顶部面板 - 用户选择
        JPanel topPanel = new JPanel(new BorderLayout(10, 10));
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel userPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        userPanel.add(new JLabel("选择用户:"));
        userPanel.add(userComboBox);
        userPanel.add(refreshButton);

        topPanel.add(userPanel, BorderLayout.NORTH);
        topPanel.add(userInfoLabel, BorderLayout.CENTER);

        add(topPanel, BorderLayout.NORTH);

        // 中间面板 - 权限表格
        JScrollPane tableScrollPane = new JScrollPane(permissionTable);
        tableScrollPane.setBorder(BorderFactory.createTitledBorder("权限列表"));
        add(tableScrollPane, BorderLayout.CENTER);

        // 底部面板 - 按钮和状态
        JPanel bottomPanel = new JPanel(new BorderLayout());

        // 按钮面板
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.add(saveButton);
        buttonPanel.add(resetButton);
        buttonPanel.add(backButton);

        // 状态面板
        JPanel statusPanel = new JPanel(new BorderLayout());
        statusPanel.setBorder(BorderFactory.createEtchedBorder());
        statusPanel.add(statusLabel, BorderLayout.WEST);

        bottomPanel.add(buttonPanel, BorderLayout.CENTER);
        bottomPanel.add(statusPanel, BorderLayout.SOUTH);

        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void setupListeners() {
        // 用户选择事件
        userComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedUserName = (String) userComboBox.getSelectedItem();
                if (selectedUserName != null && userMap.containsKey(selectedUserName)) {
                    currentUserId = userMap.get(selectedUserName);
                    loadUserPermissions(currentUserId);
                    updateUserInfo(selectedUserName);
                    updateStatus("已选择用户: " + selectedUserName);
                }
            }
        });

        // 保存按钮事件
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveUserPermissions();
            }
        });

        // 重置按钮事件
        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetUserPermissions();
            }
        });

        // 刷新按钮事件
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadUserData();
            }
        });

        // 返回按钮事件
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }

    /**
     * 加载用户数据
     */
    private void loadUserData() {
        try {
            updateStatus("正在加载用户数据...");
            Map<String, Object> result = PersonnelHttpClient.getAllPersonnel();
            if (Boolean.TRUE.equals(result.get("success"))) {
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> userList = (List<Map<String, Object>>) result.get("data");

                userMap.clear();
                userComboBox.removeAllItems();

                for (Map<String, Object> user : userList) {
                    String username = (String) user.get("username");
                    Long id = ((Number) user.get("id")).longValue();
                    String name = (String) user.get("name");
                    String displayName = name + " (" + username + ")";

                    userMap.put(displayName, id);
                    userComboBox.addItem(displayName);
                }

                if (!userMap.isEmpty()) {
                    userComboBox.setSelectedIndex(0);
                    updateStatus("用户数据加载完成，共 " + userList.size() + " 个用户");
                } else {
                    updateStatus("没有找到用户数据");
                }
            } else {
                updateStatus("加载用户数据失败: " + result.get("message"));
                JOptionPane.showMessageDialog(this, "加载用户数据失败: " + result.get("message"),
                        "错误", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            updateStatus("加载用户数据失败: " + ex.getMessage());
            JOptionPane.showMessageDialog(this, "加载用户数据失败: " + ex.getMessage(),
                    "错误", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    /**
     * 加载用户权限
     */
    private void loadUserPermissions(Long userId) {
        try {
            updateStatus("正在加载用户权限...");
            Map<String, Object> result = PermissionHttpClient.getUserPermissions(userId);
            if (Boolean.TRUE.equals(result.get("success"))) {
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> permissions = (List<Map<String, Object>>) result.get("data");

                tableModel.setRowCount(0);

                for (Map<String, Object> permission : permissions) {
                    String resourceCode = (String) permission.get("resourceCode");
                    String resourceName = (String) permission.get("resourceName");
                    String menuPath = (String) permission.get("menuPath");
                    String description = (String) permission.get("description");
                    Boolean granted = (Boolean) permission.get("granted");

                    // 过滤掉个人管理权限，不显示在授权页面
                    if (isPersonalManagementPermission(resourceCode)) {
                        continue; // 跳过个人管理权限
                    }

                    tableModel.addRow(new Object[]{resourceName, menuPath, description, granted});
                }
                updateStatus("权限数据加载完成，共 " + tableModel.getRowCount() + " 个可授权权限");
            } else {
                updateStatus("加载权限数据失败: " + result.get("message"));
                JOptionPane.showMessageDialog(this, "加载权限数据失败: " + result.get("message"),
                        "错误", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            updateStatus("加载权限数据失败: " + ex.getMessage());
            JOptionPane.showMessageDialog(this, "加载权限数据失败: " + ex.getMessage(),
                    "错误", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    /**
     * 判断是否为个人管理权限（不需要在授权页面显示）
     */
    private boolean isPersonalManagementPermission(String resourceCode) {
        return "PERSONAL_CHANGE_PWD".equals(resourceCode) ||
                "PERSONAL_MODIFY_PROFILE".equals(resourceCode);
    }

    /**
     * 保存用户权限
     */
    private void saveUserPermissions() {
        if (currentUserId == null) {
            JOptionPane.showMessageDialog(this, "请先选择用户", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            updateStatus("正在检查授权权限...");

            // 使用传递过来的管理员用户ID进行权限检查
            if (currentAdminUserId == null) {
                updateStatus("无法获取当前管理员用户信息");
                JOptionPane.showMessageDialog(this, "无法获取当前管理员信息", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // 检查当前管理员用户是否有用户授权权限
            Map<String, Object> authCheck = PermissionHttpClient.checkPermission(
                    currentAdminUserId, "USER_AUTH");

            if (!Boolean.TRUE.equals(authCheck.get("hasPermission"))) {
                updateStatus("权限不足: 没有用户授权权限");
                JOptionPane.showMessageDialog(this,
                        "您没有用户授权的权限", "权限不足", JOptionPane.ERROR_MESSAGE);
                return;
            }

            updateStatus("正在保存权限...");
            Map<String, Object> allPermissionsResult = PermissionHttpClient.getAllPermissions();
            if (!Boolean.TRUE.equals(allPermissionsResult.get("success"))) {
                updateStatus("获取权限资源失败");
                JOptionPane.showMessageDialog(this, "获取权限资源失败", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }

            @SuppressWarnings("unchecked")
            List<Map<String, Object>> allPermissions = (List<Map<String, Object>>) allPermissionsResult.get("data");

            Map<String, Boolean> permissionsToUpdate = new HashMap<>();
            int grantedCount = 0;
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                String resourceName = (String) tableModel.getValueAt(i, 0);
                Boolean granted = (Boolean) tableModel.getValueAt(i, 3);

                String resourceCode = findResourceCodeByName(allPermissions, resourceName);
                if (resourceCode != null && !isPersonalManagementPermission(resourceCode)) {
                    permissionsToUpdate.put(resourceCode, granted);
                    if (granted) grantedCount++;
                }
            }

            Map<String, Object> result = PermissionHttpClient.updateUserPermissions(
                    currentUserId, permissionsToUpdate, currentAuthUser);

            if (Boolean.TRUE.equals(result.get("success"))) {
                updateStatus("权限保存成功，共授权 " + grantedCount + " 个权限");
                JOptionPane.showMessageDialog(this,
                        "权限保存成功！\n共更新 " + permissionsToUpdate.size() + " 个权限\n其中 " + grantedCount + " 个权限已授权",
                        "成功", JOptionPane.INFORMATION_MESSAGE);
            } else {
                updateStatus("权限保存失败: " + result.get("message"));
                JOptionPane.showMessageDialog(this, "权限保存失败: " + result.get("message"),
                        "错误", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            updateStatus("保存权限失败: " + ex.getMessage());
            JOptionPane.showMessageDialog(this, "保存权限失败: " + ex.getMessage(),
                    "错误", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    /**
     * 获取当前授权用户的ID
     */
    private Long getCurrentAuthUserId() {
        try {
            Map<String, Object> allUsers = PersonnelHttpClient.getAllPersonnel();
            if (Boolean.TRUE.equals(allUsers.get("success"))) {
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> userList = (List<Map<String, Object>>) allUsers.get("data");
                for (Map<String, Object> user : userList) {
                    if (currentAuthUser.equals(user.get("username"))) {
                        return ((Number) user.get("id")).longValue();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 重置用户权限
     */
    private void resetUserPermissions() {
        if (currentUserId == null) {
            JOptionPane.showMessageDialog(this, "请先选择用户", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "确定要重置该用户的所有权限吗？此操作将撤销所有已授权权限。",
                "确认重置", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                updateStatus("正在重置权限...");
                Map<String, Object> result = PermissionHttpClient.resetUserPermissions(currentUserId);
                if (Boolean.TRUE.equals(result.get("success"))) {
                    updateStatus("权限重置成功");
                    JOptionPane.showMessageDialog(this, "权限重置成功", "成功", JOptionPane.INFORMATION_MESSAGE);
                    loadUserPermissions(currentUserId); // 重新加载权限
                } else {
                    updateStatus("权限重置失败: " + result.get("message"));
                    JOptionPane.showMessageDialog(this, "权限重置失败: " + result.get("message"),
                            "错误", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                updateStatus("重置权限失败: " + ex.getMessage());
                JOptionPane.showMessageDialog(this, "重置权限失败: " + ex.getMessage(),
                        "错误", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        } else {
            updateStatus("权限重置操作已取消");
        }
    }

    /**
     * 根据权限名称查找资源代码
     */
    private String findResourceCodeByName(List<Map<String, Object>> permissions, String resourceName) {
        for (Map<String, Object> permission : permissions) {
            if (resourceName.equals(permission.get("resourceName"))) {
                return (String) permission.get("resourceCode");
            }
        }
        return null;
    }

    /**
     * 更新用户信息显示
     */
    private void updateUserInfo(String displayName) {
        userInfoLabel.setText("当前用户: " + displayName + " | 用户ID: " + currentUserId);
    }

    /**
     * 更新状态栏
     */
    private void updateStatus(String message) {
        statusLabel.setText(message);
        System.out.println("用户授权状态: " + message);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            UserAuthFrame frame = new UserAuthFrame("admin", 1L); // 假设管理员用户ID为1
            frame.setVisible(true);
        });
    }
}