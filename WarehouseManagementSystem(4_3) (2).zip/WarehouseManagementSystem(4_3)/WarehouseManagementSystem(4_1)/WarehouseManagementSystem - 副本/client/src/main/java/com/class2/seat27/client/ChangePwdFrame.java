
package com.class2.seat27.client;

import com.class2.seat27.client.http.HttpClientUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

/**
 * 修改密码窗口类，继承自JFrame，用于实现用户修改密码界面和功能
 */
public class ChangePwdFrame extends JFrame {
    // 用户名标签和输入框
    private JLabel usernameLabel;
    private JTextField usernameField;
    // 旧密码标签和输入框
    private JLabel oldPwdLabel;
    private JPasswordField oldPwdField;
    // 新密码标签和输入框
    private JLabel newPwdLabel;
    private JPasswordField newPwdField;
    // 确认新密码标签和输入框
    private JLabel confirmPwdLabel;
    private JPasswordField confirmPwdField;
    // 确认和取消按钮
    private JButton confirmButton;
    private JButton cancelButton;

    // 服务器URL常量
    private static final String SERVER_URL = "http://localhost:8081/api/auth/change-password";
    // JSON对象映射器，用于处理JSON数据
    private static final ObjectMapper objectMapper = new ObjectMapper();

    // 当前登录用户
    private String currentUser;

    /**
     * 构造方法，初始化修改密码窗口
     *
     * @param currentUser 当前登录用户名
     */
    public ChangePwdFrame(String currentUser) {
        this.currentUser = currentUser;
        initComponents();    // 初始化窗口组件
        setupLayout();      // 设置窗口布局
        setupListeners();   // 设置组件事件监听器
    }

    /**
     * 初始化窗口组件
     */
    private void initComponents() {
        setTitle("修改密码");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(450, 350);
        setLocationRelativeTo(null); // 居中显示
        setResizable(false);

        usernameLabel = new JLabel("用户名:");
        usernameField = new JTextField(20);
        usernameField.setText(currentUser);
        usernameField.setEditable(false); // 用户名不可编辑

        oldPwdLabel = new JLabel("旧密码:");
        oldPwdField = new JPasswordField(20);

        newPwdLabel = new JLabel("新密码:");
        newPwdField = new JPasswordField(20);

        confirmPwdLabel = new JLabel("确认新密码:");
        confirmPwdField = new JPasswordField(20);

        confirmButton = new JButton("确认修改");
        cancelButton = new JButton("取消");

        // 设置按钮大小
        confirmButton.setPreferredSize(new Dimension(100, 30));
        cancelButton.setPreferredSize(new Dimension(100, 30));
    }

    /**
     * 设置窗口布局
     */
    private void setupLayout() {
        setLayout(new BorderLayout(10, 10));

        // 主面板
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // 标题
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel titleLabel = new JLabel("修改密码", JLabel.CENTER);
        titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 24));
        titleLabel.setForeground(new Color(0, 102, 204));
        mainPanel.add(titleLabel, gbc);

        // 用户名
        gbc.gridwidth = 1;
        gbc.gridy = 1;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        mainPanel.add(usernameLabel, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(usernameField, gbc);

        // 旧密码
        gbc.gridy = 2;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        mainPanel.add(oldPwdLabel, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(oldPwdField, gbc);

        // 新密码
        gbc.gridy = 3;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        mainPanel.add(newPwdLabel, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(newPwdField, gbc);

        // 确认新密码
        gbc.gridy = 4;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        mainPanel.add(confirmPwdLabel, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(confirmPwdField, gbc);

        // 按钮面板
        gbc.gridy = 5;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 0));
        buttonPanel.add(confirmButton);
        buttonPanel.add(cancelButton);
        mainPanel.add(buttonPanel, gbc);

        add(mainPanel, BorderLayout.CENTER);

        // 底部提示栏
        JPanel tipPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        tipPanel.add(new JLabel("提示：密码长度至少为6位"));
        add(tipPanel, BorderLayout.SOUTH);
    }

    /**
     * 设置组件事件监听器
     */
    private void setupListeners() {
        // 确认修改按钮点击事件
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changePassword();
            }
        });

        // 取消按钮点击事件
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // 关闭修改密码窗口
            }
        });

        // 回车确认修改
        confirmPwdField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changePassword();
            }
        });
    }

    /**
     * 修改密码方法
     */
    private void changePassword() {
        String username = usernameField.getText().trim();
        String oldPassword = new String(oldPwdField.getPassword());
        String newPassword = new String(newPwdField.getPassword());
        String confirmPassword = new String(confirmPwdField.getPassword());

        // 表单验证
        if (oldPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "密码不能为空", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (newPassword.length() < 6) {
            JOptionPane.showMessageDialog(this, "新密码长度不能少于6位", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!newPassword.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this, "两次输入的新密码不一致", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (oldPassword.equals(newPassword)) {
            JOptionPane.showMessageDialog(this, "新密码不能与旧密码相同", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // 准备修改密码数据
            Map<String, Object> changePwdData = new HashMap<>();
            changePwdData.put("username", username);
            changePwdData.put("oldPassword", oldPassword);
            changePwdData.put("newPassword", newPassword);

            // 发送修改密码请求
            String response = HttpClientUtil.postJson(SERVER_URL, changePwdData);
            System.out.println("服务器响应: " + response); // 添加调试日志

            // 解析响应
            Map<String, Object> result = objectMapper.readValue(response, Map.class);
            System.out.println("解析结果: " + result); // 添加调试日志

            if (Boolean.TRUE.equals(result.get("success"))) {
                JOptionPane.showMessageDialog(this, "密码修改成功", "成功", JOptionPane.INFORMATION_MESSAGE);
                dispose(); // 关闭修改密码窗口
            } else {
                String errorMessage = result.containsKey("message") ? result.get("message").toString() : "未知错误";
                JOptionPane.showMessageDialog(this, errorMessage, "修改失败", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "连接服务器失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }
}
