package com.class2.seat27.client;

import com.class2.seat27.client.http.HttpClientUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

/**
 * 注册窗口类，继承自JFrame，用于实现用户注册界面和注册功能
 */
public class RegisterFrame extends JFrame {
    // 用户名输入框
    private JTextField usernameField;
    // 性别选择 - 改为单选按钮
    private JRadioButton maleRadioButton;
    private JRadioButton femaleRadioButton;
    private ButtonGroup genderButtonGroup;
    // 密码输入框
    private JPasswordField passwordField;
    // 确认密码输入框
    private JPasswordField confirmPasswordField;
    // 身份证号输入框
    private JTextField idCardField;
    // 确认注册按钮
    private JButton confirmButton;
    // 取消注册按钮
    private JButton cancelButton;

    // 服务器URL常量
    private static final String SERVER_URL = "http://localhost:8081/api/auth/register";
    // JSON对象映射器，用于处理JSON数据
    private static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 构造方法，初始化注册窗口
     */
    public RegisterFrame() {
        initComponents();    // 初始化窗口组件
        setupLayout();      // 设置窗口布局
        setupListeners();   // 设置组件事件监听器
    }

    /**
     * 初始化窗口组件
     */
    private void initComponents() {
        setTitle("仓库管理系统 - 注册");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(450, 400);
        setLocationRelativeTo(null); // 居中显示
        setResizable(false);

        usernameField = new JTextField(20);

        // 初始化性别单选按钮
        maleRadioButton = new JRadioButton("男");
        femaleRadioButton = new JRadioButton("女");
        genderButtonGroup = new ButtonGroup();
        genderButtonGroup.add(maleRadioButton);
        genderButtonGroup.add(femaleRadioButton);
        maleRadioButton.setSelected(true); // 默认选择"男"

        passwordField = new JPasswordField(20);
        confirmPasswordField = new JPasswordField(20);
        idCardField = new JTextField(20);
        confirmButton = new JButton("确认注册");
        cancelButton = new JButton("取消注册");

        // 设置按钮大小
        confirmButton.setPreferredSize(new Dimension(80, 30));
        cancelButton.setPreferredSize(new Dimension(80, 30));
    }

    /**
     * 设置窗口布局
     */
    private void setupLayout() {
        setLayout(new BorderLayout(10, 10));

        // 主面板
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // 标题
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel titleLabel = new JLabel("用户注册", JLabel.CENTER);
        titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 24));
        titleLabel.setForeground(new Color(0, 102, 204));
        mainPanel.add(titleLabel, gbc);

        // 用户名
        gbc.gridwidth = 1;
        gbc.gridy = 1;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        mainPanel.add(new JLabel("用户名:"), gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(usernameField, gbc);

        // 性别 - 改为单选按钮布局
        gbc.gridy = 2;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        mainPanel.add(new JLabel("性别:"), gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        genderPanel.add(maleRadioButton);
        genderPanel.add(femaleRadioButton);
        mainPanel.add(genderPanel, gbc);

        // 密码
        gbc.gridy = 3;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        mainPanel.add(new JLabel("密码:"), gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(passwordField, gbc);

        // 确认密码
        gbc.gridy = 4;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        mainPanel.add(new JLabel("确认密码:"), gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(confirmPasswordField, gbc);

        // 身份证号
        gbc.gridy = 5;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        mainPanel.add(new JLabel("身份证号:"), gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(idCardField, gbc);

        // 按钮面板
        gbc.gridy = 6;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 0));
        buttonPanel.add(confirmButton);
        buttonPanel.add(cancelButton);
        mainPanel.add(buttonPanel, gbc);

        add(mainPanel, BorderLayout.CENTER);

        // 底部提示栏
        JPanel tipPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        tipPanel.add(new JLabel("提示：密码长度至少为6位，身份证号必须为18位"));
        add(tipPanel, BorderLayout.SOUTH);
    }

    /**
     * 设置组件事件监听器
     */
    private void setupListeners() {
        // 确认注册按钮点击事件
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                register();
            }
        });

        // 取消注册按钮点击事件
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // 关闭注册窗口
            }
        });

        // 回车确认注册
        idCardField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                register();
            }
        });
    }

    /**
     * 注册方法
     */
    private void register() {
        String username = usernameField.getText().trim();
        String gender = maleRadioButton.isSelected() ? "男" : "女";
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        String idCard = idCardField.getText().trim();

        // 表单验证
        if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || idCard.isEmpty()) {
            JOptionPane.showMessageDialog(this, "所有字段不能为空", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (password.length() < 6) {
            JOptionPane.showMessageDialog(this, "密码长度不能少于6位", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this, "两次输入的密码不一致", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (idCard.length() != 18) {
            JOptionPane.showMessageDialog(this, "身份证号必须为18位", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // 准备注册数据
            Map<String, Object> registerData = new HashMap<>();
            registerData.put("username", username);
            registerData.put("name", username); // name和username一样
            registerData.put("gender", gender);
            registerData.put("password", password);
            registerData.put("idCard", idCard);
            // userRole默认为USER，不在前端设置

            // 发送注册请求
            String response = HttpClientUtil.postJson(SERVER_URL, registerData);
            System.out.println("服务器响应: " + response); // 添加调试日志

            // 解析响应
            Map<String, Object> result = objectMapper.readValue(response, Map.class);
            System.out.println("解析结果: " + result); // 添加调试日志

            if (Boolean.TRUE.equals(result.get("success"))) {
                JOptionPane.showMessageDialog(this, "注册成功", "成功", JOptionPane.INFORMATION_MESSAGE);
                dispose(); // 关闭注册窗口
            } else {
                String errorMessage = result.containsKey("message") ? result.get("message").toString() : "未知错误";
                JOptionPane.showMessageDialog(this, errorMessage, "注册失败", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "连接服务器失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }
}
