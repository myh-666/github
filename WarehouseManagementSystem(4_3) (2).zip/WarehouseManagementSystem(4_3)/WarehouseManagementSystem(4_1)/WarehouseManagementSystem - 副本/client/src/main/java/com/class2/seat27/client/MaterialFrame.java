package com.class2.seat27.client;

import com.class2.seat27.client.http.HttpClientUtil;
import com.class2.seat27.client.http.PermissionHttpClient;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

/**
 * 物料管理界面类
 * 用于物料的增删改查操作，集成权限管理
 */
public class MaterialFrame extends JFrame {
    private JTextField searchField;
    private JTextField codeField;
    private JTextField specField;
    private JComboBox<String> unitCombo;
    private JButton searchButton;
    private JButton resetButton;
    private JButton addButton;
    private JButton editButton;
    private JButton deleteButton;
    private JButton backButton;

    private JTable materialTable;
    private DefaultTableModel tableModel;

    private List<Map<String, Object>> materialList;
    private Map<String, Object> selectedMaterial;

    private static final String SERVER_URL = "http://localhost:8081/api/warehouse";
    private static final ObjectMapper objectMapper = new ObjectMapper();

    private String username;
    private MainFrame parentFrame;
    private String operationType; // 操作类型：ADD, MODIFY, DELETE, QUERY
    private Long currentUserId;

    public MaterialFrame(MainFrame parentFrame, String username) {
        this.parentFrame = parentFrame;
        this.username = username;
        this.currentUserId = parentFrame.getCurrentUserId();
        this.operationType = "QUERY"; // 默认为查询模式
        initComponents();
        setupLayout();
        setupListeners();
        loadMaterialData();
        setupButtonPermissions(); // 设置按钮权限
    }

    /**
     * 根据操作类型设置界面
     * @param operationType 操作类型：ADD, MODIFY, DELETE, QUERY
     */
    public void setOperationType(String operationType) {
        this.operationType = operationType;

        // 根据操作类型设置界面
        switch (operationType) {
            case "ADD":
                setTitle("物料管理 - 新增物料");
                addButton.setEnabled(true);
                editButton.setEnabled(false);
                deleteButton.setEnabled(false);
                break;
            case "MODIFY":
                setTitle("物料管理 - 修改物料");
                addButton.setEnabled(false);
                editButton.setEnabled(true);
                deleteButton.setEnabled(false);
                break;
            case "DELETE":
                setTitle("物料管理 - 删除物料");
                addButton.setEnabled(false);
                editButton.setEnabled(false);
                deleteButton.setEnabled(true);
                break;
            case "QUERY":
            default:
                setTitle("物料管理 - 查询物料");
                setupButtonPermissions(); // 根据权限设置按钮状态
                break;
        }
    }

    /**
     * 初始化组件
     */
    private void initComponents() {
        setTitle("物料管理");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // 搜索区域
        searchField = new JTextField(15);
        codeField = new JTextField(15);
        specField = new JTextField(15);
        // 创建可编辑的下拉框，包含所有常用单位
        unitCombo = new JComboBox<>();
        unitCombo.setEditable(true);  // 设置下拉框可编辑
        loadUnitsFromServer();  // 从服务器加载单位列表

        searchButton = new JButton("搜索");
        resetButton = new JButton("重置");
        searchButton.setPreferredSize(new Dimension(80, 30));
        resetButton.setPreferredSize(new Dimension(80, 30));

        // 按钮区域
        addButton = new JButton("新增");
        editButton = new JButton("编辑");
        deleteButton = new JButton("删除");
        backButton = new JButton("返回");

        addButton.setPreferredSize(new Dimension(80, 30));
        editButton.setPreferredSize(new Dimension(80, 30));
        deleteButton.setPreferredSize(new Dimension(80, 30));
        backButton.setPreferredSize(new Dimension(80, 30));

        // 表格区域
        String[] columnNames = {"ID", "物料编码", "名称", "规格", "单位", "库存数量", "最低库存", "价格", "备注"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // 所有单元格不可编辑
            }
        };

        materialTable = new JTable(tableModel);
        materialTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        materialTable.getTableHeader().setReorderingAllowed(false);

        // 设置表格列宽
        materialTable.getColumnModel().getColumn(0).setPreferredWidth(50);   // ID
        materialTable.getColumnModel().getColumn(1).setPreferredWidth(100);  // 物料编码
        materialTable.getColumnModel().getColumn(2).setPreferredWidth(120);  // 名称
        materialTable.getColumnModel().getColumn(3).setPreferredWidth(150);  // 规格
        materialTable.getColumnModel().getColumn(4).setPreferredWidth(60);   // 单位
        materialTable.getColumnModel().getColumn(5).setPreferredWidth(80);   // 库存数量
        materialTable.getColumnModel().getColumn(6).setPreferredWidth(80);   // 最低库存
        materialTable.getColumnModel().getColumn(7).setPreferredWidth(80);   // 价格
        materialTable.getColumnModel().getColumn(8).setPreferredWidth(150);  // 备注
    }

    /**
     * 设置布局
     */
    private void setupLayout() {
        // 主面板
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // 搜索面板
        JPanel searchPanel = new JPanel(new BorderLayout());

        // 搜索条件面板
        JPanel conditionPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        // 第一行
        gbc.gridx = 0;
        gbc.gridy = 0;
        conditionPanel.add(new JLabel("名称:"), gbc);

        gbc.gridx = 1;
        conditionPanel.add(searchField, gbc);

        gbc.gridx = 2;
        conditionPanel.add(new JLabel("编码:"), gbc);

        gbc.gridx = 3;
        conditionPanel.add(codeField, gbc);

        // 第二行
        gbc.gridx = 0;
        gbc.gridy = 1;
        conditionPanel.add(new JLabel("规格:"), gbc);

        gbc.gridx = 1;
        conditionPanel.add(specField, gbc);

        gbc.gridx = 2;
        conditionPanel.add(new JLabel("单位:"), gbc);

        gbc.gridx = 3;
        conditionPanel.add(unitCombo, gbc);

        // 按钮面板
        JPanel searchButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        searchButtonPanel.add(searchButton);
        searchButtonPanel.add(resetButton);

        searchPanel.add(conditionPanel, BorderLayout.CENTER);
        searchPanel.add(searchButtonPanel, BorderLayout.SOUTH);

        // 按钮面板
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(backButton);

        // 顶部面板
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(searchPanel, BorderLayout.WEST);
        topPanel.add(buttonPanel, BorderLayout.EAST);

        // 表格面板
        JScrollPane tableScrollPane = new JScrollPane(materialTable);

        // 添加到主面板
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(tableScrollPane, BorderLayout.CENTER);

        // 添加状态栏
        JPanel statusPanel = new JPanel(new BorderLayout());
        statusPanel.setBorder(BorderFactory.createEtchedBorder());
        JLabel statusLabel = new JLabel("就绪");
        statusPanel.add(statusLabel, BorderLayout.WEST);
        mainPanel.add(statusPanel, BorderLayout.SOUTH);

        // 添加到窗口
        add(mainPanel);
    }

    /**
     * 设置事件监听器
     */
    private void setupListeners() {
        // 搜索按钮
        searchButton.addActionListener(e -> {
            loadMaterialDataWithFilters();
        });

        // 回车键搜索
        searchField.addActionListener(e -> {
            loadMaterialDataWithFilters();
        });

        codeField.addActionListener(e -> {
            loadMaterialDataWithFilters();
        });

        specField.addActionListener(e -> {
            loadMaterialDataWithFilters();
        });

        // 重置按钮
        resetButton.addActionListener(e -> {
            searchField.setText("");
            codeField.setText("");
            specField.setText("");
            unitCombo.setSelectedIndex(0);
            loadMaterialDataWithFilters();
        });

        // 新增按钮
        addButton.addActionListener(e -> {
            if (!checkPermission("MATERIAL_ADD")) {
                JOptionPane.showMessageDialog(this, "您没有新增物料的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                return;
            }
            showMaterialDialog();
        });

        // 编辑按钮
        editButton.addActionListener(e -> {
            if (!checkPermission("MATERIAL_MODIFY")) {
                JOptionPane.showMessageDialog(this, "您没有修改物料的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                return;
            }
            int selectedRow = materialTable.getSelectedRow();
            if (selectedRow >= 0) {
                showMaterialDialog(selectedRow);
            } else {
                JOptionPane.showMessageDialog(this, "请先选择要编辑的物料", "提示", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        // 删除按钮
        deleteButton.addActionListener(e -> {
            if (!checkPermission("MATERIAL_DELETE")) {
                JOptionPane.showMessageDialog(this, "您没有删除物料的权限", "权限不足", JOptionPane.WARNING_MESSAGE);
                return;
            }
            int selectedRow = materialTable.getSelectedRow();
            if (selectedRow >= 0) {
                int confirm = JOptionPane.showConfirmDialog(this, "确定要删除选中的物料吗？", "确认", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    deleteMaterial(selectedRow);
                }
            } else {
                JOptionPane.showMessageDialog(this, "请先选择要删除的物料", "提示", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        // 返回按钮
        backButton.addActionListener(e -> {
            this.setVisible(false);
            parentFrame.setVisible(true);
        });

        // 表格行选择
        materialTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = materialTable.rowAtPoint(e.getPoint());
                if (row >= 0) {
                    materialTable.setRowSelectionInterval(row, row);
                    updateButtonStates(); // 更新按钮状态
                }
            }
        });

        // 双击表格行编辑
        materialTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = materialTable.rowAtPoint(e.getPoint());
                    if (row >= 0 && checkPermission("MATERIAL_MODIFY")) {
                        showMaterialDialog(row);
                    }
                }
            }
        });
    }

    /**
     * 设置按钮权限状态
     */
    private void setupButtonPermissions() {
        // 根据权限设置按钮可用性
        addButton.setEnabled(checkPermission("MATERIAL_ADD"));
        editButton.setEnabled(checkPermission("MATERIAL_MODIFY") && materialTable.getSelectedRow() >= 0);
        deleteButton.setEnabled(checkPermission("MATERIAL_DELETE") && materialTable.getSelectedRow() >= 0);

        // 设置按钮提示
        if (!checkPermission("MATERIAL_ADD")) {
            addButton.setToolTipText("无新增物料权限");
        }
        if (!checkPermission("MATERIAL_MODIFY")) {
            editButton.setToolTipText("无修改物料权限");
        }
        if (!checkPermission("MATERIAL_DELETE")) {
            deleteButton.setToolTipText("无删除物料权限");
        }
    }

    /**
     * 更新按钮状态（基于行选择）
     */
    private void updateButtonStates() {
        boolean hasSelection = materialTable.getSelectedRow() >= 0;
        editButton.setEnabled(checkPermission("MATERIAL_MODIFY") && hasSelection);
        deleteButton.setEnabled(checkPermission("MATERIAL_DELETE") && hasSelection);
    }

    /**
     * 检查用户权限
     */
    private boolean checkPermission(String resourceCode) {
        try {
            // 管理员默认拥有所有权限
            if ("ADMIN".equals(parentFrame.getUserRole())) {
                return true;
            }

            Map<String, Object> result = PermissionHttpClient.checkPermission(currentUserId, resourceCode);
            return Boolean.TRUE.equals(result.get("hasPermission"));
        } catch (Exception e) {
            System.err.println("权限检查失败: " + e.getMessage());
            return false;
        }
    }

    /**
     * 加载物料数据
     */
    private void loadMaterialData() {
        loadMaterialDataWithFilters();
    }

    /**
     * 加载物料数据（带多条件搜索）
     */
    private void loadMaterialDataWithFilters() {
        try {
            // 构建请求URL
            String url = SERVER_URL + "/materials/search?";

            // 获取搜索条件
            String name = searchField.getText().trim();
            String code = codeField.getText().trim();
            String spec = specField.getText().trim();
            String unit = unitCombo.getSelectedItem().toString().trim();

            // 构建查询参数
            boolean hasParam = false;
            if (!name.isEmpty()) {
                url += "name=" + java.net.URLEncoder.encode(name, "UTF-8");
                hasParam = true;
            }

            if (!code.isEmpty()) {
                if (hasParam) url += "&";
                url += "code=" + java.net.URLEncoder.encode(code, "UTF-8");
                hasParam = true;
            }

            if (!spec.isEmpty()) {
                if (hasParam) url += "&";
                url += "spec=" + java.net.URLEncoder.encode(spec, "UTF-8");
                hasParam = true;
            }

            if (!unit.isEmpty()) {
                if (hasParam) url += "&";
                url += "unit=" + java.net.URLEncoder.encode(unit, "UTF-8");
                hasParam = true;
            }

            // 如果没有参数，移除问号
            if (!hasParam) {
                url = SERVER_URL + "/materials";
            }

            // 发送请求获取物料列表
            String response = HttpClientUtil.getJson(url);

            // 解析响应
            Map<String, Object> result = objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});

            if (Boolean.TRUE.equals(result.get("success"))) {
                materialList = (List<Map<String, Object>>) result.get("data");
                updateMaterialTable();
            } else {
                JOptionPane.showMessageDialog(this, "获取物料列表失败: " + result.get("message"), "错误", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "获取物料列表失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * 更新物料表格
     */
    private void updateMaterialTable() {
        // 清空表格
        tableModel.setRowCount(0);

        // 添加数据到表格
        if (materialList != null) {
            // 使用真实的物料ID
            for (int i = 0; i < materialList.size(); i++) {
                Map<String, Object> material = materialList.get(i);
                Object[] row = {
                        material.get("id"), // 使用真实的物料ID
                        material.get("materialCode"),
                        material.get("name"),
                        material.get("specification"),
                        material.get("unit"),
                        material.get("quantity"),
                        material.get("minStock"),
                        material.get("price"),
                        material.get("remark")
                };
                tableModel.addRow(row);
            }
        }

        // 更新按钮状态
        updateButtonStates();
    }

    /**
     * 显示物料对话框（新增）
     */
    private void showMaterialDialog() {
        // 确保selectedMaterial为null，防止误认为是编辑操作
        selectedMaterial = null;
        showMaterialDialog(-1);
    }

    /**
     * 显示物料对话框（编辑）
     */
    private void showMaterialDialog(int rowIndex) {
        JDialog dialog = new JDialog(this, rowIndex < 0 ? "新增物料" : "编辑物料", true);
        dialog.setSize(500, 450);
        dialog.setLocationRelativeTo(this);

        // 创建表单
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(5, 5, 5, 5);

        // 表单字段
        // 物料编码由系统自动生成，不提供输入字段
        JLabel materialCodeLabel = new JLabel("系统自动生成");
        JTextField nameField = new JTextField(20);
        JTextField specificationField = new JTextField(20);
        // 创建可编辑的下拉框，包含所有常用单位
        JComboBox<String> unitCombo = new JComboBox<>();
        unitCombo.setEditable(true);  // 设置下拉框可编辑

        // 从服务器加载单位列表
        try {
            // 添加空选项
            unitCombo.addItem("");

            // 从服务器获取单位列表
            String url = SERVER_URL + "/materials/units";
            String response = HttpClientUtil.getJson(url);

            // 解析响应
            Map<String, Object> result = objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});

            if (Boolean.TRUE.equals(result.get("success"))) {
                @SuppressWarnings("unchecked")
                List<String> units = (List<String>) result.get("data");

                // 添加常用单位（确保基本单位始终存在）
                String[] commonUnits = {"个", "件", "套", "公斤", "吨", "升", "米", "毫米", "箱", "包", "瓶", "袋", "卷", "桶", "台"};
                java.util.LinkedHashSet<String> allUnits = new java.util.LinkedHashSet<>();  // 使用LinkedHashSet保持顺序且去重

                // 先添加常用单位
                for (String unit : commonUnits) {
                    allUnits.add(unit);
                }

                // 再添加服务器返回的单位（如果不在常用单位中）
                if (units != null) {
                    for (String unit : units) {
                        if (unit != null && !unit.trim().isEmpty()) {
                            allUnits.add(unit.trim());
                        }
                    }
                }

                // 将所有单位添加到下拉框
                for (String unit : allUnits) {
                    unitCombo.addItem(unit);
                }
            } else {
                // 如果获取失败，使用默认单位
                String[] defaultUnits = {"", "个", "件", "套", "公斤", "吨", "升", "米", "毫米", "箱", "包", "瓶", "袋", "卷", "桶", "台"};
                for (String unit : defaultUnits) {
                    unitCombo.addItem(unit);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            // 如果发生异常，使用默认单位
            String[] defaultUnits = {"", "个", "件", "套", "公斤", "吨", "升", "米", "毫米", "箱", "包", "瓶", "袋", "卷", "桶", "台"};
            for (String unit : defaultUnits) {
                unitCombo.addItem(unit);
            }
        }
        JTextField quantityField = new JTextField(20);
        quantityField.setEditable(true);
        quantityField.setText("0");
        JTextField minStockField = new JTextField(20);
        minStockField.setEditable(true);
        minStockField.setText("0");
        JTextField priceField = new JTextField(20);
        priceField.setText("0.00");
        JTextArea remarkArea = new JTextArea(3, 20);

        // 如果是编辑模式，填充现有数据
        if (rowIndex >= 0) {
            selectedMaterial = materialList.get(rowIndex);
            // 编辑模式下显示物料编码，但不提供输入字段
            nameField.setText(selectedMaterial.get("name") != null ? selectedMaterial.get("name").toString() : "");
            specificationField.setText(selectedMaterial.get("specification") != null ? selectedMaterial.get("specification").toString() : "");

            String unit = selectedMaterial.get("unit") != null ? selectedMaterial.get("unit").toString() : "";
            boolean found = false;
            for (int i = 0; i < unitCombo.getItemCount(); i++) {
                if (unitCombo.getItemAt(i).equals(unit)) {
                    unitCombo.setSelectedIndex(i);
                    found = true;
                    break;
                }
            }
            // 如果单位不在预设列表中，直接设置编辑框的值
            if (!found && !unit.isEmpty()) {
                unitCombo.setSelectedItem(unit);
            }

            quantityField.setText(selectedMaterial.get("quantity") != null ? selectedMaterial.get("quantity").toString() : "0");
            minStockField.setText(selectedMaterial.get("minStock") != null ? selectedMaterial.get("minStock").toString() : "0");
            priceField.setText(selectedMaterial.get("price") != null ? selectedMaterial.get("price").toString() : "0.00");
            remarkArea.setText(selectedMaterial.get("remark") != null ? selectedMaterial.get("remark").toString() : "");

            // 物料编码不可编辑（禁止修改物料编码）
            // 注意：此处已将materialCodeField改为materialCodeLabel，不再有materialCodeField变量
        }

        // 添加表单字段
        addFormField(formPanel, gbc, 0, "物料编码:", materialCodeLabel);
        addFormField(formPanel, gbc, 1, "名称:", nameField);
        addFormField(formPanel, gbc, 2, "规格:", specificationField);
        addFormField(formPanel, gbc, 3, "单位:", unitCombo);
        addFormField(formPanel, gbc, 4, "库存数量:", quantityField);
        addFormField(formPanel, gbc, 5, "最低库存:", minStockField);
        addFormField(formPanel, gbc, 6, "价格:", priceField);
        addFormField(formPanel, gbc, 7, "备注:", new JScrollPane(remarkArea));

        // 按钮面板
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton saveButton = new JButton("保存");
        JButton cancelButton = new JButton("取消");

        saveButton.setPreferredSize(new Dimension(80, 30));
        cancelButton.setPreferredSize(new Dimension(80, 30));

        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);

        // 主面板
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        dialog.add(mainPanel);

        // 保存按钮事件
        saveButton.addActionListener(e -> {
            try {
                // 物料编码由系统自动生成，不需要验证
                // 注意：materialCodeField已改为materialCodeLabel，不再有materialCodeField变量

                if (nameField.getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "名称不能为空", "错误", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // 验证库存数量是否为整数
                try {
                    int quantity = Integer.parseInt(quantityField.getText().trim());
                    if (quantity < 0) {
                        JOptionPane.showMessageDialog(dialog, "库存数量不能为负数", "错误", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(dialog, "库存数量必须是整数", "错误", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // 验证最低库存是否为整数
                try {
                    int minStock = Integer.parseInt(minStockField.getText().trim());
                    if (minStock < 0) {
                        JOptionPane.showMessageDialog(dialog, "最低库存不能为负数", "错误", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(dialog, "最低库存必须是整数", "错误", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // 如果是新增模式，检查物料编码是否已存在
                if (selectedMaterial == null || selectedMaterial.get("id") == null) {
                    try {
                        // 物料编码由系统自动生成，不需要检查
                        // 跳过检查物料编码是否存在的逻辑
                        // 物料编码由系统自动生成，不需要检查
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        // 物料编码由系统自动生成，不需要检查
                        // 但仍需要捕获异常，以防其他错误
                        JOptionPane.showMessageDialog(dialog, "保存物料失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                // 准备物料数据
                Map<String, Object> materialData = new HashMap<>();
                // 物料编码由系统自动生成，不需要从表单获取
                materialData.put("materialCode", null); // 设置为null，让后端自动生成
                materialData.put("name", nameField.getText().trim());
                materialData.put("specification", specificationField.getText().trim());
                materialData.put("unit", unitCombo.getSelectedItem());
                // 库存数量使用整数类型，与后端Material实体保持一致
                materialData.put("quantity", Integer.parseInt(quantityField.getText().trim()));
                materialData.put("minStock", Integer.parseInt(minStockField.getText().trim()));
                materialData.put("price", new java.math.BigDecimal(priceField.getText().trim()));
                materialData.put("remark", remarkArea.getText().trim());

                // 如果是编辑模式，添加物料ID
                if (selectedMaterial != null && selectedMaterial.get("id") != null) {
                    materialData.put("id", Long.valueOf(selectedMaterial.get("id").toString()));

                    // 物料编码不可修改，不需要检查编码是否重复
                }

                // 发送请求
                String url;
                String response;

                // 如果是编辑模式，使用PUT方法并包含ID
                if (selectedMaterial != null && selectedMaterial.get("id") != null) {
                    url = SERVER_URL + "/materials/" + selectedMaterial.get("id");
                    response = HttpClientUtil.putJson(url, materialData);
                } else {
                    // 如果是新增模式，使用POST方法
                    url = SERVER_URL + "/materials";
                    response = HttpClientUtil.postJson(url, materialData);
                }

                // 解析响应
                Map<String, Object> result = objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});

                if (Boolean.TRUE.equals(result.get("success"))) {
                    // 如果是新增模式，从响应中获取生成的物料信息
                    if (selectedMaterial == null || selectedMaterial.get("id") == null) {
                        Map<String, Object> savedMaterial = (Map<String, Object>) result.get("data");
                        if (savedMaterial != null) {
                            // 物料编码由系统自动生成，不需要更新
                        }
                    }
                    JOptionPane.showMessageDialog(dialog, "保存成功", "成功", JOptionPane.INFORMATION_MESSAGE);
                    dialog.dispose();
                    // 使用多条件搜索刷新数据，而不是简单的关键词搜索
                    loadMaterialDataWithFilters();
                } else {
                    JOptionPane.showMessageDialog(dialog, "保存失败: " + result.get("message"), "错误", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(dialog, "保存失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            }
        });

        // 取消按钮事件
        cancelButton.addActionListener(e -> {
            dialog.dispose();
        });

        dialog.setVisible(true);
    }

    /**
     * 删除物料
     */
    private void deleteMaterial(int rowIndex) {
        try {
            selectedMaterial = materialList.get(rowIndex);
            Long materialId = Long.valueOf(selectedMaterial.get("id").toString());

            // 发送删除请求
            String url = SERVER_URL + "/materials/" + materialId;
            String response = HttpClientUtil.deleteJson(url, null);

            // 解析响应
            Map<String, Object> result = objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});

            if (Boolean.TRUE.equals(result.get("success"))) {
                JOptionPane.showMessageDialog(this, "删除成功", "成功", JOptionPane.INFORMATION_MESSAGE);
                // 使用多条件搜索刷新数据，而不是简单的关键词搜索
                loadMaterialDataWithFilters();
            } else {
                JOptionPane.showMessageDialog(this, "删除失败: " + result.get("message"), "错误", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "删除失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * 添加表单字段
     */
    private void addFormField(JPanel panel, GridBagConstraints gbc, int row, String labelText, JComponent component) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(new JLabel(labelText), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(component, gbc);

        gbc.weightx = 0;
    }

    /**
     * 从服务器加载单位列表
     */
    private void loadUnitsFromServer() {
        try {
            // 添加空选项
            unitCombo.addItem("");

            // 从服务器获取单位列表
            String url = SERVER_URL + "/materials/units";
            String response = HttpClientUtil.getJson(url);

            // 解析响应
            Map<String, Object> result = objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {});

            if (Boolean.TRUE.equals(result.get("success"))) {
                @SuppressWarnings("unchecked")
                List<String> units = (List<String>) result.get("data");

                // 添加常用单位（确保基本单位始终存在）
                String[] commonUnits = {"个", "件", "套", "公斤", "吨", "升", "米", "毫米", "箱", "包", "瓶", "袋", "卷", "桶", "台"};
                java.util.LinkedHashSet<String> allUnits = new java.util.LinkedHashSet<>();  // 使用LinkedHashSet保持顺序且去重

                // 先添加常用单位
                for (String unit : commonUnits) {
                    allUnits.add(unit);
                }

                // 再添加服务器返回的单位（如果不在常用单位中）
                if (units != null) {
                    for (String unit : units) {
                        if (unit != null && !unit.trim().isEmpty()) {
                            allUnits.add(unit.trim());
                        }
                    }
                }

                // 将所有单位添加到下拉框
                for (String unit : allUnits) {
                    unitCombo.addItem(unit);
                }
            } else {
                // 如果获取失败，使用默认单位
                String[] defaultUnits = {"", "个", "件", "套", "公斤", "吨", "升", "米", "毫米", "箱", "包", "瓶", "袋", "卷", "桶", "台"};
                for (String unit : defaultUnits) {
                    unitCombo.addItem(unit);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            // 如果发生异常，使用默认单位
            String[] defaultUnits = {"", "个", "件", "套", "公斤", "吨", "升", "米", "毫米", "箱", "包", "瓶", "袋", "卷", "桶", "台"};
            for (String unit : defaultUnits) {
                unitCombo.addItem(unit);
            }
        }
    }
}