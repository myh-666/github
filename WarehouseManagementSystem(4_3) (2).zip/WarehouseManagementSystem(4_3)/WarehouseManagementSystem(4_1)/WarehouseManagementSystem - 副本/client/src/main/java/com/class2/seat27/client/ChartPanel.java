
package com.class2.seat27.client;

import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;

/**
 * 图表面板类
 * 用于显示物料统计的图形
 */
public class ChartPanel extends JPanel {
    private List<Map<String, Object>> data;

    public ChartPanel() {
        setPreferredSize(new Dimension(800, 300));
        setBackground(Color.WHITE);
    }

    public void setData(List<Map<String, Object>> data) {
        this.data = data;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        // 清除背景
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, getWidth(), getHeight());

        if (data == null || data.isEmpty()) {
            // 显示占位文本
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.setColor(Color.GRAY);
            g2d.setFont(new Font("宋体", Font.PLAIN, 14));
            String message = "图表区域 (仅物料统计显示图表)";
            int messageWidth = g2d.getFontMetrics().stringWidth(message);
            g2d.drawString(message, (getWidth() - messageWidth) / 2, getHeight() / 2);
            return;
        }

        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();
        int padding = 50;
        int legendY = 60;

        // 绘制坐标轴
        g2d.drawLine(padding, height - padding, width - padding, height - padding); // X轴
        g2d.drawLine(padding, padding, padding, height - padding); // Y轴
        
        // 绘制零值线（X轴的延长线），用于区分正负值
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.setStroke(new BasicStroke(1.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 5.0f, new float[]{5.0f}, 0.0f));
        g2d.drawLine(padding, height - padding, width - padding, height - padding);
        g2d.setStroke(new BasicStroke(1.0f)); // 恢复默认线宽

        // 绘制标题
        g2d.setFont(new Font("宋体", Font.BOLD, 16));
        g2d.drawString("物料流量统计", width / 2 - 50, 30);

        // 绘制X轴标签
        g2d.setFont(new Font("宋体", Font.PLAIN, 12));
        g2d.drawString("物料", width / 2, height - 10);

        // 绘制Y轴标签
        g2d.drawString("数量", 10, height / 2);

        // 绘制图例
        g2d.setFont(new Font("宋体", Font.PLAIN, 12));
        g2d.setColor(Color.BLUE);
        g2d.fillRect(width - 150, legendY, 15, 15);
        g2d.setColor(Color.BLACK);
        g2d.drawString("进仓", width - 130, legendY + 12);

        g2d.setColor(Color.RED);
        g2d.fillRect(width - 150, legendY + 25, 15, 15);
        g2d.setColor(Color.BLACK);
        g2d.drawString("出仓", width - 130, legendY + 37);

        g2d.setColor(Color.GREEN);
        g2d.fillRect(width - 150, legendY + 50, 15, 15);
        g2d.setColor(Color.BLACK);
        g2d.drawString("净流量", width - 130, legendY + 62);

        // 计算数据范围
        double maxInbound = 0;
        double maxOutbound = 0;
        double maxNetFlow = 0;
        double minNetFlow = 0; // 添加最小净流量值

        for (Map<String, Object> item : data) {
            double inboundValue = Double.parseDouble(item.getOrDefault("inbound_quantity", 0).toString());
            double outboundValue = Double.parseDouble(item.getOrDefault("outbound_quantity", 0).toString());
            double netFlowValue = Double.parseDouble(item.getOrDefault("net_flow", 0).toString());

            if (inboundValue > maxInbound) maxInbound = inboundValue;
            if (outboundValue > maxOutbound) maxOutbound = outboundValue;
            if (Math.abs(netFlowValue) > maxNetFlow) maxNetFlow = Math.abs(netFlowValue);
            if (netFlowValue < minNetFlow) minNetFlow = netFlowValue; // 记录最小净流量值
        }

        // 修改最大值计算，确保考虑净流量的负值范围
        double maxValue = Math.max(Math.max(maxInbound, maxOutbound), maxNetFlow);
        // 如果净流量有负值，需要确保图表范围包含负值
        if (minNetFlow < 0) {
            maxValue = Math.max(maxValue, Math.abs(minNetFlow));
        }
        if (maxValue == 0) maxValue = 1; // 避免除零错误

        // 绘制数据点和连线
        if (data.size() == 0) return;
        
        int xStep = Math.max(30, (width - 2 * padding) / data.size());
        int[] inboundPoints = new int[data.size()];
        int[] outboundPoints = new int[data.size()];
        int[] netFlowPoints = new int[data.size()];
        int[] xPoints = new int[data.size()];

        for (int i = 0; i < data.size(); i++) {
            Map<String, Object> item = data.get(i);
            double inboundValue = Double.parseDouble(item.getOrDefault("inbound_quantity", 0).toString());
            double outboundValue = Double.parseDouble(item.getOrDefault("outbound_quantity", 0).toString());
            double netFlowValue = Double.parseDouble(item.getOrDefault("net_flow", 0).toString());

            xPoints[i] = padding + i * xStep;
            inboundPoints[i] = height - padding - (int) ((inboundValue / maxValue) * (height - 2 * padding));
            outboundPoints[i] = height - padding - (int) ((outboundValue / maxValue) * (height - 2 * padding));
            // 修复净流量计算，正确处理负值
            // 净流量为负值时，应该显示在X轴下方
            if (netFlowValue >= 0) {
                netFlowPoints[i] = height - padding - (int) ((netFlowValue / maxValue) * (height - 2 * padding));
            } else {
                netFlowPoints[i] = height - padding + (int) ((Math.abs(netFlowValue) / maxValue) * (height - 2 * padding));
            }

            // 绘制数据点
            // 进仓数据点
            g2d.setColor(Color.BLUE);
            g2d.fillOval(xPoints[i] - 3, inboundPoints[i] - 3, 6, 6);

            // 出仓数据点
            g2d.setColor(Color.RED);
            g2d.fillOval(xPoints[i] - 3, outboundPoints[i] - 3, 6, 6);

            // 净流量数据点
            g2d.setColor(Color.GREEN);
            g2d.fillOval(xPoints[i] - 3, netFlowPoints[i] - 3, 6, 6);

            // 绘制数据标签
            g2d.setColor(Color.BLACK);
            String label = item.getOrDefault("material_code", "").toString();
            if (label.length() > 8) {
                label = label.substring(0, 7) + "...";
            }
            g2d.drawString(label, xPoints[i] - 20, height - padding + 20);
        }

        // 绘制连线
        // 进仓连线
        g2d.setColor(Color.BLUE);
        g2d.drawPolyline(xPoints, inboundPoints, data.size());

        // 出仓连线
        g2d.setColor(Color.RED);
        g2d.drawPolyline(xPoints, outboundPoints, data.size());

        // 净流量连线
        g2d.setColor(Color.GREEN);
        g2d.drawPolyline(xPoints, netFlowPoints, data.size());
    }

    private static final DecimalFormat decimalFormat = new DecimalFormat("#,##0.##");
}
