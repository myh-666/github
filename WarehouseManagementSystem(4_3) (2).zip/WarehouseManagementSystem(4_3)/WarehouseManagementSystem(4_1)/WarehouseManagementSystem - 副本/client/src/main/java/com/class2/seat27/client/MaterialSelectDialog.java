package com.class2.seat27.client;

import com.class2.seat27.client.http.HttpClientUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

/**
 * 物料选择对话框类
 * 用于选择物料
 */
public class MaterialSelectDialog extends JDialog {
    private JTextField searchField;
    private JButton searchButton;
    private JButton selectButton;
    private JButton cancelButton;

    private JTable materialTable;
    private DefaultTableModel tableModel;

    private List<Map<String, Object>> materialList;
    private Map<String, Object> selectedMaterial;
    private boolean confirmed = false;

    private static final String SERVER_URL = "http://localhost:8081/api/warehouse";
    private static final ObjectMapper objectMapper = new ObjectMapper();

    private String username;
    private String operationType; // INBOUND 或 OUTBOUND

    public MaterialSelectDialog(JFrame parent, String username) {
        this(parent, username, null);
    }

    public MaterialSelectDialog(JFrame parent, String username, String operationType) {
        super(parent, "选择物料", true);
        this.username = username;
        this.operationType = operationType;

        initComponents();
        setupLayout();
        setupListeners();
        loadData();

        setSize(800, 500);
        setLocationRelativeTo(parent);
    }

    private void initComponents() {
        // 搜索区域
        searchField = new JTextField(20);
        searchButton = new JButton("搜索");
        searchButton.setPreferredSize(new Dimension(80, 30));

        // 按钮区域
        selectButton = new JButton("选择");
        cancelButton = new JButton("取消");

        // 设置按钮大小
        selectButton.setPreferredSize(new Dimension(100, 30));
        cancelButton.setPreferredSize(new Dimension(100, 30));

        // 物料表格
        tableModel = new DefaultTableModel(
            new Object[]{"ID", "物料编码", "物料名称", "规格", "单位", "库存数量"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // 所有单元格都不可编辑
            }
        };

        materialTable = new JTable(tableModel);
    }

    private void setupLayout() {
        setLayout(new BorderLayout(10, 10));
        
        // 创建主面板并设置边框
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // 顶部面板 - 搜索和按钮
        JPanel topPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0;
        gbc.gridy = 0;
        topPanel.add(new JLabel("搜索:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        topPanel.add(searchField, gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.NONE;
        topPanel.add(searchButton, gbc);

        gbc.gridx = 3;
        gbc.gridy = 0;
        gbc.insets = new Insets(5, 20, 5, 5);
        topPanel.add(selectButton, gbc);

        gbc.gridx = 4;
        gbc.gridy = 0;
        topPanel.add(cancelButton, gbc);

        // 中间面板 - 物料表格
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(new JScrollPane(materialTable), BorderLayout.CENTER);

        // 添加到主面板
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        add(mainPanel, BorderLayout.CENTER);
    }

    private void setupListeners() {
        searchButton.addActionListener(e -> {
            String keyword = searchField.getText().trim();
            loadData(keyword);
        });
        selectButton.addActionListener(e -> {
            int selectedRow = materialTable.getSelectedRow();
            if (selectedRow < 0) {
                JOptionPane.showMessageDialog(this, "请选择要使用的物料", "提示", JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            // 对于出仓操作，检查库存是否足够
            if ("OUTBOUND".equals(operationType)) {
                Map<String, Object> material = materialList.get(selectedRow);
                Object quantityObj = material.get("quantity");
                int availableQuantity = 0;
                if (quantityObj != null) {
                    try {
                        if (quantityObj instanceof Number) {
                            availableQuantity = ((Number) quantityObj).intValue();
                        } else {
                            availableQuantity = Integer.parseInt(quantityObj.toString());
                        }
                    } catch (NumberFormatException ex) {
                        // 解析失败，默认为0
                    }
                }
                
                if (availableQuantity <= 0) {
                    JOptionPane.showMessageDialog(this, "该物料库存不足，无法选择", "库存不足", JOptionPane.WARNING_MESSAGE);
                    return;
                }
            }
            
            selectedMaterial = materialList.get(selectedRow);
            confirmed = true;
            dispose();
        });
        cancelButton.addActionListener(e -> {
            confirmed = false;
            dispose();
        });
        materialTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = materialTable.rowAtPoint(e.getPoint());
                if (row >= 0) {
                    materialTable.setRowSelectionInterval(row, row);
                }
            }
        });
    }

    private void loadData() {
        loadData("");
    }

    private void loadData(String keyword) {
        try {
            String url = SERVER_URL + "/materials";
            if (!keyword.isEmpty()) {
                url += "?keyword=" + java.net.URLEncoder.encode(keyword, "UTF-8") + "&username=" + username;
            } else {
                url += "?username=" + username;
            }
            String response = HttpClientUtil.getJson(url);
            if (response == null || response.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "服务器未返回数据", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }
            Map<String, Object> result = objectMapper.readValue(response, Map.class);
            tableModel.setRowCount(0);
            materialList = new ArrayList<>();
            if (Boolean.TRUE.equals(result.get("success"))) {
                Object data = result.get("data");
                if (data instanceof List) {
                    List<Map<String, Object>> list = (List<Map<String, Object>>) data;
                    materialList.addAll(list);
                    for (Map<String, Object> item : list) {
                        tableModel.addRow(new Object[]{
                            item.getOrDefault("id", ""),
                            item.getOrDefault("materialCode", "未知编码"),
                            item.getOrDefault("name", "未知物料"),
                            item.getOrDefault("specification", ""),
                            item.getOrDefault("unit", ""),
                            item.getOrDefault("quantity", 0)
                        });
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, String.valueOf(result.get("message")), "错误", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "加载物料失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public Map<String, Object> getSelectedMaterial() {
        return selectedMaterial;
    }
}