package com.class2.seat27.client;

import com.class2.seat27.client.http.HttpClientUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.SwingConstants;
import javax.swing.SpinnerDateModel;
import javax.swing.JSpinner;
import javax.swing.JLabel;

/**
 * 报表统计界面类
 * 用于生成各种报表
 */
public class ReportFrame extends JFrame {
    private JComboBox<String> reportTypeCombo;
    private JButton generateButton;
    private JButton printButton;
    private JButton backButton;
    private JButton exportButton;
    private JPanel paramPanel;
    private JTextField startDateField;
    private JTextField endDateField;
    private JButton startDateButton;
    private JButton endDateButton;
    private JTextField yearField;
    private JTextField monthField;
    private JComboBox<String> materialCombo;
    private JLabel minFlowLabel;
    private JLabel statusLabel;

    private JTable reportTable;
    private DefaultTableModel tableModel;
    private ChartPanel chartPanel;

    private static final String SERVER_URL = "http://localhost:8081/api";
    private static final String REPORTS_URL = "http://localhost:8081/api/reports";
    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static final DecimalFormat decimalFormat = new DecimalFormat("#,##0.##");
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    private static final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private String username;
    private String reportType; // MATERIAL, IN_OUT, LEDGER
    private List<Map<String, Object>> materialList;

    /**
     * 获取报表类型
     * @return 报表类型字符串
     */
    public String getReportType() {
        return reportType;
    }

    public ReportFrame(MainFrame parentFrame, String username, String reportType) {
        this.username = username;
        this.reportType = reportType;

        initComponents();
        setupLayout();
        setupListeners();
        setupDatePickers();

        // 根据传入的reportType设置下拉框的选中项
        switch (reportType) {
            case "MATERIAL":
                reportTypeCombo.setSelectedIndex(0); // 物料统计
                break;
            case "LOW_INVENTORY":
                reportTypeCombo.setSelectedIndex(1); // 低库存预警
                break;
            case "IN_OUT":
                reportTypeCombo.setSelectedIndex(2); // 进出仓单
                break;
            case "LEDGER":
                reportTypeCombo.setSelectedIndex(3); // 仓库账本
                break;
            default:
                reportTypeCombo.setSelectedIndex(0); // 默认选择物料统计
                break;
        }

        setTitle(getReportTitle() + " - 当前用户: " + username);
        setSize(1200, 700);
        setLocationRelativeTo(parentFrame);
        loadMaterials();
        updateStatus("就绪");
    }

    private String getReportTitle() {
        switch (reportType) {
            case "MATERIAL":
                return "物料统计报表";
            case "LOW_INVENTORY":
                return "低库存预警报表";
            case "IN_OUT":
                return "进出仓单打印";
            case "LEDGER":
                return "仓库账本打印";
            default:
                return "报表统计";
        }
    }

    private void initComponents() {
        // 报表类型选择
        reportTypeCombo = new JComboBox<>();
        reportTypeCombo.addItem("物料统计");
        reportTypeCombo.addItem("低库存预警");
        reportTypeCombo.addItem("进出仓单");
        reportTypeCombo.addItem("仓库账本");

        // 参数面板
        paramPanel = new JPanel(new GridBagLayout());

        // 日期选择
        startDateField = new JTextField(10);
        endDateField = new JTextField(10);
        startDateButton = new JButton("选择日期");
        endDateButton = new JButton("选择日期");
        yearField = new JTextField(4);
        monthField = new JTextField(2);

        // 物料选择
        materialCombo = new JComboBox<>();

        // 最小流动量标签
        minFlowLabel = new JLabel("");

        // 状态标签
        statusLabel = new JLabel("就绪");

        // 按钮
        generateButton = new JButton("生成报表");
        printButton = new JButton("打印");
        exportButton = new JButton("导出Excel");
        backButton = new JButton("返回主菜单");

        // 设置按钮大小
        generateButton.setPreferredSize(new Dimension(100, 30));
        printButton.setPreferredSize(new Dimension(80, 30));
        exportButton.setPreferredSize(new Dimension(100, 30));
        backButton.setPreferredSize(new Dimension(120, 30));

        // 报表表格
        tableModel = new DefaultTableModel(
                new Object[]{"序号", "日期", "单据编号", "物料名称", "规格", "单位", "数量", "单价", "总价", "备注"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // 所有单元格都不可编辑
            }
        };

        reportTable = new JTable(tableModel);
        reportTable.setAutoCreateRowSorter(true); // 启用表格排序
        reportTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // 图表面板
        chartPanel = new ChartPanel();
    }

    private void setupLayout() {
        setLayout(new BorderLayout(10, 10));

        // 创建主面板并设置边框
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));

        // 顶部面板 - 报表类型和按钮
        JPanel topPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0;
        gbc.gridy = 0;
        topPanel.add(new JLabel("报表类型:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        topPanel.add(reportTypeCombo, gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.insets = new Insets(5, 20, 5, 5);
        topPanel.add(generateButton, gbc);

        gbc.gridx = 3;
        gbc.gridy = 0;
        topPanel.add(printButton, gbc);

        gbc.gridx = 4;
        gbc.gridy = 0;
        topPanel.add(exportButton, gbc);

        gbc.gridx = 5;
        gbc.gridy = 0;
        topPanel.add(backButton, gbc);

        // 中间面板 - 参数和报表
        JPanel centerPanel = new JPanel(new BorderLayout());

        // 参数面板
        JPanel paramContainer = new JPanel(new BorderLayout());
        paramContainer.setBorder(BorderFactory.createTitledBorder("查询参数"));
        paramContainer.add(new JScrollPane(paramPanel), BorderLayout.CENTER);

        // 报表表格和图表
        JPanel tableAndChartPanel = new JPanel(new BorderLayout());
        JScrollPane tableScrollPane = new JScrollPane(reportTable);
        tableScrollPane.setBorder(BorderFactory.createTitledBorder("报表数据"));
        tableAndChartPanel.add(tableScrollPane, BorderLayout.CENTER);

        // 图表面板
        JPanel chartContainer = new JPanel(new BorderLayout());
        chartContainer.setBorder(BorderFactory.createTitledBorder("统计图表"));
        chartContainer.add(chartPanel, BorderLayout.CENTER);
        chartContainer.setPreferredSize(new Dimension(getWidth(), 300));
        tableAndChartPanel.add(chartContainer, BorderLayout.SOUTH);

        centerPanel.add(paramContainer, BorderLayout.NORTH);
        centerPanel.add(tableAndChartPanel, BorderLayout.CENTER);

        // 状态栏
        JPanel statusPanel = new JPanel(new BorderLayout());
        statusPanel.setBorder(BorderFactory.createEtchedBorder());
        statusPanel.add(statusLabel, BorderLayout.WEST);
        JLabel recordCountLabel = new JLabel("记录数: 0");
        statusPanel.add(recordCountLabel, BorderLayout.EAST);

        // 添加到主面板
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        mainPanel.add(statusPanel, BorderLayout.SOUTH);

        add(mainPanel, BorderLayout.CENTER);

        // 初始化参数面板
        updateParameterPanel();
        updateTableColumns();
    }

    private void updateTableColumns() {
        String type = reportTypeCombo.getSelectedItem().toString();

        // 清空现有列
        tableModel.setColumnCount(0);

        // 根据报表类型设置不同的列标题
        if (type.equals("物料统计")) {
            tableModel.setColumnIdentifiers(new Object[]{"序号", "物料代码", "物料名称", "规格", "单位", "进仓数量", "进仓金额", "出仓数量", "出仓金额", "净流量", "净金额", "库存状态"});
        } else if (type.equals("低库存预警")) {
            tableModel.setColumnIdentifiers(new Object[]{"序号", "物料代码", "物料名称", "规格", "单位", "当前库存", "最低库存", "库存状态", "预警级别", "建议补货数量"});
        } else if (type.equals("进出仓单")) {
            tableModel.setColumnIdentifiers(new Object[]{"序号", "记录ID", "单据编号", "操作类型", "操作日期", "操作人", "经手人", "状态", "物料代码", "物料名称", "规格", "单位", "数量", "单价", "总价", "备注"});
        } else if (type.equals("仓库账本")) {
            tableModel.setColumnIdentifiers(new Object[]{"序号", "账本日期", "单据编号", "操作类型", "物料代码", "物料名称", "规格", "单位", "入库数量", "出库数量", "结余数量", "单价", "金额", "备注"});
        }
    }

    private void updateParameterPanel() {
        paramPanel.removeAll();

        // 初始化当前日期
        LocalDate today = LocalDate.now();

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int row = 0;

        switch (reportTypeCombo.getSelectedItem().toString()) {
            case "物料统计":
            case "低库存预警":
                gbc.gridx = 0;
                gbc.gridy = row;
                paramPanel.add(new JLabel("开始日期:"), gbc);

                gbc.gridx = 1;
                gbc.gridy = row;
                paramPanel.add(startDateField, gbc);

                gbc.gridx = 2;
                gbc.gridy = row;
                paramPanel.add(startDateButton, gbc);

                gbc.gridx = 3;
                gbc.gridy = row;
                paramPanel.add(new JLabel("结束日期:"), gbc);

                gbc.gridx = 4;
                gbc.gridy = row;
                paramPanel.add(endDateField, gbc);

                gbc.gridx = 5;
                gbc.gridy = row;
                paramPanel.add(endDateButton, gbc);

                // 设置默认日期
                LocalDate oneMonthAgo = today.minusMonths(1);
                startDateField.setText(oneMonthAgo.format(dateFormatter));
                endDateField.setText(today.format(dateFormatter));
                break;

            case "进出仓单":
                gbc.gridx = 0;
                gbc.gridy = row;
                paramPanel.add(new JLabel("年份:"), gbc);

                gbc.gridx = 1;
                gbc.gridy = row;
                paramPanel.add(yearField, gbc);

                gbc.gridx = 2;
                gbc.gridy = row;
                paramPanel.add(new JLabel("月份:"), gbc);

                gbc.gridx = 3;
                gbc.gridy = row;
                paramPanel.add(monthField, gbc);

                // 设置默认日期
                yearField.setText(String.valueOf(today.getYear()));
                monthField.setText(String.valueOf(today.getMonthValue()));
                break;

            case "仓库账本":
                gbc.gridx = 0;
                gbc.gridy = row;
                paramPanel.add(new JLabel("物料:"), gbc);

                gbc.gridx = 1;
                gbc.gridy = row;
                paramPanel.add(materialCombo, gbc);

                gbc.gridx = 2;
                gbc.gridy = row;
                paramPanel.add(new JLabel("年份:"), gbc);

                gbc.gridx = 3;
                gbc.gridy = row;
                paramPanel.add(yearField, gbc);

                // 设置默认日期
                yearField.setText(String.valueOf(today.getYear()));
                break;
        }

        paramPanel.revalidate();
        paramPanel.repaint();
    }

    private void loadMaterials() {
        try {
            updateStatus("正在加载物料列表...");
            // 使用物料API获取物料列表
            String response = HttpClientUtil.getJson("http://localhost:8081/api/warehouse/materials");
            Map<String, Object> result = objectMapper.readValue(response, Map.class);

            materialCombo.removeAllItems();
            materialList = new ArrayList<>();

            if (Boolean.TRUE.equals(result.get("success"))) {
                List<Map<String, Object>> materials = (List<Map<String, Object>>) result.get("data");

                // 确保materials不为空
                if (materials != null) {
                    for (Map<String, Object> material : materials) {
                        // 确保必要字段存在
                        String name = material.containsKey("name") ? material.get("name").toString() : "未知物料";
                        String code = material.containsKey("materialCode") ? material.get("materialCode").toString() :
                                (material.containsKey("material_code") ? material.get("material_code").toString() : "未知编码");

                        materialCombo.addItem(name + " (" + code + ")");
                        materialList.add(material);
                    }
                    updateStatus("物料列表加载完成，共 " + materials.size() + " 个物料");
                } else {
                    updateStatus("物料列表为空");
                }
            } else {
                updateStatus("获取物料列表失败: " + result.get("message"));
                JOptionPane.showMessageDialog(this, "获取物料列表失败: " + result.get("message"), "错误", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            updateStatus("加载物料列表失败: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "加载物料列表失败: " + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void setupDatePickers() {
        // 设置开始日期选择按钮
        startDateButton.addActionListener(e -> {
            // 获取当前结束日期作为默认值，如果没有则使用当前日期
            java.time.LocalDate defaultDate = java.time.LocalDate.now();
            try {
                String endDateText = endDateField.getText().trim();
                if (!endDateText.isEmpty()) {
                    defaultDate = java.time.LocalDate.parse(endDateText, dateFormatter);
                }
            } catch (Exception ex) {
                // 如果解析失败，使用当前日期
            }

            java.time.LocalDate selectedDate = showDatePicker(defaultDate.minusMonths(1));
            if (selectedDate != null) {
                startDateField.setText(selectedDate.format(dateFormatter));
                // 验证日期范围
                validateDateRange();
            }
        });

        // 设置结束日期选择按钮
        endDateButton.addActionListener(e -> {
            // 获取当前开始日期作为默认值，如果没有则使用当前日期
            java.time.LocalDate defaultDate = java.time.LocalDate.now();
            try {
                String startDateText = startDateField.getText().trim();
                if (!startDateText.isEmpty()) {
                    defaultDate = java.time.LocalDate.parse(startDateText, dateFormatter);
                }
            } catch (Exception ex) {
                // 如果解析失败，使用当前日期
            }

            java.time.LocalDate selectedDate = showDatePicker(defaultDate);
            if (selectedDate != null) {
                endDateField.setText(selectedDate.format(dateFormatter));
                // 验证日期范围
                validateDateRange();
            }
        });

        // 添加日期字段输入监听器，在用户手动输入后验证
        startDateField.addActionListener(e -> validateDateRange());
        endDateField.addActionListener(e -> validateDateRange());

        // 添加焦点失去监听器，在用户完成输入后验证
        startDateField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent e) {
                validateDateRange();
            }
        });

        endDateField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent e) {
                validateDateRange();
            }
        });
    }

    private java.time.LocalDate showDatePicker(java.time.LocalDate initialDate) {
        // 创建日期选择对话框
        JDialog dialog = new JDialog(this, "选择日期", true);
        dialog.setLayout(new BorderLayout());
        dialog.setSize(300, 200);
        dialog.setLocationRelativeTo(this);

        // 创建日期输入面板
        JPanel datePanel = new JPanel(new FlowLayout());
        SpinnerDateModel dateModel = new SpinnerDateModel(java.sql.Date.valueOf(initialDate), null, null, java.util.Calendar.DAY_OF_MONTH);
        JSpinner dateSpinner = new JSpinner(dateModel);
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, "yyyy-MM-dd");
        dateSpinner.setEditor(dateEditor);
        datePanel.add(new JLabel("选择日期:"));
        datePanel.add(dateSpinner);

        // 添加按钮面板
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton okButton = new JButton("确定");
        JButton cancelButton = new JButton("取消");

        buttonPanel.add(okButton);
        buttonPanel.add(cancelButton);

        // 将面板添加到对话框
        dialog.add(datePanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);

        // 设置按钮事件
        final java.time.LocalDate[] selectedDate = {null};
        okButton.addActionListener(e -> {
            java.util.Date date = (java.util.Date) dateSpinner.getValue();
            if (date != null) {
                selectedDate[0] = date.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
            }
            dialog.dispose();
        });

        cancelButton.addActionListener(e -> dialog.dispose());

        dialog.setVisible(true);
        return selectedDate[0];
    }

    private void setupListeners() {
        reportTypeCombo.addActionListener(e -> {
            updateParameterPanel();
            updateTableColumns();
            tableModel.setRowCount(0); // 清空表格数据
            updateStatus("报表类型已切换");
        });

        generateButton.addActionListener(e -> {
            loadReportData();
        });

        exportButton.addActionListener(e -> {
            exportToExcel();
        });

        printButton.addActionListener(e -> {
            printReport();
        });

        backButton.addActionListener(e -> {
            this.dispose();
        });

        // 表格行选择监听器
        reportTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = reportTable.rowAtPoint(e.getPoint());
                if (row >= 0) {
                    reportTable.setRowSelectionInterval(row, row);
                }
            }
        });
    }

    /**
     * 验证日期范围是否有效
     * @return 如果日期范围有效返回true，否则返回false
     */
    private boolean validateDateRange() {
        String startDateStr = startDateField.getText().trim();
        String endDateStr = endDateField.getText().trim();

        // 检查日期字段是否为空
        if (startDateStr.isEmpty() || endDateStr.isEmpty()) {
            return false;
        }

        try {
            LocalDate startDate = LocalDate.parse(startDateStr, dateFormatter);
            LocalDate endDate = LocalDate.parse(endDateStr, dateFormatter);
            LocalDate today = LocalDate.now();

            // 验证开始日期不能晚于结束日期
            if (startDate.isAfter(endDate)) {
                JOptionPane.showMessageDialog(this, "开始日期不能晚于结束日期", "错误", JOptionPane.ERROR_MESSAGE);
                startDateField.requestFocus();
                return false;
            }

            // 验证结束日期不能晚于当前日期
            if (endDate.isAfter(today)) {
                JOptionPane.showMessageDialog(this, "结束日期不能晚于当前日期", "错误", JOptionPane.ERROR_MESSAGE);
                endDateField.requestFocus();
                return false;
            }

            // 限制日期范围不超过一年
            if (startDate.plusYears(1).isBefore(endDate)) {
                JOptionPane.showMessageDialog(this, "日期范围不能超过一年", "错误", JOptionPane.ERROR_MESSAGE);
                startDateField.requestFocus();
                return false;
            }

            // 限制开始日期不能早于一年前
            if (startDate.isBefore(today.minusYears(1))) {
                JOptionPane.showMessageDialog(this, "开始日期不能早于一年前", "错误", JOptionPane.ERROR_MESSAGE);
                startDateField.requestFocus();
                return false;
            }

            return true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "日期格式不正确，请使用yyyy-MM-dd格式或通过日期选择器选择", "错误", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public void loadReportData() {
        try {
            updateStatus("正在生成报表...");
            tableModel.setRowCount(0);
            String type = reportTypeCombo.getSelectedItem().toString();
            String url = REPORTS_URL;
            Map<String, Object> params = new HashMap<>();

            if (type.equals("物料统计") || type.equals("低库存预警")) {
                url += type.equals("物料统计") ? "/material-flow" : "/low-inventory";

                // 验证日期格式
                String startDateStr = startDateField.getText().trim();
                String endDateStr = endDateField.getText().trim();

                // 检查日期字段是否为空
                if (startDateStr.isEmpty() || endDateStr.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "请选择开始日期和结束日期", "错误", JOptionPane.ERROR_MESSAGE);
                    updateStatus("请选择开始日期和结束日期");
                    return;
                }

                // 使用validateDateRange方法验证日期
                if (!validateDateRange()) {
                    updateStatus("日期范围无效");
                    return;
                }

                params.put("startDate", startDateStr);
                params.put("endDate", endDateStr);
            } else if (type.equals("进出仓单")) {
                // 使用报表API获取月度进出仓数据
                url = REPORTS_URL + "/monthly-records";
                params.put("year", Integer.parseInt(yearField.getText().trim()));
                params.put("month", Integer.parseInt(monthField.getText().trim()));
            } else if (type.equals("仓库账本")) {
                url += "/warehouse-ledger";
                params.put("year", Integer.parseInt(yearField.getText().trim()));
                int idx = materialCombo.getSelectedIndex();
                if (idx >= 0 && materialList != null && idx < materialList.size()) {
                    Map<String, Object> material = materialList.get(idx);
                    // 尝试获取物料代码，支持不同的字段名
                    String materialCode = material.containsKey("materialCode") ? material.get("materialCode").toString() :
                            (material.containsKey("material_code") ? material.get("material_code").toString() : "");
                    params.put("materialCode", materialCode);
                }
            }

            String response = HttpClientUtil.postJson(url, params);
            Map<String, Object> result = objectMapper.readValue(response, Map.class);

            if (Boolean.TRUE.equals(result.get("success"))) {
                List<Map<String, Object>> list;
                Object data = result.get("data");

                if (data instanceof List) {
                    list = (List<Map<String, Object>>) data;
                } else if (type.equals("进出仓单") && result.containsKey("records")) {
                    // 处理进出仓单报表的特殊数据结构
                    list = (List<Map<String, Object>>) result.get("records");
                } else if (type.equals("仓库账本") && result.containsKey("ledger_records")) {
                    // 处理仓库账本报表的特殊数据结构
                    list = (List<Map<String, Object>>) result.get("ledger_records");
                } else {
                    list = new ArrayList<>();
                }

                // 更新图表面板数据
                if (type.equals("物料统计")) {
                    chartPanel.setData(list);
                    chartPanel.repaint(); // 确保图表重绘
                } else {
                    chartPanel.setData(null); // 其他报表类型清空图表
                    chartPanel.repaint(); // 确保图表重绘
                }

                int i = 1;
                for (Map<String, Object> item : list) {
                    // 物料统计报表数据格式
                    if (type.equals("物料统计")) {
                        tableModel.addRow(new Object[]{
                                i++,
                                item.getOrDefault("material_code", ""),
                                item.getOrDefault("material_name", ""),
                                item.getOrDefault("specification", ""),
                                item.getOrDefault("unit", ""),
                                formatNumber(item.get("inbound_quantity")),
                                formatCurrency(item.get("inbound_amount")),
                                formatNumber(item.get("outbound_quantity")),
                                formatCurrency(item.get("outbound_amount")),
                                formatNumber(item.get("net_flow")),
                                formatCurrency(item.get("net_amount")),
                                getStockStatus(item)
                        });
                    }
                    // 进出仓单报表数据格式
                    else if (type.equals("进出仓单")) {
                        tableModel.addRow(new Object[]{
                                i++,
                                item.getOrDefault("record_id", ""),
                                item.getOrDefault("document_code", ""),
                                item.getOrDefault("operation_type", ""),
                                item.getOrDefault("operation_date", ""),
                                item.getOrDefault("operator_name", ""),
                                item.getOrDefault("handler_name", ""),
                                item.getOrDefault("status", ""),
                                item.getOrDefault("material_code", ""),
                                item.getOrDefault("material_name", ""),
                                item.getOrDefault("specification", ""),
                                item.getOrDefault("unit", ""),
                                formatNumber(item.get("quantity")),
                                formatCurrency(item.get("unit_price")),
                                formatCurrency(item.get("total_price")),
                                item.getOrDefault("remark", "")
                        });
                    }
                    // 低库存预警报表数据格式
                    else if (type.equals("低库存预警")) {
                        tableModel.addRow(new Object[]{
                                i++,
                                item.getOrDefault("material_code", ""),
                                item.getOrDefault("material_name", ""),
                                item.getOrDefault("specification", ""),
                                item.getOrDefault("unit", ""),
                                formatNumber(item.get("quantity")),
                                formatNumber(item.get("min_stock")),
                                getStockStatus(item),
                                getWarningLevel(item),
                                calculateReplenishment(item)
                        });
                    }
                    // 仓库账本报表数据格式
                    else if (type.equals("仓库账本")) {
                        Object ledgerDate = item.containsKey("ledger_date") ? item.get("ledger_date") : item.get("date");
                        Object operationType = item.containsKey("operation_type") ? item.get("operation_type") :
                                item.containsKey("type") ? item.get("type") : "";
                        Object materialCode = item.containsKey("material_code") ? item.get("material_code") : item.get("code");
                        Object materialName = item.containsKey("material_name") ? item.get("material_name") : item.get("name");
                        Object inboundQuantity = item.containsKey("inbound_quantity") ? item.get("inbound_quantity") :
                                item.containsKey("in_quantity") ? item.get("in_quantity") : 0;
                        Object outboundQuantity = item.containsKey("outbound_quantity") ? item.get("outbound_quantity") :
                                item.containsKey("out_quantity") ? item.get("out_quantity") : 0;
                        Object balanceQuantity = item.containsKey("balance_quantity") ? item.get("balance_quantity") :
                                item.containsKey("balance") ? item.get("balance") : 0;

                        tableModel.addRow(new Object[]{
                                i++,
                                ledgerDate,
                                item.getOrDefault("document_code", ""),
                                operationType,
                                materialCode,
                                materialName,
                                item.getOrDefault("specification", ""),
                                item.getOrDefault("unit", ""),
                                formatNumber(inboundQuantity),
                                formatNumber(outboundQuantity),
                                formatNumber(balanceQuantity),
                                formatCurrency(item.get("unit_price")),
                                formatCurrency(item.get("amount")),
                                item.getOrDefault("remark", "")
                        });
                    }
                }

                updateStatus("报表生成完成，共 " + list.size() + " 条记录");
            } else {
                updateStatus("报表生成失败: " + result.get("message"));
                JOptionPane.showMessageDialog(this, String.valueOf(result.get("message")), "错误", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            updateStatus("加载报表失败: " + ex.getMessage());
            JOptionPane.showMessageDialog(this, "加载报表失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    /**
     * 格式化数字
     */
    private String formatNumber(Object value) {
        if (value == null) return "0";
        try {
            if (value instanceof Number) {
                return decimalFormat.format(value);
            } else {
                double num = Double.parseDouble(value.toString());
                return decimalFormat.format(num);
            }
        } catch (Exception e) {
            return value.toString();
        }
    }

    /**
     * 格式化货币
     */
    private String formatCurrency(Object value) {
        if (value == null) return "￥0.00";
        try {
            double amount = value instanceof Number ? ((Number) value).doubleValue() : Double.parseDouble(value.toString());
            return String.format("￥%.2f", amount);
        } catch (Exception e) {
            return "￥0.00";
        }
    }

    /**
     * 获取库存状态
     */
    private String getStockStatus(Map<String, Object> item) {
        try {
            Object quantityObj = item.get("quantity");
            Object minStockObj = item.get("min_stock");

            if (quantityObj == null || minStockObj == null) {
                return "正常";
            }

            int quantity = Integer.parseInt(quantityObj.toString());
            int minStock = Integer.parseInt(minStockObj.toString());

            if (quantity == 0) {
                return "<html><font color='red'>缺货</font></html>";
            } else if (quantity < minStock) {
                return "<html><font color='orange'>不足</font></html>";
            } else if (quantity <= minStock * 1.2) {
                return "<html><font color='blue'>正常</font></html>";
            } else {
                return "<html><font color='green'>充足</font></html>";
            }
        } catch (Exception e) {
            return "正常";
        }
    }

    /**
     * 获取预警级别
     */
    private String getWarningLevel(Map<String, Object> item) {
        try {
            Object quantityObj = item.get("quantity");
            Object minStockObj = item.get("min_stock");

            if (quantityObj == null || minStockObj == null) {
                return "正常";
            }

            int quantity = Integer.parseInt(quantityObj.toString());
            int minStock = Integer.parseInt(minStockObj.toString());

            if (quantity == 0) {
                return "<html><font color='red'>紧急</font></html>";
            } else if (quantity < minStock * 0.5) {
                return "<html><font color='orange'>严重</font></html>";
            } else if (quantity < minStock) {
                return "<html><font color='yellow'>警告</font></html>";
            } else {
                return "正常";
            }
        } catch (Exception e) {
            return "正常";
        }
    }

    /**
     * 计算建议补货数量
     */
    private int calculateReplenishment(Map<String, Object> item) {
        try {
            Object quantityObj = item.get("quantity");
            Object minStockObj = item.get("min_stock");

            if (quantityObj == null || minStockObj == null) {
                return 0;
            }

            int quantity = Integer.parseInt(quantityObj.toString());
            int minStock = Integer.parseInt(minStockObj.toString());

            return Math.max(0, minStock - quantity);
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * 导出Excel功能
     */
    private void exportToExcel() {
        try {
            if (tableModel.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "没有可导出的数据", "提示", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            updateStatus("正在导出Excel...");
            String type = reportTypeCombo.getSelectedItem().toString();
            String url = REPORTS_URL + "/export";

            if (type.equals("物料统计")) {
                url += "/material-flow";
                // 获取日期参数
                String startDate = startDateField.getText().trim();
                String endDate = endDateField.getText().trim();
                url += "?startDate=" + startDate + "&endDate=" + endDate;
            } else if (type.equals("进出仓单")) {
                url += "/monthly-records";
                // 获取年月参数
                int year = Integer.parseInt(yearField.getText().trim());
                int month = Integer.parseInt(monthField.getText().trim());
                url += "?year=" + year + "&month=" + month;
            } else if (type.equals("仓库账本")) {
                url += "/warehouse-ledger";
                // 获取物料代码和年份参数
                int idx = materialCombo.getSelectedIndex();
                String materialCode = "";
                if (idx >= 0 && materialList != null && idx < materialList.size()) {
                    Map<String, Object> material = materialList.get(idx);
                    materialCode = material.containsKey("materialCode") ? material.get("materialCode").toString() :
                            (material.containsKey("material_code") ? material.get("material_code").toString() : "");
                }
                int year = Integer.parseInt(yearField.getText().trim());
                url += "?materialCode=" + materialCode + "&year=" + year;
            } else if (type.equals("低库存预警")) {
                url += "/low-inventory";
                // 获取日期参数
                String startDate = startDateField.getText().trim();
                String endDate = endDateField.getText().trim();
                url += "?startDate=" + startDate + "&endDate=" + endDate;
            } else {
                JOptionPane.showMessageDialog(this, "该报表类型不支持导出", "提示", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            // 调用API导出Excel
            byte[] excelData = HttpClientUtil.downloadFile(url);

            // 显示保存对话框
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Excel文件", "xlsx"));
            String fileName = type + "_" + java.time.LocalDate.now().toString() + ".xlsx";
            fileChooser.setSelectedFile(new java.io.File(fileName));

            int userSelection = fileChooser.showSaveDialog(this);
            if (userSelection == JFileChooser.APPROVE_OPTION) {
                java.io.File fileToSave = fileChooser.getSelectedFile();
                // 确保文件扩展名为.xlsx
                String filePath = fileToSave.getAbsolutePath();
                if (!filePath.toLowerCase().endsWith(".xlsx")) {
                    filePath += ".xlsx";
                    fileToSave = new java.io.File(filePath);
                }

                // 保存文件
                try (java.io.FileOutputStream fos = new java.io.FileOutputStream(fileToSave)) {
                    fos.write(excelData);
                    updateStatus("Excel导出成功: " + fileToSave.getAbsolutePath());
                    JOptionPane.showMessageDialog(this, "Excel导出成功！文件保存至：" + fileToSave.getAbsolutePath(),
                            "导出成功", JOptionPane.INFORMATION_MESSAGE);
                }
            } else {
                updateStatus("Excel导出已取消");
            }
        } catch (Exception ex) {
            updateStatus("导出Excel失败: " + ex.getMessage());
            JOptionPane.showMessageDialog(this, "导出Excel失败: " + ex.getMessage(),
                    "错误", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    /**
     * 打印报表功能
     */
    private void printReport() {
        try {
            // 检查表格是否有数据
            if (tableModel.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "没有可打印的数据", "提示", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            updateStatus("正在准备打印...");
            // 获取报表类型
            String reportType = reportTypeCombo.getSelectedItem().toString();

            // 创建打印任务
            MessageFormat header = new MessageFormat(reportType + "报表 - 打印时间: {0}");
            MessageFormat footer = new MessageFormat("第 {0} 页");

            try {
                // 打印表格
                boolean complete = reportTable.print(JTable.PrintMode.FIT_WIDTH, header, footer);

                if (complete) {
                    updateStatus("打印完成");
                    JOptionPane.showMessageDialog(this, "打印完成", "成功", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    updateStatus("打印已取消");
                    JOptionPane.showMessageDialog(this, "打印已取消", "提示", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (java.awt.print.PrinterException ex) {
                updateStatus("打印失败: " + ex.getMessage());
                JOptionPane.showMessageDialog(this, "打印失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            updateStatus("打印报表失败: " + ex.getMessage());
            JOptionPane.showMessageDialog(this, "打印报表失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    /**
     * 更新状态栏
     */
    private void updateStatus(String message) {
        statusLabel.setText(message);
        System.out.println("状态: " + message);
    }
}